#!/bin/zsh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

./run_management_demo_mac.sh
STATUS=$?
printf '\nPress Return to close this window...'
read -r REPLY
exit $STATUS
