#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT_DIR"
PYTHON="$ROOT_DIR/.venv/bin/python"

if [ ! -x "$PYTHON" ]; then
    printf 'Setup has not been completed. Run ./setup_mac.sh first.\n' >&2
    exit 1
fi

"$PYTHON" -m put_seller.cli \
    --task manage \
    --mode demo \
    --as-of 2026-10-21 \
    --config config/config.yaml \
    --positions data/open_positions_demo.csv

REPORT="$ROOT_DIR/output/management_latest/position_management_report.html"
if [ -f "$REPORT" ] && command -v open >/dev/null 2>&1; then
    open "$REPORT"
fi
