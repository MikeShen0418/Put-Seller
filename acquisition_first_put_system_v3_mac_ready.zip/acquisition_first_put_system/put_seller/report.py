from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def _fmt_money(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    if not np.isfinite(number):
        return ""
    return f"${number:,.0f}"


def _fmt_price(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    if not np.isfinite(number):
        return ""
    return f"${number:,.2f}"


def _fmt_pct(value: Any, digits: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    if not np.isfinite(number):
        return ""
    return f"{number:.{digits}%}"


def _fmt_num(value: Any, digits: int = 2) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    if not np.isfinite(number):
        return ""
    return f"{number:.{digits}f}"


def _bool_text(value: Any) -> str:
    if isinstance(value, (bool, np.bool_)):
        return "Yes" if bool(value) else "No"
    return str(value)


def _table_or_empty(frame: pd.DataFrame, message: str) -> str:
    if frame.empty:
        return f'<div class="empty">{html.escape(message)}</div>'
    return frame.to_html(index=False, border=0, classes="data-table", escape=True)


def _prepare_best(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "decision",
        "strategy_type",
        "decision_score",
        "spot",
        "target_entry_price",
        "earnings_bear_case_price",
        "effective_target_price",
        "earnings_date",
        "expiration",
        "dte",
        "days_to_earnings",
        "days_after_earnings",
        "strike",
        "estimated_fill",
        "cash_required",
        "max_cycle_roi",
        "roi_30d_equivalent",
        "required_30d_roi",
        "net_assignment_basis",
        "target_basis_margin",
        "implied_move_pct",
        "implied_move_vs_historical_median",
        "implied_lower_price",
        "historical_worst_earnings_price",
        "basis_vs_implied_lower_pct",
        "stock_equal_roi_price",
        "abs_delta",
        "iv",
        "iv_rv_ratio",
        "max_contracts_allowed",
        "high_premium_review",
        "failure_reasons",
        "warnings",
    ]
    result = frame[[c for c in columns if c in frame.columns]].copy()
    result = result.rename(
        columns={
            "strategy_type": "Trade type",
            "decision_score": "Score",
            "target_entry_price": "Ordinary target",
            "earnings_bear_case_price": "Earnings bear case",
            "effective_target_price": "Effective target",
            "days_to_earnings": "Days to earnings",
            "days_after_earnings": "Days after earnings",
            "estimated_fill": "Est. premium",
            "cash_required": "Cash secured",
            "max_cycle_roi": "Cycle ROI",
            "roi_30d_equivalent": "30d ROI",
            "required_30d_roi": "Required 30d ROI",
            "net_assignment_basis": "Net basis",
            "target_basis_margin": "Basis vs target",
            "implied_move_pct": "Implied move",
            "implied_move_vs_historical_median": "Implied / historical median",
            "implied_lower_price": "Implied lower",
            "historical_worst_earnings_price": "Historical-worst price",
            "basis_vs_implied_lower_pct": "Basis vs implied lower",
            "stock_equal_roi_price": "Stock beats put ROI above",
            "abs_delta": "Abs delta",
            "iv_rv_ratio": "IV/RV",
            "max_contracts_allowed": "Contract cap",
            "high_premium_review": "High-premium review",
            "failure_reasons": "Why blocked",
        }
    )
    price_columns = [
        "spot",
        "Ordinary target",
        "Earnings bear case",
        "Effective target",
        "strike",
        "Est. premium",
        "Net basis",
        "Implied lower",
        "Historical-worst price",
        "Stock beats put ROI above",
    ]
    for column in price_columns:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    if "Cash secured" in result:
        result["Cash secured"] = result["Cash secured"].map(_fmt_money)
    for column in [
        "Cycle ROI",
        "30d ROI",
        "Required 30d ROI",
        "Basis vs target",
        "Implied move",
        "Basis vs implied lower",
        "iv",
    ]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    for column in ["Score", "Abs delta", "IV/RV", "Implied / historical median"]:
        if column in result:
            result[column] = result[column].map(_fmt_num)
    if "High-premium review" in result:
        result["High-premium review"] = result["High-premium review"].map(_bool_text)
    return result


def _prepare_allocation(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "strategy_type",
        "contracts",
        "potential_assigned_shares",
        "expiration",
        "dte",
        "strike",
        "estimated_fill",
        "net_assignment_basis",
        "effective_target_price",
        "allocated_cash",
        "allocated_premium",
        "max_cycle_roi",
        "total_waiting_30d_roi",
        "decision_score",
    ]
    result = frame[[c for c in columns if c in frame.columns]].copy()
    result = result.rename(
        columns={
            "strategy_type": "Trade type",
            "potential_assigned_shares": "Possible shares",
            "estimated_fill": "Est. premium",
            "net_assignment_basis": "Net basis",
            "effective_target_price": "Effective target",
            "allocated_cash": "Allocated cash",
            "allocated_premium": "Max premium",
            "max_cycle_roi": "Cycle ROI",
            "total_waiting_30d_roi": "30d ROI",
            "decision_score": "Score",
        }
    )
    for column in ["strike", "Est. premium", "Net basis", "Effective target"]:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    for column in ["Allocated cash", "Max premium"]:
        if column in result:
            result[column] = result[column].map(_fmt_money)
    for column in ["Cycle ROI", "30d ROI"]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    if "Score" in result:
        result["Score"] = result["Score"].map(_fmt_num)
    return result


def _prepare_underlyings(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "ownership_approved",
        "target_entry_price",
        "earnings_mode",
        "earnings_trade_approved",
        "earnings_bear_case_price",
        "spot",
        "daily_return",
        "down_move_atr",
        "close_off_low_atr",
        "rv20",
        "iv_proxy",
        "iv_percentile",
        "price_to_sma50",
        "return_20d",
        "earnings_date",
        "target_expiry_implied_move_pct",
        "target_expiry_implied_lower_price",
        "valuation_confidence",
        "priority_rank",
        "data_mode",
        "error",
    ]
    result = frame[[c for c in columns if c in frame.columns]].copy()
    result = result.rename(
        columns={
            "ownership_approved": "Own approved",
            "target_entry_price": "Ordinary target",
            "earnings_mode": "Earnings mode",
            "earnings_trade_approved": "Earnings approved",
            "earnings_bear_case_price": "Earnings bear case",
            "daily_return": "Day return",
            "down_move_atr": "Down move (ATR)",
            "close_off_low_atr": "Close off low (ATR)",
            "price_to_sma50": "Price/SMA50",
            "return_20d": "20d return",
            "iv_percentile": "IV percentile",
            "iv_proxy": "IV proxy",
            "target_expiry_implied_move_pct": "Target-expiry implied move",
            "target_expiry_implied_lower_price": "Target-expiry lower price",
            "valuation_confidence": "Valuation confidence",
            "priority_rank": "Priority",
            "data_mode": "Data mode",
        }
    )
    for column in [
        "spot",
        "Ordinary target",
        "Earnings bear case",
        "Target-expiry lower price",
    ]:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    for column in [
        "Day return",
        "rv20",
        "IV proxy",
        "20d return",
        "Target-expiry implied move",
    ]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    for column in ["Down move (ATR)", "Close off low (ATR)", "Price/SMA50"]:
        if column in result:
            result[column] = result[column].map(_fmt_num)
    if "IV percentile" in result:
        result["IV percentile"] = result["IV percentile"].map(lambda x: _fmt_num(x, 0))
    for column in ["Own approved", "Earnings approved"]:
        if column in result:
            result[column] = result[column].map(_bool_text)
    return result


def _prepare_earnings_scenarios(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "decision",
        "scenario",
        "scenario_stock_price",
        "stock_return_from_entry",
        "stock_pnl_per_100_shares",
        "assumed_post_event_iv",
        "post_event_dte",
        "modeled_put_close_cost",
        "modeled_short_put_pnl_per_contract",
        "modeled_short_put_roi_on_secured_cash",
        "expiration_short_put_pnl_per_contract",
        "expiration_short_put_roi_on_secured_cash",
        "short_put_minus_stock_pnl_at_expiration",
    ]
    result = frame[[c for c in columns if c in frame.columns]].copy()
    result = result.rename(
        columns={
            "scenario_stock_price": "Scenario stock",
            "stock_return_from_entry": "Stock return",
            "stock_pnl_per_100_shares": "Stock P/L (100 sh)",
            "assumed_post_event_iv": "Assumed post-event IV",
            "post_event_dte": "Post-event DTE",
            "modeled_put_close_cost": "Modeled put close",
            "modeled_short_put_pnl_per_contract": "Modeled put P/L",
            "modeled_short_put_roi_on_secured_cash": "Modeled put ROI",
            "expiration_short_put_pnl_per_contract": "Expiry put P/L",
            "expiration_short_put_roi_on_secured_cash": "Expiry put ROI",
            "short_put_minus_stock_pnl_at_expiration": "Put minus stock P/L",
        }
    )
    for column in ["Scenario stock", "Modeled put close"]:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    for column in [
        "Stock P/L (100 sh)",
        "Modeled put P/L",
        "Expiry put P/L",
        "Put minus stock P/L",
    ]:
        if column in result:
            result[column] = result[column].map(_fmt_money)
    for column in [
        "Stock return",
        "Assumed post-event IV",
        "Modeled put ROI",
        "Expiry put ROI",
    ]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    return result


def render_html_report(
    output_path: str | Path,
    mode: str,
    run_timestamp: str,
    profile_name: str,
    best_by_ticker: pd.DataFrame,
    underlying_snapshot: pd.DataFrame,
    allocation: pd.DataFrame,
    earnings_scenarios: pd.DataFrame,
    portfolio_summary: dict[str, float],
    config: dict[str, Any],
) -> None:
    output_path = Path(output_path)
    decision_counts = best_by_ticker.get(
        "decision", pd.Series(dtype=str)
    ).value_counts().to_dict()
    strategy_counts = best_by_ticker.get(
        "strategy_type", pd.Series(dtype=str)
    ).value_counts().to_dict()
    performance = config.get("performance", {})
    earnings_cfg = config.get("earnings_acquisition", {})
    cards = [
        ("Strategy", "Acquisition first"),
        ("Regular 30d target", _fmt_pct(performance.get("target_30d_roi", 0.02))),
        ("Earnings 30d target", _fmt_pct(earnings_cfg.get("target_30d_roi", 0.03))),
        ("After-tax annual goal", _fmt_pct(performance.get("annual_after_tax_goal", 0.20))),
        ("SELL candidates", str(decision_counts.get("SELL", 0))),
        ("Earnings candidates", str(strategy_counts.get("EARNINGS_ACQUISITION", 0))),
        ("Cash allocated", _fmt_money(portfolio_summary.get("cash_allocated", 0))),
        ("Earnings cash", _fmt_money(portfolio_summary.get("earnings_acquisition_cash", 0))),
        ("Max premium", _fmt_money(portfolio_summary.get("premium_dollars", 0))),
        ("Weighted 30d ROI", _fmt_pct(portfolio_summary.get("weighted_30d_roi", 0))),
    ]
    cards_html = "".join(
        f'<div class="card"><div class="label">{html.escape(label)}</div><div class="value">{html.escape(value)}</div></div>'
        for label, value in cards
    )

    best_html = _table_or_empty(
        _prepare_best(best_by_ticker), "No ticker results were produced."
    )
    underlying_html = _table_or_empty(
        _prepare_underlyings(underlying_snapshot), "No underlying results were produced."
    )
    allocation_html = _table_or_empty(
        _prepare_allocation(allocation),
        "No candidate passed valuation, return, entry, and portfolio constraints.",
    )
    scenario_html = _table_or_empty(
        _prepare_earnings_scenarios(earnings_scenarios),
        "No selected contract is an explicitly approved earnings-acquisition trade.",
    )

    profile = config["profile"]
    filters = config["decision"]["filters"]
    entry = config["decision"]["entry"]
    method = {
        "Ordinary valuation gate": "Net assignment basis = strike - premium must be at or below the ordinary target entry price",
        "Earnings valuation gate": "A crossing contract requires explicit approval and net basis at or below a post-report bear-case value",
        "Secured-cash ROI": "Premium / strike (the 100-share contract multiplier cancels)",
        "Comparable return": "(1 + cycle ROI)^(30 / DTE) - 1",
        "Regular 30-day target": _fmt_pct(performance.get("target_30d_roi", 0.02)),
        "Earnings 30-day target": _fmt_pct(earnings_cfg.get("target_30d_roi", 0.03)),
        "High-premium review": f"Flag at {_fmt_pct(performance.get('high_premium_review_30d_roi', 0.04))}; not an automatic buy signal",
        "DTE search": f"{profile['min_dte']}-{profile['max_dte']} days; target {profile['target_dte']}",
        "Earnings DTE search": f"{earnings_cfg.get('min_dte', profile['min_dte'])}-{earnings_cfg.get('max_dte', profile['max_dte'])} days; target {earnings_cfg.get('target_dte', profile['target_dte'])}",
        "Broad delta search": f"{profile['min_abs_delta']:.2f}-{profile['max_abs_delta']:.2f}; delta is secondary to valuation",
        "Preferred ordinary entry": f"Down {entry['min_down_move_atr']:.2f}-{entry['max_down_move_atr']:.2f} ATR with stabilization",
        "Earnings entry window": f"{earnings_cfg.get('min_days_before_earnings', 1)}-{earnings_cfg.get('max_entry_days_before_earnings', 10)} days before the report",
        "Earnings sizing": f"Default {float(earnings_cfg.get('position_size_multiplier', 0.5)):.0%} of normal contracts and no more than {float(earnings_cfg.get('max_ticker_pct', 0.125)):.1%} of total cash per ticker",
        "Implied move": "ATM call midpoint + ATM put midpoint, divided by spot; an estimate, not a hard boundary",
        "IV-crush scenario": f"Illustrative reprice assumes a {float(earnings_cfg.get('assumed_iv_crush_points', 0.15)):.0%} IV-point decline; it does not drive the decision",
        "Stock comparison": "Stock beats the short put above the displayed crossover because the put profit is capped at the premium",
        "Allocation objective": str(config["capital"]["objective"]),
    }
    method_rows = "".join(
        f"<tr><th>{html.escape(key)}</th><td>{html.escape(value)}</td></tr>"
        for key, value in method.items()
    )

    demo_banner = ""
    if mode.lower() == "demo":
        demo_banner = (
            '<div class="banner"><strong>DEMO MODE:</strong> Prices, chains, IVs, earnings dates, '
            "scenario outputs, and ticker examples are synthetic. They are not recommendations.</div>"
        )

    report = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Acquisition-First Put Decision Report</title>
<style>
:root {{ --ink:#14213d; --muted:#667085; --line:#e5e7eb; --panel:#fff; --bg:#f5f7fb; }}
* {{ box-sizing:border-box; }} body {{ margin:0; font-family:Inter,Segoe UI,Arial,sans-serif; color:var(--ink); background:var(--bg); }}
.container {{ max-width:1800px; margin:0 auto; padding:28px; }} h1 {{ margin:0 0 6px; font-size:30px; }} h2 {{ margin:32px 0 12px; font-size:21px; }}
.subtle {{ color:var(--muted); margin-bottom:20px; }} .banner {{ padding:12px 14px; border:1px solid #f0c36d; background:#fff8e6; border-radius:8px; margin:14px 0; }}
.cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin:18px 0 8px; }}
.card {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:14px; box-shadow:0 1px 2px rgba(16,24,40,.04); }}
.card .label {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.04em; }} .card .value {{ font-size:22px; font-weight:700; margin-top:7px; }}
.panel {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:16px; overflow:auto; }}
.data-table {{ border-collapse:collapse; width:100%; font-size:12px; white-space:nowrap; }} .data-table th {{ position:sticky; top:0; text-align:left; padding:9px 8px; border-bottom:2px solid #cfd6df; background:#eef3f8; }}
.data-table td {{ padding:8px; border-bottom:1px solid var(--line); vertical-align:top; }} .data-table tr:hover td {{ background:#fafcff; }}
.method-table {{ border-collapse:collapse; width:100%; max-width:1200px; }} .method-table th,.method-table td {{ border-bottom:1px solid var(--line); padding:9px; text-align:left; vertical-align:top; }} .method-table th {{ width:290px; color:var(--muted); }}
.empty,.note,.footer {{ color:var(--muted); }} .empty {{ padding:20px 4px; }} .note {{ font-size:12px; line-height:1.55; margin-top:10px; }} .footer {{ margin:36px 0 10px; font-size:12px; line-height:1.55; }}
</style></head><body><div class="container">
<h1>Acquisition-First Cash-Secured Put Report</h1>
<div class="subtle">Run {html.escape(run_timestamp)} | mode={html.escape(mode)} | profile={html.escape(profile_name)}</div>
{demo_banner}<div class="cards">{cards_html}</div>
<h2>Best contract by ticker</h2><div class="panel">{best_html}</div>
<div class="note">SELL means the applicable valuation, return, event, execution, timing, and score rules pass. Earnings-acquisition trades are explicitly labeled and use the bear-case target rather than the ordinary target.</div>
<h2>Optimized allocation</h2><div class="panel">{allocation_html}</div>
<h2>Earnings outcome scenarios</h2><div class="panel">{scenario_html}</div>
<div class="note">The modeled post-event figures assume a configurable IV decline. Expiration payoff does not depend on IV. A large downside gap can overwhelm the IV crush because intrinsic value remains.</div>
<h2>Underlying conditions and ownership inputs</h2><div class="panel">{underlying_html}</div>
<h2>Active decision rules</h2><div class="panel"><table class="method-table">{method_rows}</table></div>
<div class="footer">Assignment is an intended possible outcome, not a failure. The adverse case is owning a company whose thesis deteriorates or whose value was estimated incorrectly. A covered call can lower basis after assignment, but it cannot guarantee recovery and can cap a rebound. This software does not place orders.</div>
</div></body></html>"""
    output_path.write_text(report, encoding="utf-8")


def write_run_summary(path: str | Path, payload: dict[str, Any]) -> None:
    Path(path).write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
