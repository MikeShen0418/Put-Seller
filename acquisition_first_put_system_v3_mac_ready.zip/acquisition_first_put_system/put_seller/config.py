from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    """Raised when the configuration is missing required settings."""


def load_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"Config file does not exist: {config_path}")

    with config_path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}

    profile_name = raw.get("active_profile", "acquisition_core")
    profiles = raw.get("profiles", {})
    if profile_name not in profiles:
        raise ConfigError(
            f"active_profile={profile_name!r} was not found under profiles. "
            f"Available profiles: {sorted(profiles)}"
        )

    config = deepcopy(raw)
    config["profile_name"] = profile_name
    config["profile"] = deepcopy(profiles[profile_name])
    _validate(config)
    return config


def _validate(config: dict[str, Any]) -> None:
    required_top = ["watchlist_path", "capital", "decision", "profile", "performance"]
    missing = [key for key in required_top if key not in config]
    if missing:
        raise ConfigError(f"Missing top-level config keys: {missing}")

    profile = config["profile"]
    required_profile = [
        "min_dte", "max_dte", "min_abs_delta", "max_abs_delta", "preferred_abs_delta",
    ]
    missing_profile = [key for key in required_profile if key not in profile]
    if missing_profile:
        raise ConfigError(f"Missing profile keys: {missing_profile}")
    if profile["min_dte"] > profile["max_dte"]:
        raise ConfigError("profile.min_dte cannot exceed profile.max_dte")
    if profile["min_abs_delta"] > profile["max_abs_delta"]:
        raise ConfigError("profile.min_abs_delta cannot exceed profile.max_abs_delta")

    target_roi = float(config["performance"].get("target_30d_roi", 0.0))
    if target_roi < 0:
        raise ConfigError("performance.target_30d_roi cannot be negative")

    earnings = config.get("earnings_acquisition", {})
    earnings_target = float(earnings.get("target_30d_roi", 0.0))
    if earnings_target < 0:
        raise ConfigError("earnings_acquisition.target_30d_roi cannot be negative")
    earnings_min_dte = int(earnings.get("min_dte", profile["min_dte"]))
    earnings_max_dte = int(earnings.get("max_dte", profile["max_dte"]))
    earnings_target_dte = int(earnings.get("target_dte", earnings_min_dte))
    if earnings_min_dte > earnings_max_dte:
        raise ConfigError("earnings_acquisition.min_dte cannot exceed max_dte")
    if not earnings_min_dte <= earnings_target_dte <= earnings_max_dte:
        raise ConfigError(
            "earnings_acquisition.target_dte must be inside the earnings DTE window"
        )
    if int(earnings.get("min_days_before_earnings", 0)) > int(
        earnings.get("max_entry_days_before_earnings", 0)
    ):
        raise ConfigError(
            "earnings_acquisition.min_days_before_earnings cannot exceed "
            "max_entry_days_before_earnings"
        )
    position_multiplier = float(earnings.get("position_size_multiplier", 0.5))
    if not 0 <= position_multiplier <= 1:
        raise ConfigError("earnings_acquisition.position_size_multiplier must be between 0 and 1")

    weights = config["decision"].get("weights", {})
    if weights:
        total = sum(float(value) for value in weights.values())
        if abs(total - 1.0) > 1e-6:
            raise ConfigError(f"decision.weights must sum to 1.0; got {total:.6f}")


def resolve_path(config_file: str | Path, configured_path: str | Path) -> Path:
    """Resolve a path relative to the directory containing the YAML config."""
    configured = Path(configured_path)
    if configured.is_absolute():
        return configured
    return (Path(config_file).resolve().parent / configured).resolve()
