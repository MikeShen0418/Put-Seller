from __future__ import annotations

import math
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd


def compute_underlying_features(history: pd.DataFrame, quote: dict[str, Any]) -> dict[str, float]:
    """Compute price, trend, realized-volatility and entry-timing features."""
    if history.empty or len(history) < 60:
        raise ValueError("At least 60 daily bars are required")

    frame = history.copy().sort_values("date").reset_index(drop=True)
    for column in ["open", "high", "low", "close", "volume"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame = frame.dropna(subset=["high", "low", "close"])
    if len(frame) < 60:
        raise ValueError("Too few valid daily bars after numeric cleaning")

    previous_close = frame["close"].shift(1)
    true_range = pd.concat(
        [
            frame["high"] - frame["low"],
            (frame["high"] - previous_close).abs(),
            (frame["low"] - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    atr20 = float(true_range.tail(20).mean())

    log_returns = np.log(frame["close"] / frame["close"].shift(1)).dropna()
    rv20 = float(log_returns.tail(20).std(ddof=1) * math.sqrt(252.0))
    rv60 = float(log_returns.tail(60).std(ddof=1) * math.sqrt(252.0))

    spot = float(quote["spot"])
    prev_close = float(quote.get("prev_close") or frame.iloc[-2]["close"])
    day_low = float(quote.get("low") or spot)
    day_high = float(quote.get("high") or spot)
    atr20 = max(atr20, spot * 0.001)

    sma20 = float(frame["close"].tail(20).mean())
    sma50 = float(frame["close"].tail(50).mean())
    sma200 = float(frame["close"].tail(min(200, len(frame))).mean())
    close_5d_ago = float(frame["close"].iloc[-6]) if len(frame) >= 6 else prev_close
    close_20d_ago = float(frame["close"].iloc[-21]) if len(frame) >= 21 else prev_close

    daily_move_atr = (spot - prev_close) / atr20
    down_move_atr = (prev_close - spot) / atr20
    close_off_low_atr = (spot - day_low) / atr20
    intraday_range_atr = (day_high - day_low) / atr20
    drop_5d_atr = max(0.0, (close_5d_ago - spot) / atr20)

    x = np.arange(min(20, len(frame)), dtype=float)
    y = np.log(frame["close"].tail(len(x)).to_numpy(dtype=float))
    slope20_annualized = float(np.polyfit(x, y, 1)[0] * 252.0) if len(x) >= 5 else 0.0

    return {
        "spot": spot,
        "prev_close": prev_close,
        "daily_return": spot / prev_close - 1.0 if prev_close else 0.0,
        "atr20": atr20,
        "atr20_pct": atr20 / spot if spot else np.nan,
        "daily_move_atr": daily_move_atr,
        "down_move_atr": down_move_atr,
        "close_off_low_atr": close_off_low_atr,
        "intraday_range_atr": intraday_range_atr,
        "drop_5d_atr": drop_5d_atr,
        "rv20": rv20,
        "rv60": rv60,
        "sma20": sma20,
        "sma50": sma50,
        "sma200": sma200,
        "price_to_sma20": spot / sma20 if sma20 else np.nan,
        "price_to_sma50": spot / sma50 if sma50 else np.nan,
        "price_to_sma200": spot / sma200 if sma200 else np.nan,
        "return_5d": spot / close_5d_ago - 1.0 if close_5d_ago else 0.0,
        "return_20d": spot / close_20d_ago - 1.0 if close_20d_ago else 0.0,
        "slope20_annualized": slope20_annualized,
    }


def compute_atm_straddle_metrics(chain: pd.DataFrame, spot: float) -> pd.DataFrame:
    """Estimate the option-implied move for each expiration from the ATM straddle.

    The result is an approximation based on the midpoint of the call and put at
    the strike closest to spot. It is not a probability boundary or maximum
    possible move.
    """
    columns = [
        "expiration",
        "atm_strike",
        "atm_call_mid",
        "atm_put_mid",
        "atm_straddle_cost",
        "implied_move_pct",
        "implied_lower_price",
        "implied_upper_price",
    ]
    if chain.empty or not np.isfinite(spot) or spot <= 0:
        return pd.DataFrame(columns=columns)

    frame = chain.copy()
    if not {"expiration", "strike", "option_type", "bid", "ask"}.issubset(frame.columns):
        return pd.DataFrame(columns=columns)
    frame["expiration"] = pd.to_datetime(frame["expiration"], errors="coerce").dt.date
    for column in ["strike", "bid", "ask"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame["option_type"] = frame["option_type"].astype(str).str.lower()
    frame = frame.loc[frame["option_type"].isin(["put", "call"])].dropna(
        subset=["expiration", "strike", "bid", "ask"]
    )
    if frame.empty:
        return pd.DataFrame(columns=columns)

    frame["midpoint"] = (frame["bid"].clip(lower=0) + frame["ask"].clip(lower=0)) / 2.0
    rows: list[dict[str, Any]] = []
    for expiration, expiry_frame in frame.groupby("expiration", sort=True):
        pivot = expiry_frame.pivot_table(
            index="strike", columns="option_type", values="midpoint", aggfunc="median"
        )
        if not {"put", "call"}.issubset(pivot.columns):
            continue
        pivot = pivot.dropna(subset=["put", "call"])
        if pivot.empty:
            continue
        atm_strike = float(min(pivot.index, key=lambda strike: abs(float(strike) - spot)))
        call_mid = float(pivot.loc[atm_strike, "call"])
        put_mid = float(pivot.loc[atm_strike, "put"])
        straddle = max(call_mid + put_mid, 0.0)
        implied_move_pct = straddle / spot
        rows.append(
            {
                "expiration": expiration,
                "atm_strike": atm_strike,
                "atm_call_mid": call_mid,
                "atm_put_mid": put_mid,
                "atm_straddle_cost": straddle,
                "implied_move_pct": implied_move_pct,
                "implied_lower_price": max(spot - straddle, 0.0),
                "implied_upper_price": spot + straddle,
            }
        )
    return pd.DataFrame(rows, columns=columns)


def enrich_option_chain(
    chain: pd.DataFrame,
    quote: dict[str, Any],
    underlying: dict[str, float],
    as_of: date,
    earnings_date: date | None,
    execution_fraction_from_bid: float = 0.35,
    earnings_buffer_days: int = 2,
    include_collateral_interest: bool = False,
    collateral_annual_yield: float = 0.0,
    event_metrics: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Add secured-cash ROI, acquisition basis, liquidity and earnings features."""
    if chain.empty:
        return chain.copy()

    frame = chain.copy()
    if "option_type" in frame.columns:
        frame = frame.loc[frame["option_type"].astype(str).str.lower() == "put"].copy()
    if frame.empty:
        return frame

    numeric_columns = [
        "strike",
        "bid",
        "ask",
        "last",
        "volume",
        "open_interest",
        "delta",
        "gamma",
        "theta",
        "vega",
        "iv",
    ]
    for column in numeric_columns:
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")

    frame["expiration"] = pd.to_datetime(frame["expiration"]).dt.date
    if event_metrics is not None and not event_metrics.empty:
        metrics = event_metrics.copy()
        metrics["expiration"] = pd.to_datetime(metrics["expiration"], errors="coerce").dt.date
        frame = frame.merge(metrics, on="expiration", how="left", validate="many_to_one")
    else:
        for column in [
            "atm_strike",
            "atm_call_mid",
            "atm_put_mid",
            "atm_straddle_cost",
            "implied_move_pct",
            "implied_lower_price",
            "implied_upper_price",
        ]:
            frame[column] = np.nan

    frame["dte"] = frame["expiration"].map(lambda value: max((value - as_of).days, 0))
    frame["abs_delta"] = frame["delta"].abs()
    frame["midpoint"] = (frame["bid"] + frame["ask"]) / 2.0
    frame["spread"] = frame["ask"] - frame["bid"]
    frame["spread_pct"] = np.where(
        frame["midpoint"] > 0, frame["spread"] / frame["midpoint"], np.nan
    )

    fraction = min(max(float(execution_fraction_from_bid), 0.0), 1.0)
    frame["estimated_fill"] = frame["bid"] + fraction * frame["spread"].clip(lower=0)
    frame["estimated_fill"] = frame[["estimated_fill", "ask"]].min(axis=1).clip(lower=0)

    spot = float(quote["spot"])
    rv20 = max(float(underlying["rv20"]), 1e-6)
    frame["cash_required"] = frame["strike"] * 100.0
    frame["premium_dollars"] = frame["estimated_fill"] * 100.0

    # Core formula: premium divided by the full cash purchasing capacity
    # committed to assignment. The 100-share multiplier cancels.
    frame["max_cycle_roi"] = np.where(
        frame["strike"] > 0,
        frame["estimated_fill"] / frame["strike"],
        np.nan,
    )
    frame["max_cycle_yield"] = frame["max_cycle_roi"]
    frame["net_cash_roi"] = np.where(
        (frame["strike"] - frame["estimated_fill"]) > 0,
        frame["estimated_fill"] / (frame["strike"] - frame["estimated_fill"]),
        np.nan,
    )
    frame["annualized_max_yield"] = np.where(
        frame["dte"] > 0,
        frame["max_cycle_roi"] * 365.0 / frame["dte"],
        np.nan,
    )
    frame["roi_30d_equivalent"] = np.where(
        frame["dte"] > 0,
        np.power(1.0 + frame["max_cycle_roi"], 30.0 / frame["dte"]) - 1.0,
        np.nan,
    )

    annual_cash_yield = max(float(collateral_annual_yield), 0.0)
    frame["collateral_interest_dollars"] = np.where(
        include_collateral_interest & (frame["dte"] > 0),
        frame["cash_required"] * annual_cash_yield * frame["dte"] / 365.0,
        0.0,
    )
    frame["total_waiting_dollars"] = (
        frame["premium_dollars"] + frame["collateral_interest_dollars"]
    )
    frame["total_waiting_cycle_roi"] = np.where(
        frame["cash_required"] > 0,
        frame["total_waiting_dollars"] / frame["cash_required"],
        np.nan,
    )
    frame["total_waiting_30d_roi"] = np.where(
        frame["dte"] > 0,
        np.power(1.0 + frame["total_waiting_cycle_roi"], 30.0 / frame["dte"]) - 1.0,
        np.nan,
    )

    frame["net_assignment_basis"] = frame["strike"] - frame["estimated_fill"]
    frame["breakeven"] = frame["net_assignment_basis"]
    frame["strike_discount"] = (spot - frame["strike"]) / spot
    frame["breakeven_discount"] = (spot - frame["net_assignment_basis"]) / spot
    frame["expected_move"] = spot * frame["iv"] * np.sqrt(frame["dte"] / 365.0)
    frame["strike_distance_expected_move"] = np.where(
        frame["expected_move"] > 0,
        (spot - frame["strike"]) / frame["expected_move"],
        np.nan,
    )
    frame["iv_rv_ratio"] = frame["iv"] / rv20
    frame["is_otm"] = frame["strike"] < spot
    frame["mark_to_spot_if_assigned"] = (spot - frame["net_assignment_basis"]) * 100.0

    # A short put has capped upside. These two crossover prices show when an
    # outright stock purchase would beat the put in dollar P/L or return on
    # committed capital, assuming the put expires worthless.
    frame["stock_equal_pnl_price"] = spot + frame["estimated_fill"]
    frame["stock_equal_roi_price"] = spot * (1.0 + frame["max_cycle_roi"])
    frame["stock_return_needed_to_beat_put_roi"] = frame["max_cycle_roi"]

    if earnings_date is None:
        frame["earnings_date"] = pd.NaT
        frame["days_to_earnings"] = np.nan
        frame["days_after_earnings"] = np.nan
        frame["earnings_known"] = False
        frame["earnings_crosses"] = False
    else:
        frame["earnings_date"] = earnings_date
        frame["days_to_earnings"] = (earnings_date - as_of).days
        frame["days_after_earnings"] = frame["expiration"].map(
            lambda expiration: (expiration - earnings_date).days
        )
        frame["earnings_known"] = True
        safe_cutoff = frame["expiration"].map(
            lambda value: value + timedelta(days=earnings_buffer_days)
        )
        frame["earnings_crosses"] = safe_cutoff.map(lambda value: earnings_date <= value)

    frame["expiration_pnl_at_implied_lower_per_share"] = np.where(
        frame["implied_lower_price"].notna(),
        frame["estimated_fill"]
        - np.maximum(frame["strike"] - frame["implied_lower_price"], 0.0),
        np.nan,
    )
    frame["expiration_roi_at_implied_lower"] = np.where(
        frame["strike"] > 0,
        frame["expiration_pnl_at_implied_lower_per_share"] / frame["strike"],
        np.nan,
    )

    for key, value in underlying.items():
        if key not in frame.columns:
            frame[key] = value
    frame["spot"] = spot
    return frame
