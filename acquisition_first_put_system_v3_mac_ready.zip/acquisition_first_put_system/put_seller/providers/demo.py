from __future__ import annotations

import hashlib
import math
from datetime import date, datetime, timedelta, timezone
from typing import Any

import numpy as np
import pandas as pd

from ..math_utils import black_scholes_call, black_scholes_put
from .base import MarketDataProvider


DEMO_SPECS: dict[str, dict[str, Any]] = {
    # These are synthetic scenarios attached to familiar tickers. They are not live prices.
    "NVDA": dict(price=180.0, vol=0.48, drift=0.20, down_atr=1.05, close_off_low=0.48, iv_mult=1.28, liquidity=1.00, trend="strong", earnings_days=55),
    "TSLA": dict(price=410.0, vol=0.62, drift=0.08, down_atr=2.25, close_off_low=0.08, iv_mult=1.20, liquidity=1.00, trend="breakdown", earnings_days=12),
    "AMD": dict(price=215.0, vol=0.52, drift=0.14, down_atr=0.92, close_off_low=0.38, iv_mult=1.32, liquidity=0.95, trend="stable", earnings_days=42),
    "PLTR": dict(price=185.0, vol=0.58, drift=0.24, down_atr=-0.20, close_off_low=0.55, iv_mult=1.35, liquidity=0.95, trend="strong", earnings_days=18),
    "META": dict(price=690.0, vol=0.34, drift=0.16, down_atr=0.68, close_off_low=0.44, iv_mult=1.22, liquidity=1.00, trend="stable", earnings_days=68),
    "AMZN": dict(price=245.0, vol=0.38, drift=0.14, down_atr=1.18, close_off_low=0.36, iv_mult=1.25, liquidity=1.00, trend="stable", earnings_days=36),
    "AVGO": dict(price=365.0, vol=0.42, drift=0.18, down_atr=0.28, close_off_low=0.42, iv_mult=1.26, liquidity=0.90, trend="strong", earnings_days=63),
    "MU": dict(price=235.0, vol=0.50, drift=0.12, down_atr=1.48, close_off_low=0.16, iv_mult=1.38, liquidity=0.85, trend="weak", earnings_days=9),
    "COIN": dict(price=445.0, vol=0.78, drift=0.12, down_atr=1.02, close_off_low=0.31, iv_mult=1.18, liquidity=0.55, trend="stable", earnings_days=24),
    "GOOGL": dict(price=310.0, vol=0.31, drift=0.13, down_atr=0.74, close_off_low=0.40, iv_mult=1.24, liquidity=1.00, trend="stable", earnings_days=51),
}


class DemoProvider(MarketDataProvider):
    """Deterministic synthetic provider so the full pipeline runs without API keys."""

    def __init__(self, as_of: date | None = None) -> None:
        self.as_of = as_of or date.today()
        self._history_cache: dict[str, pd.DataFrame] = {}

    def _spec(self, ticker: str) -> dict[str, Any]:
        ticker = ticker.upper()
        if ticker in DEMO_SPECS:
            return DEMO_SPECS[ticker]
        return dict(
            price=100.0,
            vol=0.45,
            drift=0.10,
            down_atr=0.8,
            close_off_low=0.35,
            iv_mult=1.25,
            liquidity=0.8,
            trend="stable",
            earnings_days=60,
        )

    @staticmethod
    def _seed(ticker: str, suffix: str = "") -> int:
        digest = hashlib.sha256(f"{ticker.upper()}::{suffix}".encode("utf-8")).hexdigest()
        return int(digest[:8], 16)

    def get_history(self, ticker: str, calendar_days: int = 420) -> pd.DataFrame:
        ticker = ticker.upper()
        if ticker in self._history_cache:
            return self._history_cache[ticker].copy()

        spec = self._spec(ticker)
        rng = np.random.default_rng(self._seed(ticker, "prices"))
        periods = max(300, int(calendar_days * 5 / 7))
        dates = pd.bdate_range(end=pd.Timestamp(self.as_of), periods=periods)

        vol = float(spec["vol"])
        drift = float(spec["drift"])
        returns = rng.normal(
            loc=(drift - 0.5 * vol * vol) / 252.0,
            scale=vol / math.sqrt(252.0),
            size=periods,
        )

        trend = spec["trend"]
        if trend == "strong":
            returns[-40:-1] += 0.0012
        elif trend == "weak":
            returns[-35:-1] -= 0.0020
        elif trend == "breakdown":
            returns[-18:-1] -= 0.0070

        close = np.exp(np.cumsum(returns))
        close *= float(spec["price"]) / close[-2]

        daily_sigma = close * vol / math.sqrt(252.0)
        open_px = np.r_[close[0], close[:-1] * (1 + rng.normal(0, vol / math.sqrt(252.0) * 0.18, periods - 1))]
        range_scale = np.maximum(daily_sigma * rng.uniform(0.55, 1.45, periods), 0.20)
        high = np.maximum(open_px, close) + range_scale * rng.uniform(0.25, 0.75, periods)
        low = np.minimum(open_px, close) - range_scale * rng.uniform(0.25, 0.75, periods)
        volume = rng.integers(8_000_000, 80_000_000, periods)

        frame = pd.DataFrame(
            {
                "date": dates.date,
                "open": open_px,
                "high": high,
                "low": np.maximum(low, 0.01),
                "close": close,
                "volume": volume,
            }
        )

        # Force the final session into a known scenario so the demo exercises
        # SELL, WATCH and REJECT paths in a deterministic way.
        prior = frame.iloc[:-1].copy()
        prev_close = float(prior.iloc[-1]["close"])
        prev = prior["close"].shift(1)
        true_range = pd.concat(
            [
                prior["high"] - prior["low"],
                (prior["high"] - prev).abs(),
                (prior["low"] - prev).abs(),
            ],
            axis=1,
        ).max(axis=1)
        atr = float(true_range.tail(20).mean())
        atr = max(atr, prev_close * 0.01)

        down_atr = float(spec["down_atr"])
        final_close = max(1.0, prev_close - down_atr * atr)
        final_open = prev_close - 0.12 * down_atr * atr
        close_off_low = float(spec["close_off_low"])
        final_low = max(0.01, final_close - close_off_low * atr)
        final_high = max(final_open, final_close) + 0.28 * atr

        frame.loc[frame.index[-1], ["open", "high", "low", "close"]] = [
            final_open,
            final_high,
            final_low,
            final_close,
        ]
        self._history_cache[ticker] = frame
        return frame.copy()

    def get_quote(self, ticker: str) -> dict:
        history = self.get_history(ticker)
        last = history.iloc[-1]
        prev = history.iloc[-2]
        return {
            "ticker": ticker.upper(),
            "spot": float(last["close"]),
            "prev_close": float(prev["close"]),
            "open": float(last["open"]),
            "high": float(last["high"]),
            "low": float(last["low"]),
            "volume": int(last["volume"]),
            "as_of": datetime.combine(self.as_of, datetime.min.time(), tzinfo=timezone.utc),
            "data_mode": "DEMO_SYNTHETIC",
        }

    def get_expirations(self, ticker: str) -> list[date]:
        del ticker
        expirations: list[date] = []
        cursor = self.as_of + timedelta(days=1)
        while len(expirations) < 12:
            if cursor.weekday() == 4:  # Friday
                expirations.append(cursor)
            cursor += timedelta(days=1)
        return expirations

    def get_option_chain(
        self,
        ticker: str,
        expiration: date,
        option_type: str | None = "put",
    ) -> pd.DataFrame:
        ticker = ticker.upper()
        requested = None if option_type is None else str(option_type).lower()
        if requested not in {None, "put", "call"}:
            raise ValueError("option_type must be 'put', 'call', or None")

        quote = self.get_quote(ticker)
        spot = float(quote["spot"])
        spec = self._spec(ticker)
        dte = max((expiration - self.as_of).days, 1)
        t = dte / 365.0
        base_iv = float(spec["vol"]) * float(spec["iv_mult"])
        earnings = self.get_next_earnings(ticker)
        if earnings is not None and earnings <= expiration:
            base_iv += 0.10 * math.sqrt(max(1.0, 30.0 / dte))

        if spot < 50:
            step = 1.0
        elif spot < 100:
            step = 2.5
        elif spot < 250:
            step = 5.0
        else:
            step = 10.0

        min_strike = math.floor((spot * 0.55) / step) * step
        max_strike = math.ceil((spot * 1.45) / step) * step
        strikes = np.arange(min_strike, max_strike + step / 2, step)
        rng = np.random.default_rng(self._seed(ticker, expiration.isoformat()))
        liquidity = float(spec["liquidity"])
        types = [requested] if requested else ["put", "call"]

        rows: list[dict[str, Any]] = []
        for current_type in types:
            for strike in strikes:
                moneyness = strike / spot
                downside = max(0.0, 1.0 - moneyness)
                upside = max(0.0, moneyness - 1.0)
                if current_type == "put":
                    iv = max(0.10, base_iv + 0.42 * downside - 0.06 * upside + 0.015 * math.sqrt(dte / 30.0))
                    greeks = black_scholes_put(
                        spot=spot, strike=float(strike), time_years=t, rate=0.04, volatility=iv
                    )
                    type_code = "P"
                else:
                    iv = max(0.10, base_iv + 0.18 * downside - 0.035 * upside + 0.010 * math.sqrt(dte / 30.0))
                    greeks = black_scholes_call(
                        spot=spot, strike=float(strike), time_years=t, rate=0.04, volatility=iv
                    )
                    type_code = "C"

                mid = max(greeks["price"], 0.01)
                delta_abs = abs(greeks["delta"])
                spread_pct = min(0.35, (0.025 + 0.035 * delta_abs + 0.015 / max(mid, 0.25)) / liquidity)
                spread = max(0.02, mid * spread_pct)
                bid = max(0.01, mid - spread / 2.0)
                ask = max(bid + 0.01, mid + spread / 2.0)

                oi_center = math.exp(-((delta_abs - 0.28) / 0.24) ** 2)
                open_interest = int(max(5, liquidity * (350 + 6500 * oi_center) * rng.uniform(0.55, 1.45)))
                volume = int(max(0, liquidity * (20 + 850 * oi_center) * rng.uniform(0.20, 1.30)))

                occ_strike = int(round(strike * 1000))
                symbol = f"{ticker}{expiration.strftime('%y%m%d')}{type_code}{occ_strike:08d}"
                rows.append(
                    {
                        "symbol": symbol,
                        "ticker": ticker,
                        "expiration": expiration,
                        "strike": float(strike),
                        "option_type": current_type,
                        "bid": round(bid, 2),
                        "ask": round(ask, 2),
                        "last": round(mid * rng.uniform(0.97, 1.03), 2),
                        "volume": volume,
                        "open_interest": open_interest,
                        "delta": float(greeks["delta"]),
                        "gamma": float(greeks["gamma"]),
                        "theta": float(greeks["theta"]),
                        "vega": float(greeks["vega"]),
                        "iv": float(iv),
                        "quote_time": quote["as_of"],
                    }
                )
        return pd.DataFrame(rows)

    def get_next_earnings(self, ticker: str) -> date | None:
        spec = self._spec(ticker)
        days = spec.get("earnings_days")
        if days is None:
            return None
        return self.as_of + timedelta(days=int(days))

    def synthetic_iv_history(self, ticker: str, observations: int = 160) -> pd.DataFrame:
        """Create a synthetic IV history solely to exercise IV-percentile logic."""
        ticker = ticker.upper()
        spec = self._spec(ticker)
        rng = np.random.default_rng(self._seed(ticker, "iv_history"))
        dates = pd.bdate_range(end=pd.Timestamp(self.as_of) - pd.Timedelta(days=1), periods=observations)
        center = float(spec["vol"]) * 1.12
        shocks = rng.normal(0.0, 0.06, observations)
        values = np.empty(observations)
        values[0] = max(0.12, center + shocks[0])
        for idx in range(1, observations):
            values[idx] = max(0.10, center + 0.88 * (values[idx - 1] - center) + shocks[idx])
        return pd.DataFrame(
            {
                "date": dates.date,
                "ticker": ticker,
                "iv_proxy": values,
                "source": "DEMO_SYNTHETIC",
            }
        )
