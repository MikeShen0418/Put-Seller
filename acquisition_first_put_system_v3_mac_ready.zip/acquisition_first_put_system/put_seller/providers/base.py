from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date

import pandas as pd


class MarketDataProvider(ABC):
    """Normalized market-data interface used by screening and management."""

    @abstractmethod
    def get_quote(self, ticker: str) -> dict:
        """Return spot, previous close, open, high, low, volume and timestamp."""

    @abstractmethod
    def get_history(self, ticker: str, calendar_days: int = 420) -> pd.DataFrame:
        """Return daily OHLCV columns indexed or keyed by date."""

    @abstractmethod
    def get_expirations(self, ticker: str) -> list[date]:
        """Return available option expiration dates."""

    @abstractmethod
    def get_option_chain(
        self,
        ticker: str,
        expiration: date,
        option_type: str | None = "put",
    ) -> pd.DataFrame:
        """Return a normalized option chain with Greeks and IV.

        option_type may be ``put``, ``call`` or ``None`` for both.
        """

    @abstractmethod
    def get_next_earnings(self, ticker: str) -> date | None:
        """Return the next known earnings date, or None if unavailable."""
