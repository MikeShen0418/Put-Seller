from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    if not np.isfinite(value):
        return 0.0
    return float(min(max(value, low), high))


def _linear_score(value: float, poor: float, excellent: float) -> float:
    if not np.isfinite(value):
        return 0.0
    if excellent == poor:
        return 100.0 if value >= excellent else 0.0
    return _clamp(100.0 * (value - poor) / (excellent - poor))


def _bell_score(value: float, center: float, width: float) -> float:
    if not np.isfinite(value):
        return 0.0
    width = max(width, 1e-6)
    return _clamp(100.0 * math.exp(-((value - center) / width) ** 2))


def _bool(value: Any, default: bool = False) -> bool:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _number(value: Any, default: float = float("nan")) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if np.isfinite(result) else default


def _text(value: Any, default: str = "") -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    text = str(value).strip()
    return text or default


def score_candidates(
    candidates: pd.DataFrame,
    config: dict[str, Any],
    manual_news_clear: bool,
    iv_percentile: float,
    iv_history_days: int,
) -> pd.DataFrame:
    """Score regular and earnings-acquisition cash-secured puts.

    Regular puts require the ordinary target entry price and normally avoid
    earnings. Earnings-acquisition puts are a separate event strategy: they
    require explicit approval, a post-earnings bear-case value, event metrics,
    and smaller position limits.
    """
    if candidates.empty:
        return candidates.copy()

    profile = config["profile"]
    decision = config["decision"]
    filters = decision["filters"]
    entry = decision["entry"]
    targets = decision["score_targets"]
    weights = decision["weights"]
    ownership_cfg = config.get("ownership", {})
    performance = config.get("performance", {})
    earnings_cfg = config.get("earnings_acquisition", {})

    rows: list[dict[str, Any]] = []
    for _, source in candidates.iterrows():
        row = source.to_dict()
        policy_failures: list[str] = []
        economic_failures: list[str] = []
        warnings: list[str] = []
        positives: list[str] = []

        dte = _number(row.get("dte"))
        abs_delta = _number(row.get("abs_delta"))
        spread_pct = _number(row.get("spread_pct"))
        open_interest = _number(row.get("open_interest"), 0.0)
        volume = _number(row.get("volume"), 0.0)
        bid = _number(row.get("bid"), 0.0)
        iv_rv = _number(row.get("iv_rv_ratio"))
        down_atr = _number(row.get("down_move_atr"))
        close_off_low = _number(row.get("close_off_low_atr"))
        drop_5d_atr = _number(row.get("drop_5d_atr"))
        price_to_sma50 = _number(row.get("price_to_sma50"))
        roi_30d = _number(row.get("total_waiting_30d_roi", row.get("roi_30d_equivalent")))
        net_basis = _number(row.get("net_assignment_basis", row.get("breakeven")))
        target_entry = _number(row.get("target_entry_price"))
        earnings_bear_case = _number(row.get("earnings_bear_case_price"))
        valuation_confidence = _number(row.get("valuation_confidence"), 50.0)
        priority_rank = _number(row.get("priority_rank"), targets.get("priority_rank_poor", 10))
        implied_lower = _number(row.get("implied_lower_price"))
        implied_move_pct = _number(row.get("implied_move_pct"))
        spot = _number(row.get("spot"))
        days_to_earnings = _number(row.get("days_to_earnings"))
        days_after_earnings = _number(row.get("days_after_earnings"))
        historical_median_move = _number(row.get("historical_median_earnings_move_pct"))
        historical_worst_drop = _number(row.get("historical_worst_earnings_drop_pct"))

        ownership_approved = _bool(row.get("ownership_approved"), False)
        thesis_intact = _bool(row.get("thesis_intact"), True)
        earnings_known = _bool(row.get("earnings_known"), False)
        earnings_crosses = _bool(row.get("earnings_crosses"), False)
        event_inside_contract = bool(
            earnings_known and np.isfinite(days_after_earnings) and days_after_earnings >= 0
        )
        earnings_buffer_cross = bool(earnings_crosses and not event_inside_contract)
        earnings_mode = _text(row.get("earnings_mode"), "avoid").lower()
        legacy_allowed = _bool(row.get("earnings_allowed"), False)
        if earnings_mode not in {"avoid", "acquisition"}:
            earnings_mode = "acquisition" if legacy_allowed else "avoid"
        elif legacy_allowed and earnings_mode == "avoid":
            earnings_mode = "acquisition"
        earnings_trade_approved = _bool(row.get("earnings_trade_approved"), legacy_allowed)
        is_earnings_trade = event_inside_contract
        strategy_type = "EARNINGS_ACQUISITION" if is_earnings_trade else "REGULAR_ACQUISITION"

        if ownership_cfg.get("require_ownership_approved", True) and not ownership_approved:
            policy_failures.append("Company is not approved for long-term ownership")
        if ownership_cfg.get("require_thesis_intact", True) and not thesis_intact:
            policy_failures.append("Ownership thesis is not intact")
        if valuation_confidence < float(ownership_cfg.get("minimum_valuation_confidence", 0)):
            policy_failures.append("Valuation confidence is below the configured minimum")
        if ownership_cfg.get("require_target_entry_price", True) and (
            not np.isfinite(target_entry) or target_entry <= 0
        ):
            policy_failures.append("Target entry price is missing or invalid")

        if is_earnings_trade:
            min_dte = int(earnings_cfg.get("min_dte", profile["min_dte"]))
            max_dte = int(earnings_cfg.get("max_dte", profile["max_dte"]))
            if not (min_dte <= dte <= max_dte):
                economic_failures.append(
                    f"DTE is outside the earnings profile ({min_dte}-{max_dte})"
                )
        elif not (profile["min_dte"] <= dte <= profile["max_dte"]):
            economic_failures.append("DTE is outside the active profile")
        if not (profile["min_abs_delta"] <= abs_delta <= profile["max_abs_delta"]):
            economic_failures.append("Delta is outside the broad search profile")
        if not _bool(row.get("is_otm"), False):
            economic_failures.append("Strike is not below the current stock price")

        if bid < filters["min_bid"]:
            policy_failures.append("Bid is too small for reliable execution")
        if not np.isfinite(spread_pct) or spread_pct > filters["max_spread_pct"]:
            policy_failures.append("Bid-ask spread is too wide")
        if open_interest < filters["min_open_interest"]:
            policy_failures.append("Open interest is too low")
        if volume < filters["min_volume"]:
            policy_failures.append("Option volume is too low")
        if np.isfinite(iv_rv) and iv_rv < filters["min_iv_rv_ratio"]:
            economic_failures.append("IV is not rich enough versus recent realized volatility")
        if filters.get("require_manual_news_clear", True) and not manual_news_clear:
            policy_failures.append("Manual company-news review is not clear")

        if is_earnings_trade:
            if np.isfinite(days_to_earnings) and days_to_earnings < 0:
                policy_failures.append("Earnings date is in the past; refresh the event calendar")
            if earnings_mode != "acquisition" or not earnings_trade_approved:
                policy_failures.append("Earnings acquisition was not explicitly approved")
            if earnings_cfg.get("require_bear_case_price", True) and (
                not np.isfinite(earnings_bear_case) or earnings_bear_case <= 0
            ):
                policy_failures.append("Post-earnings bear-case value is missing or invalid")
            if earnings_cfg.get("require_implied_move", True) and (
                not np.isfinite(implied_move_pct) or implied_move_pct <= 0
            ):
                policy_failures.append("ATM-straddle implied earnings move is unavailable")
            max_after = int(earnings_cfg.get("max_days_after_earnings", 14))
            if np.isfinite(days_after_earnings) and days_after_earnings > max_after:
                economic_failures.append(
                    f"Expiration is more than {max_after} days after earnings"
                )
            effective_target = earnings_bear_case
        else:
            effective_target = target_entry
            if filters.get("require_earnings_clear", True):
                if not earnings_known and filters.get("unknown_earnings_action", "reject") == "reject":
                    policy_failures.append("Next earnings date is unknown")
                elif earnings_buffer_cross or earnings_crosses:
                    policy_failures.append("Option is too close to earnings or crosses the event buffer")

        if np.isfinite(effective_target) and effective_target > 0 and np.isfinite(net_basis):
            target_basis_margin = (effective_target - net_basis) / effective_target
            if net_basis > effective_target:
                if is_earnings_trade:
                    economic_failures.append(
                        "Net assignment basis is above the post-earnings bear-case value"
                    )
                else:
                    economic_failures.append("Net assignment basis is above the target entry price")
            else:
                positives.append(
                    "Net assignment basis is at or below the earnings bear case"
                    if is_earnings_trade
                    else "Net assignment basis is at or below the target price"
                )
        else:
            target_basis_margin = float("nan")

        ordinary_target_margin = (
            (target_entry - net_basis) / target_entry
            if np.isfinite(target_entry) and target_entry > 0 and np.isfinite(net_basis)
            else float("nan")
        )
        earnings_basis_margin = (
            (earnings_bear_case - net_basis) / earnings_bear_case
            if np.isfinite(earnings_bear_case)
            and earnings_bear_case > 0
            and np.isfinite(net_basis)
            else float("nan")
        )
        basis_vs_implied_lower_pct = (
            (implied_lower - net_basis) / spot
            if np.isfinite(implied_lower)
            and np.isfinite(net_basis)
            and np.isfinite(spot)
            and spot > 0
            else float("nan")
        )
        implied_move_vs_historical_median = (
            implied_move_pct / historical_median_move
            if np.isfinite(implied_move_pct)
            and np.isfinite(historical_median_move)
            and historical_median_move > 0
            else float("nan")
        )
        historical_worst_price = (
            spot * (1.0 - historical_worst_drop)
            if np.isfinite(spot)
            and spot > 0
            and np.isfinite(historical_worst_drop)
            and historical_worst_drop >= 0
            else float("nan")
        )
        basis_vs_historical_worst_pct = (
            (historical_worst_price - net_basis) / spot
            if np.isfinite(historical_worst_price)
            and np.isfinite(net_basis)
            and np.isfinite(spot)
            and spot > 0
            else float("nan")
        )

        if is_earnings_trade:
            min_bear_margin = float(earnings_cfg.get("minimum_bear_case_margin", 0.0))
            if np.isfinite(earnings_basis_margin) and earnings_basis_margin < min_bear_margin:
                economic_failures.append(
                    f"Bear-case basis margin is below the required {min_bear_margin:.2%}"
                )
            require_lower = bool(earnings_cfg.get("require_basis_at_or_below_lower_implied", False))
            if np.isfinite(basis_vs_implied_lower_pct):
                if basis_vs_implied_lower_pct >= 0:
                    positives.append("Net basis is at or below the straddle-implied lower price")
                elif require_lower:
                    economic_failures.append(
                        "Net assignment basis is above the straddle-implied lower price"
                    )
                else:
                    warnings.append(
                        "Net basis is above the straddle-implied lower price; bear-case valuation must justify it"
                    )
            if np.isfinite(implied_move_vs_historical_median):
                if implied_move_vs_historical_median >= 1.15:
                    positives.append("Implied earnings move is elevated versus the supplied historical median")
                elif implied_move_vs_historical_median < 0.90:
                    warnings.append("Implied earnings move is below the supplied historical median")
            if np.isfinite(basis_vs_historical_worst_pct):
                if basis_vs_historical_worst_pct >= 0:
                    positives.append("Net basis is below the supplied historical worst earnings price")
                else:
                    warnings.append(
                        "Net basis is above the supplied historical worst earnings price"
                    )

        ticker_min_30d = _number(row.get("ticker_min_30d_roi"))
        ticker_earnings_min = _number(row.get("earnings_min_30d_roi"))
        if is_earnings_trade:
            required_30d_roi = (
                ticker_earnings_min
                if np.isfinite(ticker_earnings_min)
                else float(earnings_cfg.get("target_30d_roi", 0.03))
            )
        else:
            required_30d_roi = (
                ticker_min_30d
                if np.isfinite(ticker_min_30d)
                else float(performance.get("target_30d_roi", 0.02))
            )
        if not np.isfinite(roi_30d) or roi_30d < required_30d_roi:
            economic_failures.append(
                f"30-day-equivalent ROI is below the {required_30d_roi:.2%} target"
            )
        else:
            positives.append("Waiting return meets the applicable 30-day ROI target")

        ticker_min_annualized = _number(row.get("ticker_min_annualized_yield"))
        if np.isfinite(ticker_min_annualized):
            annualized = _number(row.get("annualized_max_yield"))
            if annualized < ticker_min_annualized:
                economic_failures.append("Simple annualized yield is below the ticker-specific floor")

        panic = False
        if np.isfinite(down_atr) and down_atr > entry["panic_down_move_atr"]:
            policy_failures.append("Daily decline is in the panic zone")
            panic = True
        if np.isfinite(drop_5d_atr) and drop_5d_atr > entry["max_5d_drop_atr"]:
            policy_failures.append("Five-day decline indicates a possible falling knife")
            panic = True
        if np.isfinite(price_to_sma50) and price_to_sma50 < entry["hard_min_price_to_sma50"]:
            policy_failures.append("Price is too far below the 50-day average")
            panic = True

        if is_earnings_trade:
            min_before = int(earnings_cfg.get("min_days_before_earnings", 1))
            max_before = int(earnings_cfg.get("max_entry_days_before_earnings", 10))
            event_window_ready = bool(
                np.isfinite(days_to_earnings)
                and min_before <= days_to_earnings <= max_before
            )
            entry_ready = bool(event_window_ready and not panic)
            if not event_window_ready and not policy_failures:
                if np.isfinite(days_to_earnings) and days_to_earnings > max_before:
                    warnings.append(
                        f"Earnings entry window has not opened; rerun within {max_before} days of the report"
                    )
                elif np.isfinite(days_to_earnings) and days_to_earnings < min_before:
                    warnings.append("Earnings report is too near or already passed; refresh the event date")
                else:
                    warnings.append("Earnings timing could not be verified")
            warnings.append(
                "EARNINGS ACQUISITION: IV crush can remove extrinsic value, but a downside gap creates intrinsic value"
            )
        else:
            entry_ready = (
                np.isfinite(down_atr)
                and entry["min_down_move_atr"] <= down_atr <= entry["max_down_move_atr"]
                and np.isfinite(close_off_low)
                and close_off_low >= entry["min_close_off_low_atr"]
                and not panic
            )
            if not entry_ready and not policy_failures:
                if not np.isfinite(down_atr) or down_atr < entry["min_down_move_atr"]:
                    warnings.append("No meaningful red-day premium expansion yet")
                elif down_atr > entry["max_down_move_atr"]:
                    warnings.append("Decline is sharp; wait for stabilization")
                if not np.isfinite(close_off_low) or close_off_low < entry["min_close_off_low_atr"]:
                    warnings.append("Stock is still trading near the session low")

        high_premium_threshold = float(performance.get("high_premium_review_30d_roi", 0.04))
        high_premium_review = bool(np.isfinite(roi_30d) and roi_30d >= high_premium_threshold)
        if high_premium_review:
            warnings.append(
                "HIGH PREMIUM REVIEW: investigate event, distress, skew, and execution before trading"
            )

        margin_score = _linear_score(
            target_basis_margin,
            targets["target_basis_margin_poor"],
            targets["target_basis_margin_excellent"],
        )
        confidence_score = _linear_score(
            valuation_confidence,
            targets["valuation_confidence_poor"],
            targets["valuation_confidence_excellent"],
        )
        priority_score = _linear_score(
            -priority_rank,
            -float(targets["priority_rank_poor"]),
            -float(targets["priority_rank_best"]),
        )
        delta_preference_score = _bell_score(
            abs_delta,
            profile["preferred_abs_delta"],
            profile["delta_preference_width"],
        )
        acquisition_score = (
            0.45 * margin_score
            + 0.30 * confidence_score
            + 0.15 * priority_score
            + 0.10 * delta_preference_score
        )

        waiting_return_score = _linear_score(
            roi_30d,
            targets["roi_30d_poor"],
            targets["roi_30d_excellent"],
        )

        ratio_score = _linear_score(iv_rv, targets["iv_rv_poor"], targets["iv_rv_excellent"])
        history_confidence = min(iv_history_days / max(targets["min_iv_history_days"], 1), 1.0)
        iv_percentile_effective = 50.0 + (float(iv_percentile) - 50.0) * history_confidence
        vol_score = 0.55 * ratio_score + 0.45 * iv_percentile_effective

        if is_earnings_trade:
            target_days = float(earnings_cfg.get("target_entry_days_before_earnings", 3))
            timing_width = float(earnings_cfg.get("entry_timing_width_days", 5))
            timing_score = _bell_score(days_to_earnings, target_days, timing_width)
            implied_buffer_score = _linear_score(
                basis_vs_implied_lower_pct,
                float(earnings_cfg.get("implied_lower_margin_poor", -0.05)),
                float(earnings_cfg.get("implied_lower_margin_excellent", 0.05)),
            )
            entry_score = 0.60 * timing_score + 0.40 * implied_buffer_score
        else:
            red_day_score = _bell_score(
                down_atr,
                entry["ideal_down_move_atr"],
                entry["entry_bell_width"],
            )
            recovery_score = _linear_score(
                close_off_low,
                0.0,
                entry["excellent_close_off_low_atr"],
            )
            entry_score = 0.72 * red_day_score + 0.28 * recovery_score

        price_to_sma_score = _linear_score(
            price_to_sma50,
            targets["price_to_sma50_poor"],
            targets["price_to_sma50_excellent"],
        )
        return20_score = _linear_score(
            _number(row.get("return_20d")),
            targets["return_20d_poor"],
            targets["return_20d_excellent"],
        )
        slope_score = _linear_score(
            _number(row.get("slope20_annualized")),
            targets["slope20_poor"],
            targets["slope20_excellent"],
        )
        trend_score = 0.45 * price_to_sma_score + 0.30 * return20_score + 0.25 * slope_score

        spread_score = _linear_score(
            -spread_pct,
            -filters["max_spread_pct"],
            -targets["excellent_spread_pct"],
        )
        oi_score = _linear_score(
            math.log1p(max(open_interest, 0)),
            math.log1p(filters["min_open_interest"]),
            math.log1p(targets["excellent_open_interest"]),
        )
        volume_score = _linear_score(
            math.log1p(max(volume, 0)),
            math.log1p(filters["min_volume"]),
            math.log1p(targets["excellent_volume"]),
        )
        liquidity_score = 0.45 * spread_score + 0.35 * oi_score + 0.20 * volume_score

        distance_em = _number(row.get("strike_distance_expected_move"))
        breakeven_discount = _number(row.get("breakeven_discount"))
        if is_earnings_trade:
            event_buffer_score = _linear_score(
                basis_vs_implied_lower_pct,
                float(earnings_cfg.get("implied_lower_margin_poor", -0.05)),
                float(earnings_cfg.get("implied_lower_margin_excellent", 0.05)),
            )
            breakeven_score = _linear_score(
                breakeven_discount,
                targets["breakeven_discount_poor"],
                targets["breakeven_discount_excellent"],
            )
            buffer_score = 0.70 * event_buffer_score + 0.30 * breakeven_score
        else:
            distance_score = _linear_score(
                distance_em,
                targets["distance_em_poor"],
                targets["distance_em_excellent"],
            )
            breakeven_score = _linear_score(
                breakeven_discount,
                targets["breakeven_discount_poor"],
                targets["breakeven_discount_excellent"],
            )
            buffer_score = 0.60 * distance_score + 0.40 * breakeven_score

        component_scores = {
            "acquisition_score": acquisition_score,
            "waiting_return_score": waiting_return_score,
            "entry_score": entry_score,
            "trend_score": trend_score,
            "vol_score": vol_score,
            "liquidity_score": liquidity_score,
            "buffer_score": buffer_score,
        }
        total_score = _clamp(
            sum(component_scores[name] * float(weights[name]) for name in component_scores)
        )

        if iv_rv >= targets["iv_rv_excellent"]:
            positives.append("IV is rich versus realized volatility")
        if iv_percentile_effective >= 70:
            positives.append("IV is elevated versus stored history")
        if entry_ready:
            positives.append(
                "Earnings timing window is active"
                if is_earnings_trade
                else "Red-day and stabilization conditions are met"
            )
        if spread_pct <= targets["excellent_spread_pct"]:
            positives.append("Option market is liquid")
        if not is_earnings_trade and distance_em >= targets["distance_em_excellent"]:
            positives.append("Strike has a meaningful implied-move buffer")

        if policy_failures:
            status = "REJECT"
        elif economic_failures:
            status = "NO TRADE"
        elif entry_ready and total_score >= decision["sell_score"]:
            status = "SELL"
        elif total_score >= decision["watch_score"] or not entry_ready:
            status = "WATCH"
        else:
            status = "NO TRADE"

        if status == "WATCH" and not warnings:
            warnings.append("Setup qualifies economically but is waiting for a better entry or score")
        elif status == "NO TRADE" and not economic_failures and not warnings:
            warnings.append("Composite score is below the actionable threshold")

        base_max_contracts = int(max(_number(row.get("max_contracts"), 0), 0))
        max_contracts_allowed = base_max_contracts
        max_ticker_pct_override = float("nan")
        if is_earnings_trade:
            explicit_earnings_max = _number(row.get("earnings_max_contracts"))
            if np.isfinite(explicit_earnings_max):
                max_contracts_allowed = max(0, min(base_max_contracts, int(explicit_earnings_max)))
            elif base_max_contracts > 0:
                multiplier = max(float(earnings_cfg.get("position_size_multiplier", 0.50)), 0.0)
                max_contracts_allowed = min(
                    base_max_contracts,
                    max(1, int(math.floor(base_max_contracts * multiplier))),
                )
            max_ticker_pct_override = float(earnings_cfg.get("max_ticker_pct", 0.125))

        row.update(component_scores)
        row.update(
            {
                "strategy_type": strategy_type,
                "event_inside_contract": event_inside_contract,
                "earnings_buffer_cross": earnings_buffer_cross,
                "earnings_mode_effective": earnings_mode,
                "effective_target_price": effective_target,
                "ordinary_target_basis_margin": ordinary_target_margin,
                "earnings_basis_margin": earnings_basis_margin,
                "target_basis_margin": target_basis_margin,
                "basis_vs_implied_lower_pct": basis_vs_implied_lower_pct,
                "implied_move_vs_historical_median": implied_move_vs_historical_median,
                "historical_worst_earnings_price": historical_worst_price,
                "basis_vs_historical_worst_pct": basis_vs_historical_worst_pct,
                "minimum_required_30d_roi": required_30d_roi,
                "required_30d_roi": required_30d_roi,
                "roi_excess_vs_target": roi_30d - required_30d_roi
                if np.isfinite(roi_30d)
                else np.nan,
                "high_premium_review": high_premium_review,
                "iv_percentile": float(iv_percentile),
                "iv_percentile_effective": float(iv_percentile_effective),
                "iv_history_days": int(iv_history_days),
                "entry_ready": bool(entry_ready),
                "max_contracts_allowed": int(max_contracts_allowed),
                "max_ticker_pct_override": max_ticker_pct_override,
                "policy_failure_count": len(policy_failures),
                "economic_failure_count": len(economic_failures),
                "hard_failure_count": len(policy_failures) + len(economic_failures),
                "decision_score": round(total_score, 2),
                "decision": status,
                "policy_failures": "; ".join(policy_failures),
                "economic_failures": "; ".join(economic_failures),
                "failure_reasons": "; ".join(policy_failures + economic_failures),
                "warnings": "; ".join(dict.fromkeys(warnings)),
                "positive_signals": "; ".join(dict.fromkeys(positives)),
            }
        )
        rows.append(row)

    return pd.DataFrame(rows)
