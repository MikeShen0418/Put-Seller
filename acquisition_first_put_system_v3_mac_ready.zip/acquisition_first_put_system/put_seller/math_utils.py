from __future__ import annotations

import math


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def _black_scholes_common(
    spot: float,
    strike: float,
    time_years: float,
    rate: float,
    volatility: float,
    dividend_yield: float,
) -> tuple[float, float, float, float, float]:
    if min(spot, strike, time_years, volatility) <= 0:
        raise ValueError("spot, strike, time_years and volatility must be positive")
    sqrt_t = math.sqrt(time_years)
    d1 = (
        math.log(spot / strike)
        + (rate - dividend_yield + 0.5 * volatility * volatility) * time_years
    ) / (volatility * sqrt_t)
    d2 = d1 - volatility * sqrt_t
    discount_r = math.exp(-rate * time_years)
    discount_q = math.exp(-dividend_yield * time_years)
    return sqrt_t, d1, d2, discount_r, discount_q


def black_scholes_put(
    spot: float,
    strike: float,
    time_years: float,
    rate: float,
    volatility: float,
    dividend_yield: float = 0.0,
) -> dict[str, float]:
    """Return European put price and Greeks for deterministic demo generation."""
    sqrt_t, d1, d2, discount_r, discount_q = _black_scholes_common(
        spot, strike, time_years, rate, volatility, dividend_yield
    )
    price = strike * discount_r * norm_cdf(-d2) - spot * discount_q * norm_cdf(-d1)
    delta = -discount_q * norm_cdf(-d1)
    gamma = discount_q * norm_pdf(d1) / (spot * volatility * sqrt_t)
    vega = spot * discount_q * norm_pdf(d1) * sqrt_t / 100.0
    theta_annual = (
        -spot * discount_q * norm_pdf(d1) * volatility / (2.0 * sqrt_t)
        + rate * strike * discount_r * norm_cdf(-d2)
        - dividend_yield * spot * discount_q * norm_cdf(-d1)
    )
    return {
        "price": max(price, 0.0),
        "delta": delta,
        "gamma": gamma,
        "theta": theta_annual / 365.0,
        "vega": vega,
    }


def black_scholes_call(
    spot: float,
    strike: float,
    time_years: float,
    rate: float,
    volatility: float,
    dividend_yield: float = 0.0,
) -> dict[str, float]:
    """Return European call price and Greeks for deterministic demo generation."""
    sqrt_t, d1, d2, discount_r, discount_q = _black_scholes_common(
        spot, strike, time_years, rate, volatility, dividend_yield
    )
    price = spot * discount_q * norm_cdf(d1) - strike * discount_r * norm_cdf(d2)
    delta = discount_q * norm_cdf(d1)
    gamma = discount_q * norm_pdf(d1) / (spot * volatility * sqrt_t)
    vega = spot * discount_q * norm_pdf(d1) * sqrt_t / 100.0
    theta_annual = (
        -spot * discount_q * norm_pdf(d1) * volatility / (2.0 * sqrt_t)
        - rate * strike * discount_r * norm_cdf(d2)
        + dividend_yield * spot * discount_q * norm_cdf(d1)
    )
    return {
        "price": max(price, 0.0),
        "delta": delta,
        "gamma": gamma,
        "theta": theta_annual / 365.0,
        "vega": vega,
    }
