from __future__ import annotations

import shutil
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import resolve_path
from .earnings import build_earnings_scenarios
from .features import (
    compute_atm_straddle_metrics,
    compute_underlying_features,
    enrich_option_chain,
)
from .optimizer import optimize_portfolio
from .providers.base import MarketDataProvider
from .providers.demo import DemoProvider
from .report import render_html_report, write_run_summary
from .scoring import score_candidates
from .store import IVSnapshotStore


@dataclass
class PipelineResult:
    underlying_snapshot: pd.DataFrame
    all_candidates: pd.DataFrame
    best_by_ticker: pd.DataFrame
    allocation: pd.DataFrame
    earnings_scenarios: pd.DataFrame
    portfolio_summary: dict[str, float]
    output_dir: Path
    report_path: Path


def _parse_bool(value: Any, default: bool = False) -> bool:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _parse_optional_date(value: Any) -> date | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip()
    if not text:
        return None
    parsed = pd.to_datetime(text, errors="coerce")
    return None if pd.isna(parsed) else parsed.date()


def _parse_optional_float(value: Any) -> float | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        parsed = float(text)
    except ValueError:
        return None
    return parsed if np.isfinite(parsed) else None


def _parse_int(value: Any, default: int) -> int:
    parsed = _parse_optional_float(value)
    return default if parsed is None else max(int(parsed), 0)


def _parse_text(value: Any, default: str = "") -> str:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    text = str(value).strip()
    return text or default


def _select_best(scored: pd.DataFrame) -> pd.Series:
    rank = {"SELL": 5, "WATCH": 4, "NO TRADE": 3, "REJECT": 2, "ERROR": 0}
    temp = scored.copy()
    temp["_rank"] = temp["decision"].map(rank).fillna(0)
    for column, default in [
        ("policy_failure_count", 0),
        ("economic_failure_count", 0),
        ("acquisition_score", 0.0),
        ("roi_30d_equivalent", 0.0),
        ("open_interest", 0.0),
    ]:
        if column not in temp.columns:
            temp[column] = default
    temp = temp.sort_values(
        [
            "_rank",
            "policy_failure_count",
            "economic_failure_count",
            "decision_score",
            "acquisition_score",
            "roi_30d_equivalent",
            "open_interest",
        ],
        ascending=[False, True, True, False, False, False, False],
    )
    return temp.iloc[0].drop(labels=["_rank"])


def _iv_proxy(scored_or_enriched: pd.DataFrame, target_dte: int) -> float:
    if scored_or_enriched.empty:
        return float("nan")
    frame = scored_or_enriched.copy()
    subset = frame.loc[frame["abs_delta"].between(0.10, 0.35, inclusive="both")]
    if subset.empty:
        subset = frame
    subset = subset.assign(_dte_gap=(subset["dte"] - target_dte).abs())
    closest = subset.loc[subset["_dte_gap"] == subset["_dte_gap"].min()]
    return float(closest["iv"].median())


def _watchlist_metadata(watch_row: pd.Series, config: dict[str, Any]) -> dict[str, Any]:
    default_max = int(config["capital"]["max_contracts_per_ticker"])
    ownership_approved = _parse_bool(watch_row.get("ownership_approved"), False)
    thesis_intact = _parse_bool(watch_row.get("thesis_intact"), True)
    target_entry_price = _parse_optional_float(watch_row.get("target_entry_price"))
    desired_shares = _parse_int(watch_row.get("desired_shares"), 100)
    max_shares = _parse_int(watch_row.get("max_shares"), desired_shares or 100)
    explicit_max_contracts = _parse_int(watch_row.get("max_contracts"), default_max)
    share_cap_contracts = max_shares // 100
    max_contracts = (
        min(explicit_max_contracts, share_cap_contracts) if share_cap_contracts > 0 else 0
    )

    legacy_earnings_allowed = _parse_bool(watch_row.get("earnings_allowed"), False)
    earnings_mode = _parse_text(watch_row.get("earnings_mode"), "").lower()
    if earnings_mode not in {"avoid", "acquisition"}:
        earnings_mode = "acquisition" if legacy_earnings_allowed else "avoid"
    earnings_trade_approved = _parse_bool(
        watch_row.get("earnings_trade_approved"), legacy_earnings_allowed
    )

    return {
        "ownership_approved": ownership_approved,
        "thesis_intact": thesis_intact,
        "target_entry_price": target_entry_price,
        "desired_shares": desired_shares,
        "max_shares": max_shares,
        "max_contracts": max_contracts,
        "priority_rank": _parse_int(watch_row.get("priority_rank"), 10),
        "valuation_confidence": _parse_optional_float(watch_row.get("valuation_confidence"))
        or 50.0,
        "manual_news_clear": _parse_bool(watch_row.get("manual_news_clear"), False),
        "earnings_allowed": legacy_earnings_allowed,
        "earnings_mode": earnings_mode,
        "earnings_trade_approved": earnings_trade_approved,
        "earnings_bear_case_price": _parse_optional_float(
            watch_row.get("earnings_bear_case_price")
        ),
        "earnings_min_30d_roi": _parse_optional_float(
            watch_row.get("earnings_min_30d_roi")
        ),
        "earnings_max_contracts": _parse_optional_float(
            watch_row.get("earnings_max_contracts")
        ),
        "historical_median_earnings_move_pct": _parse_optional_float(
            watch_row.get("historical_median_earnings_move_pct")
        ),
        "historical_worst_earnings_drop_pct": _parse_optional_float(
            watch_row.get("historical_worst_earnings_drop_pct")
        ),
        "manual_earnings_date": _parse_optional_date(watch_row.get("manual_earnings_date")),
        "min_30d_roi": _parse_optional_float(watch_row.get("min_30d_roi")),
        "min_annualized_yield": _parse_optional_float(
            watch_row.get("min_annualized_yield")
        ),
        "sector": watch_row.get("sector", ""),
        "thesis": watch_row.get("thesis", ""),
    }


def run_pipeline(
    provider: MarketDataProvider,
    config: dict[str, Any],
    config_path: str | Path,
    mode: str,
    output_root_override: str | Path | None = None,
) -> PipelineResult:
    config_path = Path(config_path).resolve()
    watchlist_path = resolve_path(config_path, config["watchlist_path"])
    snapshot_setting = (
        config.get("demo_snapshot_store_path", config["snapshot_store_path"])
        if mode.lower() == "demo"
        else config["snapshot_store_path"]
    )
    snapshot_path = resolve_path(config_path, snapshot_setting)
    output_root = (
        Path(output_root_override).resolve()
        if output_root_override is not None
        else resolve_path(config_path, config["output_root"])
    )
    output_root.mkdir(parents=True, exist_ok=True)

    watchlist = pd.read_csv(watchlist_path)
    required = {"ticker", "enabled"}
    missing = required.difference(watchlist.columns)
    if missing:
        raise ValueError(f"Watchlist is missing columns: {sorted(missing)}")
    watchlist["ticker"] = watchlist["ticker"].astype(str).str.upper().str.strip()
    watchlist = watchlist.loc[
        watchlist["enabled"].map(lambda value: _parse_bool(value, True))
    ]
    if watchlist.empty:
        raise ValueError("The enabled watchlist is empty")

    store = IVSnapshotStore(snapshot_path)
    if isinstance(provider, DemoProvider):
        for ticker in watchlist["ticker"]:
            store.seed_if_missing(provider.synthetic_iv_history(ticker))

    underlying_rows: list[dict[str, Any]] = []
    candidate_frames: list[pd.DataFrame] = []
    best_rows: list[dict[str, Any]] = []
    snapshot_records: list[dict[str, Any]] = []

    for _, watch_row in watchlist.iterrows():
        ticker = str(watch_row["ticker"]).upper()
        metadata = _watchlist_metadata(watch_row, config)
        try:
            quote = provider.get_quote(ticker)
            quote_as_of = quote.get("as_of")
            as_of = quote_as_of.date() if isinstance(quote_as_of, datetime) else date.today()
            history = provider.get_history(ticker)
            underlying = compute_underlying_features(history, quote)

            earnings_date = metadata["manual_earnings_date"] or provider.get_next_earnings(ticker)
            profile = config["profile"]
            earnings_cfg = config.get("earnings_acquisition", {})
            regular_min_dte = int(profile["min_dte"])
            regular_max_dte = int(profile["max_dte"])
            use_event_window = metadata["earnings_mode"] == "acquisition"
            event_min_dte = int(earnings_cfg.get("min_dte", regular_min_dte))
            event_max_dte = int(earnings_cfg.get("max_dte", regular_max_dte))

            def _eligible_expiration(expiry: date) -> bool:
                dte = (expiry - as_of).days
                regular_ok = regular_min_dte <= dte <= regular_max_dte
                event_ok = use_event_window and event_min_dte <= dte <= event_max_dte
                return regular_ok or event_ok

            expirations = [
                expiry
                for expiry in provider.get_expirations(ticker)
                if _eligible_expiration(expiry)
            ]
            if not expirations:
                window_text = f"{regular_min_dte}-{regular_max_dte} DTE"
                if use_event_window:
                    window_text += f" or earnings {event_min_dte}-{event_max_dte} DTE"
                raise ValueError(
                    f"No expirations found in {window_text} window"
                )

            complete_chains: list[pd.DataFrame] = []
            for expiration in expirations:
                chain = provider.get_option_chain(ticker, expiration, option_type=None)
                if not chain.empty:
                    complete_chains.append(chain)
            if not complete_chains:
                raise ValueError("Option chains were empty for all eligible expirations")

            complete_chain = pd.concat(complete_chains, ignore_index=True)
            event_metrics = compute_atm_straddle_metrics(
                complete_chain, float(quote["spot"])
            )
            put_chain = complete_chain.loc[
                complete_chain["option_type"].astype(str).str.lower().eq("put")
            ].copy()
            if put_chain.empty:
                raise ValueError("Put chains were empty for all eligible expirations")

            enriched = enrich_option_chain(
                chain=put_chain,
                quote=quote,
                underlying=underlying,
                as_of=as_of,
                earnings_date=earnings_date,
                execution_fraction_from_bid=config["decision"][
                    "execution_fraction_from_bid"
                ],
                earnings_buffer_days=config["decision"]["earnings_buffer_days"],
                include_collateral_interest=config.get("performance", {}).get(
                    "include_collateral_interest", False
                ),
                collateral_annual_yield=config.get("performance", {}).get(
                    "collateral_annual_yield", 0.0
                ),
                event_metrics=event_metrics,
            )
            for key, value in metadata.items():
                if key == "manual_earnings_date":
                    continue
                enriched[key] = value
            enriched["ticker_min_30d_roi"] = metadata["min_30d_roi"]
            enriched["ticker_min_annualized_yield"] = metadata[
                "min_annualized_yield"
            ]

            iv_target_dte = (
                int(earnings_cfg.get("target_dte", profile["target_dte"]))
                if use_event_window
                else int(profile["target_dte"])
            )
            iv_proxy = _iv_proxy(enriched, iv_target_dte)
            iv_percentile, iv_history_days = store.percentile(ticker, iv_proxy)
            scored = score_candidates(
                candidates=enriched,
                config=config,
                manual_news_clear=metadata["manual_news_clear"],
                iv_percentile=iv_percentile,
                iv_history_days=iv_history_days,
            )
            scored["data_mode"] = quote.get("data_mode", mode)
            candidate_frames.append(scored)
            best = _select_best(scored)
            best_rows.append(best.to_dict())

            nearest_event_metrics: dict[str, Any] = {}
            if not event_metrics.empty:
                metrics = event_metrics.copy()
                metric_target_dte = (
                    int(earnings_cfg.get("target_dte", profile["target_dte"]))
                    if use_event_window
                    else int(profile["target_dte"])
                )
                metrics["_dte_gap"] = metrics["expiration"].map(
                    lambda expiration: abs((expiration - as_of).days - metric_target_dte)
                )
                nearest = metrics.sort_values("_dte_gap").iloc[0]
                nearest_event_metrics = {
                    "target_expiry_atm_strike": nearest.get("atm_strike"),
                    "target_expiry_implied_move_pct": nearest.get("implied_move_pct"),
                    "target_expiry_implied_lower_price": nearest.get("implied_lower_price"),
                    "target_expiry_implied_upper_price": nearest.get("implied_upper_price"),
                }

            underlying_rows.append(
                {
                    "ticker": ticker,
                    **underlying,
                    "iv_proxy": iv_proxy,
                    "iv_percentile": iv_percentile,
                    "iv_history_days": iv_history_days,
                    "earnings_date": earnings_date,
                    **nearest_event_metrics,
                    **{
                        key: value
                        for key, value in metadata.items()
                        if key != "manual_earnings_date"
                    },
                    "data_mode": quote.get("data_mode", mode),
                    "error": "",
                }
            )
            snapshot_records.append(
                {
                    "date": as_of,
                    "ticker": ticker,
                    "iv_proxy": iv_proxy,
                    "source": quote.get("data_mode", mode),
                }
            )
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            underlying_rows.append(
                {
                    "ticker": ticker,
                    **{
                        key: value
                        for key, value in metadata.items()
                        if key != "manual_earnings_date"
                    },
                    "data_mode": mode,
                    "error": message,
                }
            )
            best_rows.append(
                {
                    "ticker": ticker,
                    "decision": "ERROR",
                    "decision_score": 0.0,
                    "failure_reasons": message,
                    "warnings": "",
                    "positive_signals": "",
                    **{
                        key: value
                        for key, value in metadata.items()
                        if key != "manual_earnings_date"
                    },
                }
            )

    store.append(snapshot_records)

    underlying_snapshot = pd.DataFrame(underlying_rows)
    all_candidates = (
        pd.DataFrame.from_records(
            record
            for frame in candidate_frames
            for record in frame.to_dict(orient="records")
        )
        if candidate_frames
        else pd.DataFrame()
    )
    best_by_ticker = pd.DataFrame(best_rows)
    if not best_by_ticker.empty:
        decision_rank = {"SELL": 0, "WATCH": 1, "NO TRADE": 2, "REJECT": 3, "ERROR": 4}
        best_by_ticker["_sort"] = best_by_ticker["decision"].map(decision_rank).fillna(9)
        best_by_ticker = (
            best_by_ticker.sort_values(
                ["_sort", "decision_score"], ascending=[True, False]
            )
            .drop(columns="_sort")
            .reset_index(drop=True)
        )

    allocation, portfolio_summary = optimize_portfolio(best_by_ticker, config)
    earnings_scenarios = build_earnings_scenarios(best_by_ticker, config)

    run_time = datetime.now(timezone.utc)
    run_id = run_time.strftime("run_%Y%m%d_%H%M%S_%fZ")
    output_dir = output_root / run_id
    output_dir.mkdir(parents=True, exist_ok=False)

    underlying_snapshot.to_csv(output_dir / "underlying_snapshot.csv", index=False)
    all_candidates.to_csv(output_dir / "all_candidates.csv", index=False)
    best_by_ticker.to_csv(output_dir / "best_by_ticker.csv", index=False)
    shortlist_columns = [
        "ticker",
        "decision",
        "strategy_type",
        "decision_score",
        "spot",
        "target_entry_price",
        "earnings_bear_case_price",
        "effective_target_price",
        "earnings_date",
        "expiration",
        "dte",
        "days_to_earnings",
        "days_after_earnings",
        "strike",
        "abs_delta",
        "estimated_fill",
        "cash_required",
        "max_cycle_roi",
        "roi_30d_equivalent",
        "required_30d_roi",
        "net_assignment_basis",
        "target_basis_margin",
        "implied_move_pct",
        "implied_lower_price",
        "basis_vs_implied_lower_pct",
        "implied_move_vs_historical_median",
        "historical_worst_earnings_price",
        "stock_equal_roi_price",
        "iv",
        "iv_rv_ratio",
        "high_premium_review",
        "failure_reasons",
        "warnings",
    ]
    best_by_ticker[
        [c for c in shortlist_columns if c in best_by_ticker.columns]
    ].to_csv(output_dir / "trade_shortlist.csv", index=False)
    allocation.to_csv(output_dir / "portfolio_allocation.csv", index=False)
    earnings_scenarios.to_csv(output_dir / "earnings_scenarios.csv", index=False)

    report_path = output_dir / "decision_report.html"
    render_html_report(
        output_path=report_path,
        mode=mode,
        run_timestamp=run_time.isoformat(),
        profile_name=config["profile_name"],
        best_by_ticker=best_by_ticker,
        underlying_snapshot=underlying_snapshot,
        allocation=allocation,
        earnings_scenarios=earnings_scenarios,
        portfolio_summary=portfolio_summary,
        config=config,
    )
    strategy_counts = (
        best_by_ticker.get("strategy_type", pd.Series(dtype=str)).value_counts().to_dict()
    )
    write_run_summary(
        output_dir / "run_summary.json",
        {
            "run_timestamp": run_time.isoformat(),
            "mode": mode,
            "profile": config["profile_name"],
            "strategy": "acquisition-first cash-secured puts with separate earnings-acquisition mode",
            "portfolio_summary": portfolio_summary,
            "decision_counts": best_by_ticker.get(
                "decision", pd.Series(dtype=str)
            ).value_counts().to_dict(),
            "strategy_counts": strategy_counts,
            "earnings_scenario_rows": int(len(earnings_scenarios)),
            "watchlist_path": str(config.get("watchlist_path", watchlist_path)),
            "snapshot_store_path": str(snapshot_setting),
        },
    )

    latest_dir = output_root / "latest"
    if latest_dir.exists():
        shutil.rmtree(latest_dir)
    shutil.copytree(output_dir, latest_dir)

    return PipelineResult(
        underlying_snapshot=underlying_snapshot,
        all_candidates=all_candidates,
        best_by_ticker=best_by_ticker,
        allocation=allocation,
        earnings_scenarios=earnings_scenarios,
        portfolio_summary=portfolio_summary,
        output_dir=output_dir,
        report_path=report_path,
    )
