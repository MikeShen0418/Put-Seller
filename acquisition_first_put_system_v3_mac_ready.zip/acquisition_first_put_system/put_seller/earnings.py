from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np
import pandas as pd

from .math_utils import black_scholes_put


SCENARIO_NOTE = (
    "Illustrative Black-Scholes reprice after earnings; not a forecast. "
    "It ignores American exercise, dividends, skew changes, jumps after the event, and execution costs."
)


def _number(value: Any, default: float = float("nan")) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if np.isfinite(result) else default


def _date(value: Any) -> date | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    parsed = pd.to_datetime(value, errors="coerce")
    return None if pd.isna(parsed) else parsed.date()


def _add_scenario(
    scenarios: list[tuple[str, float]],
    name: str,
    price: float,
) -> None:
    if not np.isfinite(price) or price <= 0:
        return
    for existing_name, existing_price in scenarios:
        if existing_name == name or abs(existing_price - price) < 1e-8:
            return
    scenarios.append((name, float(price)))


def build_earnings_scenarios(
    best_by_ticker: pd.DataFrame,
    config: dict[str, Any],
) -> pd.DataFrame:
    """Build event outcome scenarios for selected earnings-acquisition puts.

    Two views are shown:
    1) modeled post-earnings mark-to-market after a configurable IV crush; and
    2) expiration payoff, which is independent of IV.
    """
    columns = [
        "ticker",
        "decision",
        "strategy_type",
        "expiration",
        "earnings_date",
        "scenario",
        "scenario_stock_price",
        "stock_return_from_entry",
        "stock_pnl_per_100_shares",
        "assumed_post_event_iv",
        "post_event_dte",
        "modeled_put_close_cost",
        "modeled_short_put_pnl_per_share",
        "modeled_short_put_pnl_per_contract",
        "modeled_short_put_roi_on_secured_cash",
        "expiration_short_put_pnl_per_share",
        "expiration_short_put_pnl_per_contract",
        "expiration_short_put_roi_on_secured_cash",
        "short_put_minus_stock_pnl_at_expiration",
        "scenario_note",
    ]
    if best_by_ticker.empty or "strategy_type" not in best_by_ticker.columns:
        return pd.DataFrame(columns=columns)

    earnings_cfg = config.get("earnings_acquisition", {})
    assumed_crush = max(float(earnings_cfg.get("assumed_iv_crush_points", 0.15)), 0.0)
    min_post_iv = max(float(earnings_cfg.get("minimum_post_event_iv", 0.20)), 0.01)
    rate = float(earnings_cfg.get("scenario_risk_free_rate", 0.04))

    rows: list[dict[str, Any]] = []
    event_mask = best_by_ticker["strategy_type"].astype(str).eq("EARNINGS_ACQUISITION")
    if "earnings_trade_approved" in best_by_ticker.columns:
        approved = best_by_ticker["earnings_trade_approved"].map(
            lambda value: bool(value) if isinstance(value, (bool, np.bool_)) else str(value).strip().lower() in {"1", "true", "yes", "y"}
        )
        event_mask &= approved
    if "earnings_bear_case_price" in best_by_ticker.columns:
        bear_values = pd.to_numeric(best_by_ticker["earnings_bear_case_price"], errors="coerce")
        event_mask &= bear_values.gt(0)
    event_rows = best_by_ticker.loc[event_mask]
    for _, source in event_rows.iterrows():
        spot = _number(source.get("spot"))
        strike = _number(source.get("strike"))
        premium = _number(source.get("estimated_fill"))
        iv = _number(source.get("iv"))
        expiration = _date(source.get("expiration"))
        earnings_date = _date(source.get("earnings_date"))
        if not all(np.isfinite(value) and value > 0 for value in [spot, strike, premium, iv]):
            continue
        if expiration is None or earnings_date is None:
            continue

        implied_move = _number(source.get("implied_move_pct"))
        lower_implied = _number(source.get("implied_lower_price"))
        upper_implied = _number(source.get("implied_upper_price"))
        bear_case = _number(source.get("earnings_bear_case_price"))
        worst_drop = _number(source.get("historical_worst_earnings_drop_pct"))

        scenarios: list[tuple[str, float]] = []
        _add_scenario(scenarios, "UPPER IMPLIED MOVE", upper_implied)
        _add_scenario(scenarios, "UNCHANGED", spot)
        _add_scenario(scenarios, "LOWER IMPLIED MOVE", lower_implied)
        _add_scenario(scenarios, "BEAR-CASE VALUE", bear_case)
        if np.isfinite(worst_drop) and worst_drop >= 0:
            _add_scenario(scenarios, "HISTORICAL WORST DROP", spot * (1.0 - worst_drop))
        if not scenarios and np.isfinite(implied_move):
            _add_scenario(scenarios, "UPPER IMPLIED MOVE", spot * (1.0 + implied_move))
            _add_scenario(scenarios, "UNCHANGED", spot)
            _add_scenario(scenarios, "LOWER IMPLIED MOVE", spot * (1.0 - implied_move))

        post_event_dte = max((expiration - earnings_date).days - 1, 1)
        post_event_iv = max(iv - assumed_crush, min_post_iv)
        for scenario_name, scenario_price in scenarios:
            try:
                modeled_close = black_scholes_put(
                    spot=scenario_price,
                    strike=strike,
                    time_years=post_event_dte / 365.0,
                    rate=rate,
                    volatility=post_event_iv,
                )["price"]
            except ValueError:
                modeled_close = float("nan")

            modeled_pnl = premium - modeled_close if np.isfinite(modeled_close) else np.nan
            expiration_pnl = premium - max(strike - scenario_price, 0.0)
            stock_pnl = (scenario_price - spot) * 100.0
            rows.append(
                {
                    "ticker": source.get("ticker", ""),
                    "decision": source.get("decision", ""),
                    "strategy_type": source.get("strategy_type", ""),
                    "expiration": expiration,
                    "earnings_date": earnings_date,
                    "scenario": scenario_name,
                    "scenario_stock_price": scenario_price,
                    "stock_return_from_entry": scenario_price / spot - 1.0,
                    "stock_pnl_per_100_shares": stock_pnl,
                    "assumed_post_event_iv": post_event_iv,
                    "post_event_dte": post_event_dte,
                    "modeled_put_close_cost": modeled_close,
                    "modeled_short_put_pnl_per_share": modeled_pnl,
                    "modeled_short_put_pnl_per_contract": modeled_pnl * 100.0
                    if np.isfinite(modeled_pnl)
                    else np.nan,
                    "modeled_short_put_roi_on_secured_cash": modeled_pnl / strike
                    if np.isfinite(modeled_pnl)
                    else np.nan,
                    "expiration_short_put_pnl_per_share": expiration_pnl,
                    "expiration_short_put_pnl_per_contract": expiration_pnl * 100.0,
                    "expiration_short_put_roi_on_secured_cash": expiration_pnl / strike,
                    "short_put_minus_stock_pnl_at_expiration": expiration_pnl * 100.0
                    - stock_pnl,
                    "scenario_note": SCENARIO_NOTE,
                }
            )
    return pd.DataFrame(rows, columns=columns)
