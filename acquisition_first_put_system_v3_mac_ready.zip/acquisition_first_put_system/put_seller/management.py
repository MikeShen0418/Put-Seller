from __future__ import annotations

import html
import shutil
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import resolve_path
from .providers.base import MarketDataProvider


@dataclass
class ManagementResult:
    actions: pd.DataFrame
    output_dir: Path
    report_path: Path


def _bool(value: Any, default: bool = False) -> bool:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _float(value: Any, default: float = float("nan")) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if np.isfinite(result) else default


def _int(value: Any, default: int = 0) -> int:
    number = _float(value)
    return default if not np.isfinite(number) else max(int(number), 0)


def _date(value: Any) -> date | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip()
    if not text or text.upper() == "YYYY-MM-DD":
        return None
    parsed = pd.to_datetime(text, errors="coerce")
    return None if pd.isna(parsed) else parsed.date()


def _nearest_contract(chain: pd.DataFrame, strike: float) -> pd.Series | None:
    if chain.empty or not np.isfinite(strike):
        return None
    frame = chain.copy()
    frame["_distance"] = (pd.to_numeric(frame["strike"], errors="coerce") - strike).abs()
    frame = frame.dropna(subset=["_distance"])
    if frame.empty:
        return None
    return frame.sort_values(["_distance", "open_interest"], ascending=[True, False]).iloc[0]


def _analyze_short_put(
    row: pd.Series,
    provider: MarketDataProvider,
    config: dict[str, Any],
) -> dict[str, Any]:
    ticker = str(row["ticker"]).upper()
    quote = provider.get_quote(ticker)
    spot = float(quote["spot"])
    as_of = quote.get("as_of")
    as_of_date = as_of.date() if isinstance(as_of, datetime) else date.today()
    strike = _float(row.get("strike"))
    expiration = _date(row.get("expiration"))
    premium_received = _float(row.get("premium_received"))
    contracts = max(_int(row.get("contracts"), 1), 1)
    thesis_intact = _bool(row.get("thesis_intact"), True)
    still_want = _bool(row.get("still_want_shares"), True)
    news_clear = _bool(row.get("manual_news_clear"), False)

    if expiration is None or not np.isfinite(strike) or not np.isfinite(premium_received):
        raise ValueError("Short put requires strike, expiration, and premium_received")

    chain = provider.get_option_chain(ticker, expiration, option_type="put")
    contract = _nearest_contract(chain, strike)
    if contract is None:
        raise ValueError("Could not locate the short put in the option chain")

    current_close_cost = float(contract["ask"])
    dte = max((expiration - as_of_date).days, 0)
    abs_delta = abs(float(contract["delta"]))
    intrinsic = max(strike - spot, 0.0)
    extrinsic = max(current_close_cost - intrinsic, 0.0)
    captured_pct = (
        (premium_received - current_close_cost) / premium_received
        if premium_received > 0
        else float("nan")
    )
    mtm_pnl = (premium_received - current_close_cost) * 100.0 * contracts
    breakeven = strike - premium_received
    cfg = config.get("position_management", {})
    take_profit = float(cfg.get("take_profit_fraction", 0.65))
    assignment_dte = int(cfg.get("assignment_decision_dte", 3))
    roll_delta = float(cfg.get("roll_review_abs_delta", 0.55))
    near_strike_pct = float(cfg.get("near_strike_pct", 0.015))

    if not thesis_intact or not news_clear:
        action = "CLOSE PUT"
        reason = "The ownership thesis or manual news check is no longer clear."
    elif not still_want:
        action = "CLOSE PUT"
        reason = "You no longer want the shares; remove the assignment obligation."
    elif np.isfinite(captured_pct) and captured_pct >= take_profit and current_close_cost < premium_received:
        action = "TAKE PROFIT"
        reason = f"Approximately {captured_pct:.0%} of the original premium has been captured."
    elif dte <= assignment_dte and spot < strike:
        action = "ACCEPT ASSIGNMENT"
        reason = "The put is in the money near expiration and you still want the shares."
    elif dte <= assignment_dte and abs(spot - strike) / max(spot, 0.01) <= near_strike_pct:
        action = "DECIDE BEFORE EXPIRY"
        reason = "The stock is near the strike; close for certainty or deliberately accept assignment risk."
    elif spot < strike and abs_delta >= roll_delta:
        action = "HOLD FOR ASSIGNMENT"
        reason = "Assignment is increasingly likely. Review a roll only if the replacement put independently qualifies."
    else:
        action = "HOLD"
        reason = "The thesis is intact and the position has not reached a management trigger."

    return {
        "position_type": "short_put",
        "ticker": ticker,
        "action": action,
        "reason": reason,
        "spot": spot,
        "contracts": contracts,
        "strike": strike,
        "expiration": expiration,
        "dte": dte,
        "premium_received": premium_received,
        "current_close_cost": current_close_cost,
        "profit_captured_pct": captured_pct,
        "mark_to_market_pnl": mtm_pnl,
        "abs_delta": abs_delta,
        "intrinsic_value": intrinsic,
        "extrinsic_value": extrinsic,
        "assignment_basis": breakeven,
        "stock_vs_basis": spot - breakeven,
        "selected_call_strike": np.nan,
        "selected_call_premium": np.nan,
        "selected_call_30d_roi": np.nan,
        "effective_exit_if_called": np.nan,
        "notes": row.get("notes", ""),
    }


def _covered_call_candidates(
    ticker: str,
    spot: float,
    adjusted_basis: float,
    min_exit: float,
    provider: MarketDataProvider,
    config: dict[str, Any],
    as_of_date: date,
) -> pd.DataFrame:
    mgmt = config.get("position_management", {})
    execution = config.get("covered_call_execution", {})
    min_dte = int(mgmt.get("covered_call_min_dte", 21))
    max_dte = int(mgmt.get("covered_call_max_dte", 45))
    min_delta = float(mgmt.get("covered_call_min_abs_delta", 0.10))
    max_delta = float(mgmt.get("covered_call_max_abs_delta", 0.35))
    fraction = float(execution.get("execution_fraction_from_bid", 0.35))
    next_earnings = provider.get_next_earnings(ticker)

    frames: list[pd.DataFrame] = []
    for expiry in provider.get_expirations(ticker):
        dte = (expiry - as_of_date).days
        if not (min_dte <= dte <= max_dte):
            continue
        if mgmt.get("covered_call_require_earnings_clear", True):
            if next_earnings is None or next_earnings <= expiry:
                continue
        chain = provider.get_option_chain(ticker, expiry, option_type="call")
        if chain.empty:
            continue
        chain = chain.copy()
        chain["dte"] = dte
        frames.append(chain)
    if not frames:
        return pd.DataFrame()

    frame = pd.concat(frames, ignore_index=True)
    for c in ["strike", "bid", "ask", "delta", "volume", "open_interest"]:
        frame[c] = pd.to_numeric(frame[c], errors="coerce")
    frame["midpoint"] = (frame["bid"] + frame["ask"]) / 2.0
    frame["spread_pct"] = np.where(
        frame["midpoint"] > 0,
        (frame["ask"] - frame["bid"]) / frame["midpoint"],
        np.nan,
    )
    frame["estimated_fill"] = frame["bid"] + fraction * (frame["ask"] - frame["bid"]).clip(lower=0)
    frame["estimated_fill"] = frame[["estimated_fill", "ask"]].min(axis=1).clip(lower=0)
    frame["abs_delta"] = frame["delta"].abs()
    frame["effective_exit_if_called"] = frame["strike"] + frame["estimated_fill"]
    frame["call_cycle_roi"] = frame["estimated_fill"] / max(spot, 0.01)
    frame["call_30d_roi"] = np.power(1.0 + frame["call_cycle_roi"], 30.0 / frame["dte"]) - 1.0
    frame["exit_gain_vs_adjusted_basis"] = frame["effective_exit_if_called"] - adjusted_basis

    frame = frame.loc[
        (frame["strike"] >= spot)
        & frame["abs_delta"].between(min_delta, max_delta, inclusive="both")
        & (frame["bid"] >= float(execution.get("min_bid", 0.20)))
        & (frame["open_interest"] >= float(execution.get("min_open_interest", 200)))
        & (frame["volume"] >= float(execution.get("min_volume", 10)))
        & (frame["spread_pct"] <= float(execution.get("max_spread_pct", 0.15)))
        & (frame["effective_exit_if_called"] >= max(min_exit, adjusted_basis))
    ].copy()
    return frame.sort_values(
        ["call_30d_roi", "effective_exit_if_called", "open_interest"],
        ascending=[False, False, False],
    )


def _analyze_shares(
    row: pd.Series,
    provider: MarketDataProvider,
    config: dict[str, Any],
) -> dict[str, Any]:
    ticker = str(row["ticker"]).upper()
    quote = provider.get_quote(ticker)
    spot = float(quote["spot"])
    as_of = quote.get("as_of")
    as_of_date = as_of.date() if isinstance(as_of, datetime) else date.today()
    shares = max(_int(row.get("shares"), 0), 0)
    cost_basis = _float(row.get("stock_cost_basis"))
    prior_call_premium = _float(row.get("cumulative_call_premium"), 0.0)
    thesis_intact = _bool(row.get("thesis_intact"), True)
    willing_to_sell = _bool(row.get("willing_to_sell_shares"), False)
    news_clear = _bool(row.get("manual_news_clear"), False)
    min_exit = _float(row.get("min_acceptable_exit_price"), 0.0)
    if shares < 100 or not np.isfinite(cost_basis):
        raise ValueError("Shares position requires at least 100 shares and stock_cost_basis")

    adjusted_basis = cost_basis - max(prior_call_premium, 0.0)
    unrealized_pnl = (spot - adjusted_basis) * shares

    selected: pd.Series | None = None
    if thesis_intact and news_clear and willing_to_sell:
        calls = _covered_call_candidates(
            ticker=ticker,
            spot=spot,
            adjusted_basis=adjusted_basis,
            min_exit=min_exit,
            provider=provider,
            config=config,
            as_of_date=as_of_date,
        )
        if not calls.empty:
            selected = calls.iloc[0]

    target_call_roi = float(
        config.get("position_management", {}).get("covered_call_target_30d_roi", 0.01)
    )
    if not thesis_intact or not news_clear:
        action = "SELL SHARES / THESIS REVIEW"
        reason = "Do not use covered calls to avoid acknowledging a broken thesis."
    elif not willing_to_sell:
        action = "HOLD SHARES; NO CALL"
        reason = "A covered call is inappropriate because you are not willing to surrender the shares."
    elif selected is None:
        action = "WAIT FOR BETTER CALL"
        reason = "No liquid call offers an acceptable effective exit price under the current rules."
    elif float(selected["call_30d_roi"]) < target_call_roi:
        action = "WATCH CALL / WAIT FOR GREEN DAY"
        reason = "An acceptable strike exists, but the call return is below the configured target."
    else:
        action = "SELL COVERED CALL"
        reason = "The call premium is acceptable and the effective exit is at or above the adjusted basis."

    return {
        "position_type": "shares",
        "ticker": ticker,
        "action": action,
        "reason": reason,
        "spot": spot,
        "contracts": shares // 100,
        "shares": shares,
        "strike": np.nan,
        "expiration": selected["expiration"] if selected is not None else pd.NaT,
        "dte": int(selected["dte"]) if selected is not None else np.nan,
        "premium_received": np.nan,
        "current_close_cost": np.nan,
        "profit_captured_pct": np.nan,
        "mark_to_market_pnl": unrealized_pnl,
        "abs_delta": abs(float(selected["delta"])) if selected is not None else np.nan,
        "intrinsic_value": np.nan,
        "extrinsic_value": np.nan,
        "assignment_basis": adjusted_basis,
        "stock_vs_basis": spot - adjusted_basis,
        "selected_call_strike": float(selected["strike"]) if selected is not None else np.nan,
        "selected_call_premium": float(selected["estimated_fill"]) if selected is not None else np.nan,
        "selected_call_30d_roi": float(selected["call_30d_roi"]) if selected is not None else np.nan,
        "effective_exit_if_called": float(selected["effective_exit_if_called"]) if selected is not None else np.nan,
        "notes": row.get("notes", ""),
    }


def _fmt(value: Any, kind: str) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ""
    if not np.isfinite(number):
        return ""
    if kind == "money":
        return f"${number:,.0f}"
    if kind == "price":
        return f"${number:,.2f}"
    if kind == "pct":
        return f"{number:.2%}"
    return f"{number:.2f}"


def _render_management_report(path: Path, actions: pd.DataFrame, mode: str, timestamp: str) -> None:
    frame = actions.copy()
    rename = {
        "position_type": "Position",
        "spot": "Spot",
        "premium_received": "Original premium",
        "current_close_cost": "Buyback ask",
        "profit_captured_pct": "Premium captured",
        "mark_to_market_pnl": "Mark-to-market P/L",
        "abs_delta": "Abs delta",
        "assignment_basis": "Adjusted basis",
        "stock_vs_basis": "Stock vs basis",
        "selected_call_strike": "Call strike",
        "selected_call_premium": "Call premium",
        "selected_call_30d_roi": "Call 30d ROI",
        "effective_exit_if_called": "Effective exit",
    }
    frame = frame.rename(columns=rename)
    for c in ["Spot", "strike", "Original premium", "Buyback ask", "Adjusted basis", "Stock vs basis", "Call strike", "Call premium", "Effective exit"]:
        if c in frame:
            frame[c] = frame[c].map(lambda x: _fmt(x, "price"))
    if "Mark-to-market P/L" in frame:
        frame["Mark-to-market P/L"] = frame["Mark-to-market P/L"].map(lambda x: _fmt(x, "money"))
    for c in ["Premium captured", "Call 30d ROI"]:
        if c in frame:
            frame[c] = frame[c].map(lambda x: _fmt(x, "pct"))
    if "Abs delta" in frame:
        frame["Abs delta"] = frame["Abs delta"].map(lambda x: _fmt(x, "num"))
    table = frame.to_html(index=False, border=0, classes="data-table")
    banner = ""
    if mode == "demo":
        banner = '<div class="banner"><strong>DEMO:</strong> Synthetic market data and example positions.</div>'
    text = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Position Management</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f5f7fb;color:#14213d}}.container{{max-width:1600px;margin:auto;padding:28px}}.panel{{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:16px;overflow:auto}}.data-table{{border-collapse:collapse;width:100%;font-size:12px;white-space:nowrap}}th{{background:#eef3f8;text-align:left;padding:9px;border-bottom:2px solid #cfd6df}}td{{padding:8px;border-bottom:1px solid #e5e7eb;vertical-align:top}}.banner{{padding:12px;background:#fff8e6;border:1px solid #f0c36d;border-radius:8px;margin:14px 0}}.note{{color:#667085;font-size:12px;line-height:1.55;margin-top:14px}}</style></head><body><div class="container"><h1>Put and Assigned-Share Management</h1><div>Run {html.escape(timestamp)} | mode={html.escape(mode)}</div>{banner}<div class="panel">{table}</div><div class="note">The default acquisition-first behavior is to accept assignment when the thesis remains intact. A roll is not treated as a repair; it should be opened only when the replacement put independently passes the screen. Covered calls are recommended only when the effective exit price is acceptable.</div></div></body></html>"""
    path.write_text(text, encoding="utf-8")


def run_management(
    provider: MarketDataProvider,
    config: dict[str, Any],
    config_path: str | Path,
    mode: str,
    positions_path_override: str | Path | None = None,
    output_root_override: str | Path | None = None,
) -> ManagementResult:
    config_path = Path(config_path).resolve()
    positions_path = (
        Path(positions_path_override).resolve()
        if positions_path_override
        else resolve_path(config_path, config["positions_path"])
    )
    output_root = (
        Path(output_root_override).resolve()
        if output_root_override
        else resolve_path(config_path, config["output_root"])
    )
    positions = pd.read_csv(positions_path, skipinitialspace=True)
    if positions.empty:
        raise ValueError("Positions file is empty")
    required = {"position_type", "ticker"}
    missing = required.difference(positions.columns)
    if missing:
        raise ValueError(f"Positions file is missing columns: {sorted(missing)}")

    rows: list[dict[str, Any]] = []
    for _, row in positions.iterrows():
        try:
            position_type = str(row.get("position_type", "")).strip().lower()
            if position_type == "short_put":
                rows.append(_analyze_short_put(row, provider, config))
            elif position_type == "shares":
                rows.append(_analyze_shares(row, provider, config))
            else:
                raise ValueError("position_type must be short_put or shares")
        except Exception as exc:
            rows.append(
                {
                    "position_type": row.get("position_type", ""),
                    "ticker": str(row.get("ticker", "")).upper(),
                    "action": "ERROR",
                    "reason": f"{type(exc).__name__}: {exc}",
                    "notes": row.get("notes", ""),
                }
            )
    actions = pd.DataFrame(rows)

    run_time = datetime.now(timezone.utc)
    run_id = run_time.strftime("management_%Y%m%d_%H%M%S_%fZ")
    output_dir = output_root / run_id
    output_dir.mkdir(parents=True, exist_ok=False)
    actions.to_csv(output_dir / "position_actions.csv", index=False)
    report_path = output_dir / "position_management_report.html"
    _render_management_report(report_path, actions, mode, run_time.isoformat())

    latest = output_root / "management_latest"
    if latest.exists():
        shutil.rmtree(latest)
    shutil.copytree(output_dir, latest)
    return ManagementResult(actions=actions, output_dir=output_dir, report_path=report_path)
