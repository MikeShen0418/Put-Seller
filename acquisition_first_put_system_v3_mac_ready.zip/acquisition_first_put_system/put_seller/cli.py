from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from dotenv import load_dotenv

from .config import load_config
from .management import run_management
from .pipeline import run_pipeline
from .providers.demo import DemoProvider
from .providers.tradier import TradierProvider


def build_parser() -> argparse.ArgumentParser:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Acquisition-first cash-secured put screening and position management."
    )
    parser.add_argument(
        "--config",
        default=str(project_root / "config" / "config.yaml"),
        help="Path to YAML configuration file.",
    )
    parser.add_argument("--task", choices=["screen", "manage"], default="screen")
    parser.add_argument("--mode", choices=["demo", "live"], default="demo")
    parser.add_argument(
        "--profile",
        choices=["defensive", "acquisition_core", "yield"],
        help="Override active_profile from the YAML file.",
    )
    parser.add_argument("--cash", type=float, help="Override total cash available.")
    parser.add_argument("--watchlist", help="Override the watchlist CSV path.")
    parser.add_argument("--positions", help="Override the positions CSV path for --task manage.")
    parser.add_argument(
        "--as-of",
        help="Demo as-of date in YYYY-MM-DD format. Defaults to today.",
    )
    parser.add_argument("--output-root", help="Optional output directory override.")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    project_root = Path(__file__).resolve().parents[1]
    load_dotenv(project_root / ".env")
    load_dotenv()

    config = load_config(args.config)
    if args.profile:
        config["profile_name"] = args.profile
        config["profile"] = config["profiles"][args.profile].copy()
    if args.cash is not None:
        if args.cash <= 0:
            raise SystemExit("--cash must be positive")
        config["capital"]["total_cash"] = args.cash
    if args.watchlist:
        config["watchlist_path"] = str(Path(args.watchlist).resolve())

    if args.mode == "demo":
        as_of = date.fromisoformat(args.as_of) if args.as_of else None
        provider = DemoProvider(as_of=as_of)
    else:
        provider = TradierProvider()

    if args.task == "manage":
        result = run_management(
            provider=provider,
            config=config,
            config_path=args.config,
            mode=args.mode,
            positions_path_override=args.positions,
            output_root_override=args.output_root,
        )
        display = [
            c for c in [
                "ticker", "position_type", "action", "spot", "strike", "dte",
                "profit_captured_pct", "assignment_basis", "selected_call_strike",
                "selected_call_30d_roi", "reason",
            ] if c in result.actions.columns
        ]
        print("\nPosition management actions\n")
        print(result.actions[display].to_string(index=False))
        print(f"\nReport: {result.report_path}")
        print(f"Output directory: {result.output_dir}")
        return

    result = run_pipeline(
        provider=provider,
        config=config,
        config_path=args.config,
        mode=args.mode,
        output_root_override=args.output_root,
    )
    display_columns = [
        "ticker", "decision", "strategy_type", "decision_score", "spot",
        "target_entry_price", "earnings_bear_case_price", "earnings_date",
        "expiration", "strike", "abs_delta", "estimated_fill",
        "roi_30d_equivalent", "required_30d_roi", "net_assignment_basis",
        "implied_move_pct", "failure_reasons", "warnings",
    ]
    available = [c for c in display_columns if c in result.best_by_ticker.columns]
    print("\nBest acquisition contract by ticker\n")
    print(result.best_by_ticker[available].to_string(index=False))
    print("\nPortfolio summary\n")
    for key, value in result.portfolio_summary.items():
        print(f"{key}: {value}")
    print(f"\nReport: {result.report_path}")
    if not result.earnings_scenarios.empty:
        print(f"Earnings scenarios: {result.output_dir / 'earnings_scenarios.csv'}")
    print(f"Output directory: {result.output_dir}")


if __name__ == "__main__":
    main()
