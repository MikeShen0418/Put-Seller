@echo off
setlocal
cd /d %~dp0
python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not exist .env copy .env.example .env >nul
echo.
echo Setup complete.
echo Run run_demo.bat first. Edit .env and the live CSV templates before live mode.
pause
