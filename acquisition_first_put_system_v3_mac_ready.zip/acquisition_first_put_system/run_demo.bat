@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python -m put_seller.cli --task screen --mode demo --as-of 2026-10-21 --config config\config.yaml
if exist output\latest\decision_report.html start "" output\latest\decision_report.html
pause
