# Quick Start

## Windows

1. Extract the ZIP into a normal folder.
2. Open the inner folder containing `setup_windows.bat`.
3. Double-click `setup_windows.bat` once.
4. Double-click `run_demo.bat`.
5. Open:

```text
output\latest\decision_report.html
```

6. Review the supporting CSV files, especially:

```text
output\latest\trade_shortlist.csv
output\latest\earnings_scenarios.csv
```

7. Double-click `run_management_demo.bat` to see what the system does after a put has been sold or shares have been assigned.

## Mac

The Mac-ready package includes Finder-double-click launchers. In the extracted project folder:

1. Double-click `1 - Setup Mac.command` once.
2. Double-click `2 - Run Demo.command`.
3. Double-click `5 - Run Management Demo.command` to see the position-management workflow.

For live use, double-click `3 - Edit Live Inputs.command`, complete `.env` and the live watchlist, then use `4 - Run Live Screen.command`.

Terminal users can instead run:

```bash
cd /path/to/acquisition_first_put_system
chmod +x *.command *.sh
./setup_mac.sh
./run_demo_mac.sh
./run_management_demo_mac.sh
```

See `MAC_QUICK_START.md` for Apple Silicon, Intel Mac, Gatekeeper, and live-mode instructions.

## Before live mode

Edit `.env`:

```text
TRADIER_TOKEN=your_token
TRADIER_BASE_URL=https://api.tradier.com/v1
ALPHAVANTAGE_API_KEY=your_key
```

Then edit:

```text
data/watchlist_live_template.csv
```

For each ticker:

1. Set a real `target_entry_price` above zero.
2. Set `ownership_approved=true` only when you genuinely want the company.
3. Enter `desired_shares`, `max_shares`, and `max_contracts`.
4. Enter `priority_rank`, `valuation_confidence`, and your thesis.
5. Review current company news and only then set `manual_news_clear=true`.
6. Leave `earnings_mode=avoid` for the ordinary strategy.
7. For an intentional earnings trade, set:

```text
earnings_mode=acquisition
earnings_trade_approved=true
earnings_bear_case_price=<your post-report bear-case value>
earnings_min_30d_roi=<optional event hurdle>
earnings_max_contracts=<optional event cap>
```

Run live screening:

### Windows

```text
run_live.bat
```

### Mac

```bash
./run_live_mac.sh
```

## Read the report in this order

1. `Decision`
2. `Trade type`
3. `Net basis`
4. `Effective target`
5. `30d ROI`
6. `Required 30d ROI`
7. `Implied move` and `Implied lower` for earnings trades
8. `Why blocked`
9. `Warnings`
10. `High-premium review`

A high premium is not automatically attractive. Ownership and valuation come first.

## Update your own watchlist

Copy:

```text
data/watchlist_live_template.csv
```

Save it under a new name and run:

```bash
python -m put_seller.cli --task screen --mode live --watchlist data/my_watchlist.csv
```

## Manage existing positions

Copy:

```text
data/open_positions_template.csv
```

Enter actual positions and run:

```bash
python -m put_seller.cli --task manage --mode live --positions data/my_positions.csv
```

The manager does not place trades or automatically roll positions. It identifies the decision point and provides an explainable action.
