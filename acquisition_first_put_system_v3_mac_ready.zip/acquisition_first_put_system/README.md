# Acquisition-First Put System v0.3.1

A Python decision-support pipeline for one specific idea:

> Own only companies already approved for long-term ownership, but do not buy them at a price you lack confidence in. Sell a cash-secured put only when the premium-adjusted assignment price is acceptable. If assignment does not occur, earn a worthwhile return on the secured cash while waiting.

The system supports two deliberately separate strategies:

1. **Regular acquisition put** — normally avoids earnings and prefers a meaningful red day that begins to stabilize.
2. **Earnings-acquisition put** — intentionally crosses earnings, but only with explicit approval, a post-report bear-case value, an event-specific return hurdle, and reduced sizing.

It also includes short-put management, assigned-share management, covered-call screening, a capital optimizer, synthetic demo data, live Tradier market data, earnings dates from Alpha Vantage, CSV/JSON/HTML outputs, Windows launchers, native macOS shell scripts and Finder-double-click `.command` launchers, a notebook, and automated tests.

The demo uses familiar ticker names, but every demo price, option chain, volatility, earnings date, and scenario is synthetic. It is not a recommendation list.

## Decision hierarchy

The system follows this order:

1. **Ownership approval** — you genuinely want the company.
2. **Thesis and news** — the business thesis remains intact and current news has been reviewed.
3. **Valuation** — the net assignment basis meets the applicable target.
4. **Waiting return** — the put meets the applicable 30-day-equivalent ROI hurdle.
5. **Event control** — ordinary puts avoid earnings; event puts require explicit approval and a bear-case valuation.
6. **Execution quality** — bid/ask, volume, and open interest are acceptable.
7. **Entry timing** — regular trades prefer red-day stabilization; earnings trades use a defined event window.
8. **Portfolio sizing** — assignment would not create an oversized position.

High implied volatility is useful only after the company and price are approved. It is not a reason to own a company.

## Core formulas

For a standard 100-share cash-secured put:

```text
Cash secured = strike × 100
Maximum premium income = option premium × 100
Maximum cycle ROI = premium / strike
Net assignment basis = strike - premium
30-day-equivalent ROI = (1 + cycle ROI)^(30 / DTE) - 1
```

The 100-share multiplier cancels from the ROI calculation. The denominator already represents the full cash purchasing capacity committed to assignment.

Example:

```text
Strike:                 $100
Premium:                $2.50
Cash secured:           $10,000
Maximum premium:        $250
Cycle ROI:              2.50%
Net assignment basis:   $97.50
```

Collateral interest is supported but turned off by default, matching the initial decision to ignore money-market income.

## Return targets

Default screening hurdles:

```text
Regular acquisition put:    2.0% gross per 30 days
Earnings-acquisition put:   3.0% gross per 30 days
High-premium review flag:   4.0%+ per 30 days
```

These are opportunity filters, not expected portfolio returns. A 3%–5% quoted monthly ROI is not automatically better; it usually means the market is pricing a meaningful event, downside, skew, or execution risk.

The configuration also records a long-run 20% after-tax goal using a simplified 24% effective tax assumption. Actual performance must be calculated from real account values, including stock mark-to-market after assignment.

## Regular acquisition puts

The ordinary strategy uses:

```text
net assignment basis <= ordinary target entry price
```

The default `acquisition_core` search is:

```text
24–38 DTE
10–32 absolute delta
30 DTE target
```

Delta is deliberately secondary. Your valuation target determines the acceptable strike; delta describes the exposure produced by that choice.

The preferred entry is a pullback inside an otherwise acceptable trend:

- meaningful red day measured relative to ATR;
- some recovery from the session low;
- no earnings inside the contract or buffer;
- no panic decline or multi-day breakdown;
- IV reasonably rich versus recent realized volatility.

## Earnings-acquisition puts

An earnings put is not merely an `earnings_allowed` waiver. It is a separate strategy.

A crossing contract requires all of the following:

```text
ownership_approved = true
thesis_intact = true
manual_news_clear = true
earnings_mode = acquisition
earnings_trade_approved = true
earnings_bear_case_price > 0
net assignment basis <= earnings_bear_case_price
30-day ROI >= earnings-specific hurdle
ATM-straddle implied move available
position size within the reduced event cap
```

The ordinary target price may rely on current guidance. The earnings bear case should answer a harder question:

> If growth, margins, or guidance disappoint, what price would still represent an acceptable post-report value?

The default event controls are:

```text
Event DTE window:           10–30 DTE; 21 DTE target
Entry window:              1–10 calendar days before earnings
Preferred entry timing:    about 3 days before earnings
Expiration:                no more than 14 days after earnings
Default event sizing:      50% of normal contract count
Per-ticker event cash cap: 12.5% of total portfolio cash
```

All values are configurable.

### Implied earnings move

For each expiration, the system estimates:

```text
Implied move % = (ATM call midpoint + ATM put midpoint) / stock price
Implied lower price = stock price - ATM straddle cost
Implied upper price = stock price + ATM straddle cost
```

This is a useful market estimate, not a confidence interval, guaranteed boundary, or maximum possible move.

### Why IV crush is helpful but not protection

A short put has negative vega, so an IV decline after earnings can reduce its value. But IV crush mainly removes **extrinsic value**.

```text
Put value = intrinsic value + extrinsic value
Intrinsic value = max(strike - stock price, 0)
```

If the stock gaps far below the strike, intrinsic value can overwhelm the IV benefit. The system therefore requires a bear-case value and produces an earnings scenario table rather than assuming that IV crush makes the trade safe.

### Stock versus short put

A short put has capped upside. The system shows two crossover prices:

```text
Equal dollar-P/L stock price = current stock price + put premium
Equal return-on-capital stock price = current stock price × (1 + put cycle ROI)
```

Below the crossover, the short put can outperform buying the stock immediately because of the premium and lower effective basis. Above it, the stock wins because its upside is uncapped.

## Earnings scenario output

`output/latest/earnings_scenarios.csv` and the HTML report compare:

- upper implied move;
- unchanged stock;
- lower implied move;
- your supplied earnings bear-case value;
- your supplied historical worst earnings drop, when available.

For each outcome the system reports:

1. stock return and P/L on 100 shares;
2. modeled next-day put close cost after a configurable IV decline;
3. modeled short-put mark-to-market P/L;
4. expiration short-put payoff, which is independent of IV;
5. short-put P/L minus stock P/L.

The post-event reprice is an illustrative Black-Scholes scenario, not a forecast. It ignores American exercise, dividends, skew changes, jump dynamics, and execution costs.

## Decision labels

- `SELL` — applicable ownership, valuation, return, event, execution, timing, and score rules pass.
- `WATCH` — economics qualify, but entry timing or total score is not ready.
- `NO TRADE` — the company may remain approved, but the contract misses the applicable target price or return requirement.
- `REJECT` — a policy rule fails, such as unapproved ownership, broken thesis, missing event approval, poor liquidity, or a falling-knife condition.
- `ERROR` — data or input processing failed.

The `strategy_type` column distinguishes:

```text
REGULAR_ACQUISITION
EARNINGS_ACQUISITION
```

A contract crossing earnings is labeled as earnings exposure even when it is rejected because approval is absent.

## Quick start

Read `QUICK_START.md` for exact steps.

### Windows

1. Double-click `setup_windows.bat` once.
2. Double-click `run_demo.bat`.
3. Open `output/latest/decision_report.html`.
4. Double-click `run_management_demo.bat` to inspect position-management logic.

### Mac

Finder method:

```text
1 - Setup Mac.command
2 - Run Demo.command
5 - Run Management Demo.command
```

Terminal method:

```bash
chmod +x *.command *.sh
./setup_mac.sh
./run_demo_mac.sh
./run_management_demo_mac.sh
```

The package supports Apple Silicon and Intel Macs through a local Python virtual environment. See `MAC_QUICK_START.md` for detailed instructions and Gatekeeper troubleshooting.

## Watchlist fields

The important columns in `data/watchlist_live_template.csv` are:

| Column | Meaning |
|---|---|
| `ownership_approved` | You genuinely want to own the company |
| `thesis_intact` | Current business thesis remains valid |
| `target_entry_price` | Highest acceptable basis for a regular put |
| `desired_shares` | Desired long-term share count |
| `max_shares` | Absolute assigned-share cap |
| `max_contracts` | Normal contract cap |
| `priority_rank` | 1 is highest acquisition priority |
| `valuation_confidence` | 0–100 confidence in valuation work |
| `manual_news_clear` | Set true only after reviewing current material news |
| `earnings_mode` | `avoid` or `acquisition` |
| `earnings_trade_approved` | Explicit approval for the binary event |
| `earnings_bear_case_price` | Maximum acceptable net basis after a weak report |
| `earnings_min_30d_roi` | Optional ticker-specific event hurdle |
| `earnings_max_contracts` | Optional event-specific contract cap |
| `historical_median_earnings_move_pct` | Optional manual historical context |
| `historical_worst_earnings_drop_pct` | Optional positive percentage, such as `0.20` |
| `manual_earnings_date` | Optional `YYYY-MM-DD` override |
| `min_30d_roi` | Ticker-specific regular ROI hurdle |
| `thesis` | Ownership rationale and key caveats |

A target price of zero intentionally fails closed.

## Position management

The manager supports:

```text
short_put
shares
```

Typical actions include:

```text
HOLD
TAKE PROFIT
ACCEPT ASSIGNMENT
CLOSE PUT
HOLD FOR ASSIGNMENT
SELL COVERED CALL
WAIT FOR BETTER CALL
SELL SHARES / THESIS REVIEW
```

The central management question remains:

> Knowing today’s information, would I voluntarily buy the shares at the premium-adjusted assignment basis?

A roll is not treated as a repair. The replacement put should independently pass the acquisition screen.

Covered calls are screened only when the effective exit is acceptable:

```text
call strike + call premium >= adjusted stock basis
```

Covered calls can lower basis but cannot guarantee recovery and may cap a rebound.

## Output files

Put screen:

```text
output/latest/decision_report.html
output/latest/trade_shortlist.csv
output/latest/best_by_ticker.csv
output/latest/all_candidates.csv
output/latest/underlying_snapshot.csv
output/latest/portfolio_allocation.csv
output/latest/earnings_scenarios.csv
output/latest/run_summary.json
```

Position manager:

```text
output/management_latest/position_management_report.html
output/management_latest/position_actions.csv
```

## Data sources and run cadence

Live mode uses:

- **Tradier** — quote, daily history, expirations, complete put/call chains, bid/ask, volume, open interest, Greeks, and IV.
- **Alpha Vantage** — upcoming earnings dates.
- **Your watchlist** — ownership approval, valuation targets, bear cases, sizing, and thesis decisions.
- **Local IV history** — one IV proxy observation per ticker per day.

A practical cadence is:

```text
Normal day:          once around 10:30–11:30 a.m. Eastern
Meaningful red day:  optional second run around 2:30–3:30 p.m. Eastern
Open positions:      management run once per trading day
Near expiry/event:   increase review frequency as needed
```

The system does not place orders. Verify the live bid/ask at your broker and use a limit order.

## Live setup

Copy `.env.example` to `.env` and enter:

```text
TRADIER_TOKEN=...
TRADIER_BASE_URL=https://api.tradier.com/v1
ALPHAVANTAGE_API_KEY=...
```

Then edit `data/watchlist_live_template.csv` and run `run_live.bat` or `./run_live_mac.sh`.

## Tests

```bash
pytest -q
```

Version 0.3 includes 11 automated tests covering regular valuation gates, earnings approval and bear-case gates, the separate event DTE window, ATM-straddle implied moves, scenario analysis, event sizing, ROI calculations, demo option chains, allocation, and position management.

## Important limitation

Maximum ROI assumes the put expires worthless. Actual portfolio performance must include option mark-to-market, assigned-stock value, dividends, collateral interest when enabled, commissions, taxes, and subsequent covered-call outcomes. No formula, IV crush, delta range, or covered-call cycle removes the underlying company risk.
