from datetime import date

import pandas as pd
import pytest

from put_seller.config import load_config
from put_seller.earnings import build_earnings_scenarios
from put_seller.features import compute_atm_straddle_metrics
from put_seller.scoring import score_candidates


def test_atm_straddle_implied_move_uses_call_and_put_midpoints():
    expiration = date(2026, 11, 20)
    chain = pd.DataFrame(
        [
            {"expiration": expiration, "strike": 95, "option_type": "call", "bid": 7.8, "ask": 8.2},
            {"expiration": expiration, "strike": 95, "option_type": "put", "bid": 2.8, "ask": 3.2},
            {"expiration": expiration, "strike": 100, "option_type": "call", "bid": 3.8, "ask": 4.2},
            {"expiration": expiration, "strike": 100, "option_type": "put", "bid": 3.3, "ask": 3.7},
            {"expiration": expiration, "strike": 105, "option_type": "call", "bid": 1.8, "ask": 2.2},
            {"expiration": expiration, "strike": 105, "option_type": "put", "bid": 6.8, "ask": 7.2},
        ]
    )
    metrics = compute_atm_straddle_metrics(chain, spot=100.0).iloc[0]
    assert metrics["atm_strike"] == 100.0
    assert metrics["atm_straddle_cost"] == pytest.approx(7.5)
    assert metrics["implied_move_pct"] == pytest.approx(0.075)
    assert metrics["implied_lower_price"] == pytest.approx(92.5)
    assert metrics["implied_upper_price"] == pytest.approx(107.5)


def _event_candidate() -> dict:
    return {
        "ticker": "XYZ",
        "dte": 30,
        "abs_delta": 0.20,
        "is_otm": True,
        "bid": 3.0,
        "spread_pct": 0.03,
        "open_interest": 1500,
        "volume": 200,
        "iv_rv_ratio": 1.5,
        "down_move_atr": 0.2,
        "close_off_low_atr": 0.4,
        "drop_5d_atr": 0.4,
        "price_to_sma50": 1.02,
        "return_20d": 0.04,
        "slope20_annualized": 0.2,
        "roi_30d_equivalent": 0.035,
        "total_waiting_30d_roi": 0.035,
        "net_assignment_basis": 87.0,
        "target_entry_price": 92.0,
        "earnings_bear_case_price": 88.0,
        "ownership_approved": True,
        "thesis_intact": True,
        "earnings_mode": "acquisition",
        "earnings_trade_approved": True,
        "earnings_known": True,
        "earnings_crosses": True,
        "days_to_earnings": 5,
        "days_after_earnings": 7,
        "valuation_confidence": 80,
        "priority_rank": 1,
        "strike_distance_expected_move": 0.6,
        "breakeven_discount": 0.13,
        "implied_move_pct": 0.10,
        "implied_lower_price": 90.0,
        "spot": 100.0,
        "iv": 0.65,
        "max_contracts": 2,
    }


def test_earnings_acquisition_requires_approval_and_bear_case():
    config = load_config("config/config.yaml")
    good = score_candidates(
        pd.DataFrame([_event_candidate()]), config, True, 80, 120
    ).iloc[0]
    assert good["strategy_type"] == "EARNINGS_ACQUISITION"
    assert good["decision"] in {"SELL", "WATCH"}
    assert good["effective_target_price"] == pytest.approx(88.0)
    assert good["required_30d_roi"] == pytest.approx(0.03)
    assert good["max_contracts_allowed"] == 1

    unapproved = _event_candidate()
    unapproved["earnings_trade_approved"] = False
    rejected = score_candidates(
        pd.DataFrame([unapproved]), config, True, 80, 120
    ).iloc[0]
    assert rejected["decision"] == "REJECT"
    assert "not explicitly approved" in rejected["policy_failures"]

    missing_bear = _event_candidate()
    missing_bear["earnings_bear_case_price"] = float("nan")
    rejected = score_candidates(
        pd.DataFrame([missing_bear]), config, True, 80, 120
    ).iloc[0]
    assert rejected["decision"] == "REJECT"
    assert "bear-case value is missing" in rejected["policy_failures"]


def test_earnings_bear_case_is_a_hard_economic_gate():
    config = load_config("config/config.yaml")
    row = _event_candidate()
    row["net_assignment_basis"] = 89.0
    result = score_candidates(pd.DataFrame([row]), config, True, 80, 120).iloc[0]
    assert result["decision"] == "NO TRADE"
    assert "above the post-earnings bear-case value" in result["economic_failures"]


def test_earnings_trade_uses_event_specific_dte_window():
    config = load_config("config/config.yaml")
    event_row = _event_candidate()
    event_row["dte"] = 18
    event_row["days_to_earnings"] = 5
    event_row["days_after_earnings"] = 13
    event_result = score_candidates(
        pd.DataFrame([event_row]), config, True, 80, 120
    ).iloc[0]
    assert "outside the earnings profile" not in event_result["economic_failures"]

    regular_row = event_row.copy()
    regular_row["earnings_crosses"] = False
    regular_row["days_after_earnings"] = -5
    regular_result = score_candidates(
        pd.DataFrame([regular_row]), config, True, 80, 120
    ).iloc[0]
    assert "DTE is outside the active profile" in regular_result["economic_failures"]


def test_earnings_scenario_table_shows_iv_crush_and_expiration_payoff():
    config = load_config("config/config.yaml")
    best = pd.DataFrame(
        [
            {
                "ticker": "XYZ",
                "decision": "SELL",
                "strategy_type": "EARNINGS_ACQUISITION",
                "earnings_trade_approved": True,
                "earnings_bear_case_price": 86.0,
                "spot": 100.0,
                "strike": 90.0,
                "estimated_fill": 4.0,
                "iv": 0.60,
                "expiration": date(2026, 11, 20),
                "earnings_date": date(2026, 11, 10),
                "implied_move_pct": 0.08,
                "implied_lower_price": 92.0,
                "implied_upper_price": 108.0,
                "historical_worst_earnings_drop_pct": 0.20,
            }
        ]
    )
    scenarios = build_earnings_scenarios(best, config)
    assert set(scenarios["scenario"]) == {
        "UPPER IMPLIED MOVE",
        "UNCHANGED",
        "LOWER IMPLIED MOVE",
        "BEAR-CASE VALUE",
        "HISTORICAL WORST DROP",
    }
    unchanged = scenarios.loc[scenarios["scenario"] == "UNCHANGED"].iloc[0]
    assert unchanged["expiration_short_put_pnl_per_contract"] == pytest.approx(400.0)
    assert unchanged["modeled_put_close_cost"] < 4.0
    worst = scenarios.loc[scenarios["scenario"] == "HISTORICAL WORST DROP"].iloc[0]
    assert worst["expiration_short_put_pnl_per_contract"] == pytest.approx(-600.0)
