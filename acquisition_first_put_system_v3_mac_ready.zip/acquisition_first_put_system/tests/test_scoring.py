import pandas as pd

from put_seller.config import load_config
from put_seller.scoring import score_candidates


def _base_candidate() -> dict:
    return {
        "ticker": "XYZ",
        "dte": 30,
        "abs_delta": 0.20,
        "is_otm": True,
        "bid": 2.0,
        "spread_pct": 0.03,
        "open_interest": 1000,
        "volume": 100,
        "iv_rv_ratio": 1.3,
        "down_move_atr": 0.9,
        "close_off_low_atr": 0.4,
        "drop_5d_atr": 0.5,
        "price_to_sma50": 1.0,
        "return_20d": 0.02,
        "slope20_annualized": 0.1,
        "roi_30d_equivalent": 0.025,
        "total_waiting_30d_roi": 0.025,
        "net_assignment_basis": 88.0,
        "target_entry_price": 90.0,
        "ownership_approved": True,
        "thesis_intact": True,
        "earnings_allowed": False,
        "earnings_known": True,
        "earnings_crosses": False,
        "valuation_confidence": 80,
        "priority_rank": 1,
        "strike_distance_expected_move": 0.6,
        "breakeven_discount": 0.12,
        "iv": 0.5,
    }


def test_target_price_is_a_hard_economic_gate():
    config = load_config("config/config.yaml")
    good = score_candidates(pd.DataFrame([_base_candidate()]), config, True, 75, 100).iloc[0]
    assert good["decision"] in {"SELL", "WATCH"}

    bad_row = _base_candidate()
    bad_row["net_assignment_basis"] = 92.0
    bad = score_candidates(pd.DataFrame([bad_row]), config, True, 75, 100).iloc[0]
    assert bad["decision"] == "NO TRADE"
    assert "above the target entry price" in bad["economic_failures"]
