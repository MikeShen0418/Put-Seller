from datetime import date

from put_seller.providers.demo import DemoProvider


def test_demo_provider_is_deterministic_and_supports_puts_and_calls():
    provider_a = DemoProvider(as_of=date(2026, 10, 20))
    provider_b = DemoProvider(as_of=date(2026, 10, 20))
    quote_a = provider_a.get_quote("NVDA")
    quote_b = provider_b.get_quote("NVDA")
    assert quote_a["spot"] == quote_b["spot"]
    expiration = provider_a.get_expirations("NVDA")[4]
    puts = provider_a.get_option_chain("NVDA", expiration, option_type="put")
    calls = provider_a.get_option_chain("NVDA", expiration, option_type="call")
    assert not puts.empty and not calls.empty
    assert set(["bid", "ask", "delta", "iv", "open_interest"]).issubset(puts.columns)
    assert set(puts["option_type"]) == {"put"}
    assert set(calls["option_type"]) == {"call"}
    assert (puts["ask"] >= puts["bid"]).all()
