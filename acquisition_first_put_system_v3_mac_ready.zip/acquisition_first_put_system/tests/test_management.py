from datetime import date

import pandas as pd

from put_seller.config import load_config
from put_seller.management import _analyze_shares, _analyze_short_put
from put_seller.providers.demo import DemoProvider


def test_position_manager_distinguishes_assignment_and_broken_thesis():
    provider = DemoProvider(as_of=date(2026, 10, 20))
    config = load_config("config/config.yaml")
    put = pd.Series(
        {
            "ticker": "TSLA",
            "contracts": 1,
            "strike": 380,
            "expiration": "2026-11-20",
            "premium_received": 12,
            "thesis_intact": False,
            "still_want_shares": False,
            "manual_news_clear": True,
        }
    )
    result = _analyze_short_put(put, provider, config)
    assert result["action"] == "CLOSE PUT"

    shares = pd.Series(
        {
            "ticker": "AMD",
            "shares": 100,
            "stock_cost_basis": 198,
            "cumulative_call_premium": 2.5,
            "thesis_intact": True,
            "willing_to_sell_shares": True,
            "manual_news_clear": True,
            "min_acceptable_exit_price": 198,
        }
    )
    stock_result = _analyze_shares(shares, provider, config)
    assert stock_result["action"] in {"SELL COVERED CALL", "WATCH CALL / WAIT FOR GREEN DAY", "WAIT FOR BETTER CALL"}
