import pandas as pd
import pytest

from put_seller.optimizer import optimize_portfolio


def test_optimizer_respects_cash_concentration_and_share_caps():
    best = pd.DataFrame(
        [
            {
                "ticker": "AAA",
                "decision": "SELL",
                "premium_dollars": 300.0,
                "total_waiting_dollars": 300.0,
                "cash_required": 10000.0,
                "dte": 30,
                "decision_score": 80.0,
                "annualized_max_yield": 0.365,
                "total_waiting_30d_roi": 0.03,
                "target_basis_margin": 0.04,
                "valuation_confidence": 80,
                "priority_rank": 1,
                "max_contracts": 1,
            },
            {
                "ticker": "BBB",
                "decision": "SELL",
                "premium_dollars": 250.0,
                "total_waiting_dollars": 250.0,
                "cash_required": 8000.0,
                "dte": 30,
                "decision_score": 75.0,
                "annualized_max_yield": 0.380,
                "total_waiting_30d_roi": 0.03125,
                "target_basis_margin": 0.03,
                "valuation_confidence": 75,
                "priority_rank": 2,
                "max_contracts": 2,
            },
        ]
    )
    config = {
        "capital": {
            "total_cash": 30000.0,
            "cash_increment": 100.0,
            "max_ticker_pct": 0.50,
            "max_contracts_per_ticker": 5,
            "objective": "acquisition_quality",
        }
    }
    allocation, summary = optimize_portfolio(best, config)
    assert summary["cash_allocated"] <= 30000.0
    assert allocation.loc[allocation["ticker"] == "AAA", "contracts"].max() <= 1
    for _, row in allocation.iterrows():
        assert row["allocated_cash"] <= 15000.0


def test_optimizer_uses_earnings_specific_contract_and_concentration_caps():
    best = pd.DataFrame(
        [
            {
                "ticker": "EVENT",
                "decision": "SELL",
                "strategy_type": "EARNINGS_ACQUISITION",
                "premium_dollars": 500.0,
                "total_waiting_dollars": 500.0,
                "cash_required": 10000.0,
                "dte": 30,
                "decision_score": 90.0,
                "annualized_max_yield": 0.60,
                "total_waiting_30d_roi": 0.05,
                "target_basis_margin": 0.05,
                "valuation_confidence": 85,
                "priority_rank": 1,
                "max_contracts": 4,
                "max_contracts_allowed": 1,
                "max_ticker_pct_override": 0.125,
            }
        ]
    )
    config = {
        "capital": {
            "total_cash": 100000.0,
            "cash_increment": 100.0,
            "max_ticker_pct": 0.25,
            "max_contracts_per_ticker": 5,
            "objective": "acquisition_quality",
        }
    }
    allocation, summary = optimize_portfolio(best, config)
    assert allocation.iloc[0]["contracts"] == 1
    assert summary["earnings_acquisition_cash"] == pytest.approx(10000.0)
    assert summary["earnings_acquisition_pct_of_total_cash"] == pytest.approx(0.10)
