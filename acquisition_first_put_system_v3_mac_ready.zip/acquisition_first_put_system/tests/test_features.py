from datetime import date, timedelta

import pandas as pd
import pytest

from put_seller.features import enrich_option_chain


def test_secured_cash_roi_assignment_basis_and_earnings_crossing():
    chain = pd.DataFrame(
        [
            {
                "symbol": "TEST",
                "ticker": "XYZ",
                "expiration": date(2026, 12, 18),
                "strike": 90.0,
                "option_type": "put",
                "bid": 2.0,
                "ask": 2.2,
                "last": 2.1,
                "volume": 100,
                "open_interest": 1000,
                "delta": -0.20,
                "gamma": 0.01,
                "theta": -0.05,
                "vega": 0.10,
                "iv": 0.50,
            }
        ]
    )
    as_of = date(2026, 11, 18)
    enriched = enrich_option_chain(
        chain,
        quote={"spot": 100.0},
        underlying={"rv20": 0.40},
        as_of=as_of,
        earnings_date=as_of + timedelta(days=20),
        execution_fraction_from_bid=0.0,
        earnings_buffer_days=2,
    )
    row = enriched.iloc[0]
    assert row["cash_required"] == pytest.approx(9000.0)
    assert row["premium_dollars"] == pytest.approx(200.0)
    assert row["max_cycle_roi"] == pytest.approx(2.0 / 90.0)
    assert row["net_assignment_basis"] == pytest.approx(88.0)
    assert row["roi_30d_equivalent"] == pytest.approx(2.0 / 90.0)
    assert row["annualized_max_yield"] == pytest.approx((2.0 / 90.0) * 365 / 30)
    assert bool(row["earnings_crosses"]) is True
