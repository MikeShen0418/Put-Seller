# macOS Quick Start

This package runs on both Apple Silicon Macs and Intel Macs. It contains only Python source code; no architecture-specific executable is bundled.

## Requirements

- macOS
- Python 3.10 or newer
- Internet access during the one-time package installation

Check Python by opening Terminal and running:

```bash
python3 --version
```

If Python is missing, install a current Python 3 release. One common option is Homebrew:

```bash
brew install python
```

## Easiest method: double-click launchers

In Finder, open the extracted `acquisition_first_put_system` folder and use these files in order:

1. `1 - Setup Mac.command` — creates `.venv`, installs dependencies, creates `.env`, and runs all tests.
2. `2 - Run Demo.command` — runs the synthetic option screen and opens the HTML report.
3. `5 - Run Management Demo.command` — demonstrates management of short puts and assigned shares.

For live mode:

4. `3 - Edit Live Inputs.command` — opens `.env` and `data/watchlist_live_template.csv`.
5. Add your Tradier token and Alpha Vantage key to `.env`.
6. Replace the sample watchlist assumptions with your own approved companies, target prices, position limits, news review, and earnings settings.
7. `4 - Run Live Screen.command` — retrieves live market data and opens the latest report.
8. `6 - Edit Live Positions.command` — opens the live position template.
9. `7 - Run Management Live.command` — evaluates actual positions entered in the template.
10. `8 - Open Latest Reports.command` — reopens the latest screening and management reports.

## If macOS blocks a launcher

Because the files were downloaded from the internet, macOS may require an explicit first open.

- Control-click the `.command` file and choose **Open**, or
- Open Terminal in the project folder and run:

```bash
chmod +x *.command *.sh
```

Then double-click the launcher again.

## Terminal method

The Finder launchers call these scripts, which can also be run directly:

```bash
cd /path/to/acquisition_first_put_system
chmod +x *.command *.sh
./setup_mac.sh
./run_demo_mac.sh
./run_management_demo_mac.sh
```

For live mode:

```bash
./run_live_mac.sh
./run_management_live_mac.sh
```

## Optional Jupyter notebook support

The screen and management system do not require Jupyter. To use the included notebook, run this after setup:

```bash
.venv/bin/python -m pip install -e '.[notebook]'
```

Then launch:

```bash
.venv/bin/python -m jupyter lab
```

## Output locations

Screening report:

```text
output/latest/decision_report.html
```

Position-management report:

```text
output/management_latest/position_management_report.html
```

The scripts automatically open these reports in the default browser after a successful run.

## Important live-mode inputs

The program does not decide whether a company is worth owning. You must maintain:

- `ownership_approved`
- `thesis_intact`
- `target_entry_price`
- `earnings_bear_case_price` for intentional earnings trades
- desired and maximum share counts
- `manual_news_clear`
- API credentials in `.env`

A `SELL` output is a decision-support result, not an automatic order.
