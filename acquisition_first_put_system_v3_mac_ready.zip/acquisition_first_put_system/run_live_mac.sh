#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT_DIR"
PYTHON="$ROOT_DIR/.venv/bin/python"

if [ ! -x "$PYTHON" ]; then
    printf 'Setup has not been completed. Run ./setup_mac.sh first.\n' >&2
    exit 1
fi

if [ ! -f .env ]; then
    printf '.env is missing. Run ./setup_mac.sh first.\n' >&2
    exit 1
fi

if grep -Eq 'replace_me|your_actual_|your_token|your_key' .env; then
    printf 'Live API credentials are still placeholders in .env.\n' >&2
    printf 'Add your Tradier token and Alpha Vantage key, then rerun.\n' >&2
    exit 1
fi

printf 'Using data/watchlist_live_template.csv. Review its ownership, valuation, news, and earnings fields before relying on the results.\n'

"$PYTHON" -m put_seller.cli \
    --task screen \
    --mode live \
    --config config/config.yaml \
    --watchlist data/watchlist_live_template.csv

REPORT="$ROOT_DIR/output/latest/decision_report.html"
if [ -f "$REPORT" ] && command -v open >/dev/null 2>&1; then
    open "$REPORT"
fi
