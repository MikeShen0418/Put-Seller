# Earnings-Acquisition Guide

Use this mode only when the company is already approved for ownership and you are deliberately willing to accept the binary earnings event.

## Required watchlist settings

```csv
earnings_mode,earnings_trade_approved,earnings_bear_case_price,earnings_min_30d_roi,earnings_max_contracts
acquisition,true,150,0.03,1
```

The ordinary `target_entry_price` remains useful for non-event expirations. The event contract is judged against `earnings_bear_case_price`.

## Pre-trade questions

1. Would I still want the company after a disappointing but thesis-intact quarter?
2. Does the bear-case value reflect lower growth, margins, or guidance?
3. Is the net assignment basis at or below that bear case?
4. What move is the ATM straddle pricing?
5. How does the proposed basis compare with the implied lower price?
6. What was the largest historical earnings decline I am willing to use as context?
7. Is the position small enough that a gap through multiple strikes is tolerable?
8. Am I comfortable missing a large upside rally because put profit is capped?

## Reading the scenario file

`earnings_scenarios.csv` contains:

- `modeled_put_close_cost` — illustrative post-event option value after the configured IV decline;
- `modeled_short_put_pnl_per_contract` — hypothetical mark-to-market P/L immediately after the event;
- `expiration_short_put_pnl_per_contract` — payoff if the scenario stock price also applies at expiration;
- `stock_pnl_per_100_shares` — P/L from buying 100 shares before earnings;
- `short_put_minus_stock_pnl_at_expiration` — which position performs better in that scenario.

The model is educational, not predictive. Actual option repricing depends on the realized gap, remaining time, skew, liquidity, dividends, and market conditions.

## Default controls

```text
Event ROI hurdle:             3% per 30 days
Event DTE window:             10–30 DTE; 21 DTE target
Entry window:                 1–10 days before earnings
Preferred timing:             about 3 days before earnings
Maximum time after earnings:  14 days
Normal sizing multiplier:     50%
Maximum event cash/ticker:    12.5% of total cash
```

Edit `config/config.yaml` to change them.
