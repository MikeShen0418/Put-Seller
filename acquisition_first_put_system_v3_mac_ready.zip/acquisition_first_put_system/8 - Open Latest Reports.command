#!/bin/zsh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

OPENED=0
if [ -f output/latest/decision_report.html ]; then
    open output/latest/decision_report.html
    OPENED=1
fi
if [ -f output/management_latest/position_management_report.html ]; then
    open output/management_latest/position_management_report.html
    OPENED=1
fi
if [ "$OPENED" -eq 0 ]; then
    printf 'No latest reports were found. Run the demo or live screen first.\n'
fi

printf '\nPress Return to close this window...'
read -r REPLY
