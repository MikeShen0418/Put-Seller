@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python -m put_seller.cli --task manage --mode demo --as-of 2026-10-21 --config config\config.yaml --positions data\open_positions_demo.csv
if exist output\management_latest\position_management_report.html start "" output\management_latest\position_management_report.html
pause
