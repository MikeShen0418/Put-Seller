#!/bin/zsh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

if [ ! -f .env ]; then
    cp .env.example .env
fi

open -a TextEdit .env
open data/watchlist_live_template.csv

printf '\nOpened .env and the live watchlist.\n'
printf 'Add API credentials and review every ownership, valuation, news, and earnings field before live use.\n'
printf '\nPress Return to close this window...'
read -r REPLY
