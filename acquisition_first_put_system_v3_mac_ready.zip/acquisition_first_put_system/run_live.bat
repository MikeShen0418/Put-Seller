@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
echo Edit .env and data\watchlist_live_template.csv before continuing.
echo target_entry_price must be positive and manual_news_clear must be true after review.
echo Earnings trades also require earnings_mode=acquisition, explicit approval, and a bear-case price.
python -m put_seller.cli --task screen --mode live --config config\config.yaml --watchlist data\watchlist_live_template.csv
if exist output\latest\decision_report.html start "" output\latest\decision_report.html
pause
