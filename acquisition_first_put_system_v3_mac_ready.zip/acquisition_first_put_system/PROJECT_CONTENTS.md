# Package Contents

- `README.md` — full system overview and operating instructions.
- `QUICK_START.md` — first-run instructions for Windows and Mac.
- `MAC_QUICK_START.md` — Finder launchers, Apple Silicon/Intel setup, Gatekeeper help, and live-mode instructions.
- `STRATEGY_PLAYBOOK.md` — consolidated strategy logic from the discussion.
- `EARNINGS_ACQUISITION_GUIDE.md` — event-trade fields, questions, and scenario interpretation.
- `CHANGELOG.md` — version history.
- `config/config.yaml` — ordinary and earnings return, timing, valuation, scenario, and sizing rules.
- `data/watchlist_dummy.csv` — working synthetic example with ordinary and earnings cases.
- `data/watchlist_live_template.csv` — template for your approved companies.
- `data/open_positions_demo.csv` — short-put and assigned-share examples.
- `data/open_positions_template.csv` — live position-management template.
- `notebooks/Acquisition_First_Put_System.ipynb` — walkthrough notebook.
- `put_seller/` — Python source code.
- `tests/` — 11 automated tests.
- `output/latest/` — sample screen, shortlist, earnings scenarios, and allocation.
- `output/management_latest/` — sample position-management report.
- Windows `.bat` launchers, Mac `.sh` scripts, and Finder-double-click `.command` launchers.
