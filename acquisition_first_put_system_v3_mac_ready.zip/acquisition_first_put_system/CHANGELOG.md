# Changelog

## Version 0.3.1 — macOS usability revision

- Confirmed the Python source is cross-platform and contains no Windows-only path handling.
- Added Finder-double-click `.command` launchers for setup, demo, live screening, management, editing inputs, and opening reports.
- Strengthened `setup_mac.sh` with Python version checks, Apple Silicon/Intel architecture reporting, editable package installation, and automatic validation tests.
- Changed Mac run scripts to use the virtual-environment interpreter directly instead of depending on shell activation.
- Added placeholder-credential checks before live runs.
- Added `MAC_QUICK_START.md` with Gatekeeper troubleshooting and both Finder and Terminal workflows.
- Preserved the existing Windows launchers and cross-platform Python logic.
- Removed an unused Matplotlib runtime dependency and moved Jupyter packages into an optional notebook extra to simplify macOS installation.

## Version 0.3.0 — earnings-acquisition revision

- Replaced the simple earnings waiver with a separate `EARNINGS_ACQUISITION` strategy.
- Added explicit event approval and `earnings_mode` watchlist controls.
- Added a required post-report `earnings_bear_case_price` gate.
- Added a separate default 3% gross 30-day event return hurdle.
- Added configurable event timing: entry window and maximum days after earnings.
- Added a separate 10–30 DTE event search so earnings contracts are not incorrectly forced through the ordinary 24–38 DTE profile.
- Added smaller event sizing through contract and per-ticker cash caps.
- Changed option-chain retrieval to use complete put/call chains for ATM-straddle calculations.
- Added ATM-straddle implied move, implied lower price, and implied upper price.
- Added basis comparisons against the implied lower price and optional historical worst earnings drop.
- Added stock-versus-short-put crossover prices.
- Added `earnings_scenarios.csv` with implied-up, unchanged, implied-down, bear-case, and historical-worst outcomes.
- Added an illustrative post-event IV-crush reprice and separate expiration payoff.
- Updated the HTML dashboard, shortlist, allocation report, and run summary.
- Added `EARNINGS_ACQUISITION_GUIDE.md`.
- Expanded the strategy playbook and quick-start guide.
- Expanded the automated suite from 5 to 11 tests.

## Version 0.2.0 — acquisition-first revision

- Reframed the project from a generic premium/yield screener to a stock-acquisition system.
- Added mandatory ownership approval and thesis hierarchy.
- Added `target_entry_price` as the primary regular-contract gate.
- Added `net_assignment_basis = strike - premium`.
- Added `max_cycle_roi = premium / strike` using the full secured cash denominator.
- Added compounded 30-day-equivalent ROI.
- Added a default 2% gross 30-day target.
- Added a high-premium review flag for 4%+ opportunities.
- Made delta secondary to valuation.
- Added desired-share and maximum-share assignment sizing.
- Added `NO TRADE` as a separate outcome from policy rejection.
- Added position management and covered-call screening.
- Added Windows and Mac launch scripts.
