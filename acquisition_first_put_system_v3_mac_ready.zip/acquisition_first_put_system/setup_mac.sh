#!/bin/sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT_DIR"

printf 'Acquisition-First Put System - macOS setup\n'
printf 'Project folder: %s\n' "$ROOT_DIR"
printf 'Machine: %s (%s)\n' "$(uname -s)" "$(uname -m)"

if [ "$(uname -s)" != "Darwin" ]; then
    printf 'Warning: this launcher is intended for macOS, but setup will continue.\n'
fi

if ! command -v python3 >/dev/null 2>&1; then
    printf '\nPython 3 was not found. Install Python 3.10 or newer, then rerun this file.\n'
    printf 'Common macOS option after installing Homebrew: brew install python\n'
    exit 1
fi

if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)'; then
    printf '\nPython 3.10 or newer is required. Detected: '
    python3 --version || true
    printf 'Install a newer Python version, then rerun this file.\n'
    exit 1
fi

printf 'Python: %s\n' "$(python3 --version 2>&1)"

if [ ! -x .venv/bin/python ]; then
    printf '\nCreating the private Python environment...\n'
    python3 -m venv .venv
else
    printf '\nUsing the existing private Python environment.\n'
fi

PYTHON="$ROOT_DIR/.venv/bin/python"

printf 'Installing or updating required packages...\n'
"$PYTHON" -m pip install --upgrade pip setuptools wheel
"$PYTHON" -m pip install -r requirements.txt
"$PYTHON" -m pip install -e .

if [ ! -f .env ]; then
    cp .env.example .env
    printf 'Created .env from .env.example.\n'
else
    printf 'Existing .env was preserved.\n'
fi

printf '\nRunning the built-in validation tests...\n'
"$PYTHON" -m pytest -q

printf '\nSetup complete.\n'
printf 'Next: double-click "2 - Run Demo.command" or run ./run_demo_mac.sh in Terminal.\n'
