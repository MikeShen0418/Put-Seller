# Strategy Playbook

This document consolidates the reasoning behind the code.

## 1. Start with the shares, not the premium

The strategy begins with:

> I want to own this company, but I do not have enough confidence to buy it at today’s price. I will sell a cash-secured put at a valuation-supported price. If assigned, I acquire the stock at an acceptable premium-adjusted basis. If not assigned, I keep the premium.

A cash-secured put is therefore a paid conditional purchase order.

The sequence is:

```text
company quality -> valuation -> target price -> option selection -> volatility and timing
```

not:

```text
large premium -> high IV -> invent a reason to own the company
```

## 2. Price first, delta second

For a regular acquisition put:

```text
strike - premium <= ordinary target entry price
```

For an earnings-acquisition put:

```text
strike - premium <= post-earnings bear-case price
```

Delta is not the percentage distance below the stock. It describes current option sensitivity and roughly characterizes aggressiveness. The system uses a broad delta range because valuation should determine the strike.

## 3. Return on secured cash

Ignoring money-market interest:

```text
ROI = premium / strike
```

For one contract:

```text
premium income = premium × 100
cash secured = strike × 100
```

The 100s cancel.

For contracts with different expirations:

```text
30-day-equivalent ROI = (1 + cycle ROI)^(30 / DTE) - 1
```

The working ordinary target is about 2% gross per 30 days. The default event target is 3%. A 4%–5% opportunity receives more scrutiny rather than automatic preference.

## 4. Why approximately 30 DTE

Around 30 days offers a practical compromise:

- faster capital turnover than long-dated options;
- meaningful time decay;
- generally usable liquidity;
- more premium than very short contracts;
- less final-week gamma concentration than a seven-day option.

The system uses a range rather than forcing exactly 30 days.

## 5. High volatility

High IV means the options market prices a wide range of outcomes. It may reflect disagreement, but it may also reflect:

- earnings;
- litigation or regulation;
- financing stress;
- product uncertainty;
- a real deterioration in the business;
- heavy downside hedging demand.

The system compares IV with recent realized volatility and stored IV history, but high IV is supporting information, not the ownership thesis.

## 6. Red-day entries for regular puts

A red day can improve put premium through both the stock move and IV expansion. The preferred regular setup is:

- pullback inside an intact or stable trend;
- approximately one ATR down;
- some recovery from the session low;
- no new fundamental damage;
- no multi-day collapse;
- no earnings inside the contract.

The system may return `WATCH` until stabilization appears.

## 7. Earnings are a separate strategy

The earlier blanket statement “never sell puts before earnings” is too broad for an acquisition-first investor. Selling a put through earnings can be rational when you truly want the shares at a lower price.

But the correct trade is not:

> IV will crash, so the put must make money.

It is:

> I am being paid an elevated premium to commit to buying the stock after a major information event at a net price that remains attractive under a weak-report bear case.

The system therefore requires:

```text
explicit event approval
post-report bear-case price
ATM-straddle implied move
higher event ROI hurdle
smaller position size
short event-focused expiration
```

Event contracts use a separate default 10–30 DTE search with a 21 DTE
preference. This matters because a put opened only a few days before earnings
and expiring shortly afterward will often be shorter than the ordinary 24–38
DTE acquisition window.

## 8. What IV crush can and cannot do

Before earnings, IV often rises. After the report, event uncertainty often disappears and IV falls. That benefits a short put through negative vega.

However:

```text
put value = intrinsic value + extrinsic value
```

IV crush reduces extrinsic value. It cannot erase intrinsic value:

```text
intrinsic value = max(strike - stock price, 0)
```

If a $90 put faces a stock at $70, it has about $20 of intrinsic value regardless of how much IV fell. The event premium is a fixed buffer, not open-ended downside protection.

## 9. Implied earnings move

The system uses the ATM straddle:

```text
implied move % = (ATM call midpoint + ATM put midpoint) / stock price
```

This produces an approximate upper and lower market-implied price. It is not a hard boundary. Earnings returns have fat tails and can exceed the straddle-implied move.

A strong event-acquisition setup has:

- net basis at or below the post-report bear case;
- preferably net basis near or below the implied lower price;
- acceptable historical earnings-gap context;
- explicit willingness to own the shares after a disappointing but thesis-intact report.

## 10. Short put versus buying the stock before earnings

The short put usually performs better when the stock is:

- flat;
- modestly higher;
- moderately lower;
- below the strike but not far below the net basis.

Buying the stock performs better when the stock rallies strongly because the short put’s maximum profit is capped at the premium.

The system displays:

```text
Equal dollar-P/L stock price = spot + premium
Equal ROI stock price = spot × (1 + put cycle ROI)
```

Above the crossover, direct stock ownership wins. Below it, the put can win because of the premium and lower effective basis.

## 11. Earnings scenario analysis

For explicitly approved event trades, the system compares:

```text
upper implied move
unchanged stock
lower implied move
bear-case value
historical worst earnings drop, when supplied
```

It shows both:

- an illustrative post-event reprice after a configurable IV decline; and
- the expiration payoff, which no longer depends on IV.

The modeled reprice is not a prediction. It exists to demonstrate why unchanged or modestly moving stocks may benefit from IV crush while a large downside gap can still dominate.

## 12. Assignment

Assignment is not the worst case. It is an intended possible outcome when the thesis remains intact.

The real adverse case is:

- the business deteriorates;
- the target valuation was wrong;
- the stock falls far below the assignment basis;
- the assigned position is too large.

When the stock declines, ask:

> Knowing today’s information, would I voluntarily buy the shares at the premium-adjusted basis?

- Yes: assignment can be accepted.
- No: close the put.
- Considering a roll: evaluate the replacement as a new independent trade.

## 13. Buying back and taking profit

Maximum gain is the premium received.

```text
realized option profit = premium received - buyback cost
```

The manager defaults to reviewing a take-profit after 65% of the original premium has been captured. This reduces exposure to the remaining event or gamma risk when relatively little premium remains.

## 14. Rolling

A roll closes the old put and opens a new put. It does not erase the first trade’s loss.

Rule:

> Roll only when the new strike, expiration, basis, return, earnings exposure, and position size would independently qualify today.

## 15. Covered calls after assignment

After assignment, the original put premium lowers the economic basis. Later call premiums can lower it further.

The system normally requires:

```text
call strike + call premium >= adjusted stock basis
```

Covered calls help in flat or modestly recovering markets. They do not guarantee recovery. If the stock collapses, calls at the old basis may pay very little; calls closer to the stock can cap a rebound below your basis.

Do not sell a call unless you are willing to surrender the shares at the strike.

## 16. Benchmarking against QQQ

Do not compare a quoted premium yield directly with QQQ’s total return. Real strategy return includes:

```text
option P/L
+ assigned-stock mark-to-market
+ dividends
+ collateral interest when included
- fees
- taxes
```

The 2% monthly number is an opportunity filter. The 20% after-tax objective should be assessed from actual rolling 12-month portfolio values.

## 17. No-trade discipline

A valid system must be able to say `NO TRADE`.

Do not:

- raise the target purchase price to make a contract fit;
- choose a weaker company because its IV is higher;
- cross earnings accidentally;
- use the ordinary target as the event bear case;
- force all cash to be deployed;
- use covered calls to disguise a broken thesis;
- assume IV crush guarantees a profit.
