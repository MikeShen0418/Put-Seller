@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
echo Edit data\open_positions_template.csv before continuing.
python -m put_seller.cli --task manage --mode live --config config\config.yaml --positions data\open_positions_template.csv
if exist output\management_latest\position_management_report.html start "" output\management_latest\position_management_report.html
pause
