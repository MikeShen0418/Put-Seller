#!/bin/zsh
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

open data/open_positions_template.csv

printf '\nOpened the live positions template. Enter actual short puts or assigned shares before running management.\n'
printf '\nPress Return to close this window...'
read -r REPLY
