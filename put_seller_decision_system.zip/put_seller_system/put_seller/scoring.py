from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    if not np.isfinite(value):
        return 0.0
    return float(min(max(value, low), high))


def _linear_score(value: float, poor: float, excellent: float) -> float:
    if excellent == poor:
        return 100.0 if value >= excellent else 0.0
    return _clamp(100.0 * (value - poor) / (excellent - poor))


def _bell_score(value: float, center: float, width: float) -> float:
    width = max(width, 1e-6)
    return _clamp(100.0 * math.exp(-((value - center) / width) ** 2))


def score_candidates(
    candidates: pd.DataFrame,
    config: dict[str, Any],
    manual_news_clear: bool,
    iv_percentile: float,
    iv_history_days: int,
) -> pd.DataFrame:
    if candidates.empty:
        return candidates.copy()

    frame = candidates.copy()
    profile = config["profile"]
    decision = config["decision"]
    filters = decision["filters"]
    entry = decision["entry"]
    targets = decision["score_targets"]
    weights = decision["weights"]

    rows: list[dict[str, Any]] = []
    for _, source in frame.iterrows():
        row = source.to_dict()
        failures: list[str] = []
        warnings: list[str] = []
        positives: list[str] = []

        dte = float(row.get("dte", np.nan))
        abs_delta = float(row.get("abs_delta", np.nan))
        spread_pct = float(row.get("spread_pct", np.nan))
        open_interest = float(row.get("open_interest", 0) or 0)
        volume = float(row.get("volume", 0) or 0)
        bid = float(row.get("bid", 0) or 0)
        iv_rv = float(row.get("iv_rv_ratio", np.nan))
        down_atr = float(row.get("down_move_atr", np.nan))
        close_off_low = float(row.get("close_off_low_atr", np.nan))
        drop_5d_atr = float(row.get("drop_5d_atr", np.nan))
        price_to_sma50 = float(row.get("price_to_sma50", np.nan))

        if not (profile["min_dte"] <= dte <= profile["max_dte"]):
            failures.append("DTE outside active profile")
        if not (profile["min_abs_delta"] <= abs_delta <= profile["max_abs_delta"]):
            failures.append("Delta outside active profile")
        if not bool(row.get("is_otm", False)):
            failures.append("Strike is not out of the money")
        if bid < filters["min_bid"]:
            failures.append("Bid is too small")
        if not np.isfinite(spread_pct) or spread_pct > filters["max_spread_pct"]:
            failures.append("Bid-ask spread is too wide")
        if open_interest < filters["min_open_interest"]:
            failures.append("Open interest is too low")
        if volume < filters["min_volume"]:
            failures.append("Option volume is too low")
        if np.isfinite(iv_rv) and iv_rv < filters["min_iv_rv_ratio"]:
            failures.append("IV is not rich enough versus realized volatility")

        target_breakeven = row.get("max_breakeven_price")
        if target_breakeven is not None and pd.notna(target_breakeven):
            if float(row.get("breakeven", np.inf)) > float(target_breakeven):
                failures.append("Breakeven is above the ticker-specific target price")
        ticker_min_yield = row.get("ticker_min_annualized_yield")
        if ticker_min_yield is not None and pd.notna(ticker_min_yield):
            if float(row.get("annualized_max_yield", -np.inf)) < float(ticker_min_yield):
                failures.append("Annualized yield is below the ticker-specific minimum")

        if filters.get("require_manual_news_clear", True) and not manual_news_clear:
            failures.append("Manual news check is not clear")

        earnings_known = bool(row.get("earnings_known", False))
        earnings_crosses = bool(row.get("earnings_crosses", False))
        if filters.get("require_earnings_clear", True):
            if not earnings_known and filters.get("unknown_earnings_action", "reject") == "reject":
                failures.append("Next earnings date is unknown")
            elif earnings_crosses:
                failures.append("Option crosses earnings or earnings buffer")

        panic = False
        if np.isfinite(down_atr) and down_atr > entry["panic_down_move_atr"]:
            failures.append("Down move is in the panic zone")
            panic = True
        if np.isfinite(drop_5d_atr) and drop_5d_atr > entry["max_5d_drop_atr"]:
            failures.append("Five-day decline is too large")
            panic = True
        if np.isfinite(price_to_sma50) and price_to_sma50 < entry["hard_min_price_to_sma50"]:
            failures.append("Price is too far below the 50-day average")
            panic = True

        entry_ready = (
            np.isfinite(down_atr)
            and entry["min_down_move_atr"] <= down_atr <= entry["max_down_move_atr"]
            and np.isfinite(close_off_low)
            and close_off_low >= entry["min_close_off_low_atr"]
            and not panic
        )
        if not entry_ready and not failures:
            if down_atr < entry["min_down_move_atr"]:
                warnings.append("No meaningful red-day premium expansion yet")
            elif down_atr > entry["max_down_move_atr"]:
                warnings.append("Decline is too sharp; wait for stabilization")
            if close_off_low < entry["min_close_off_low_atr"]:
                warnings.append("Stock is still closing near the session low")

        annualized_yield = float(row.get("annualized_max_yield", np.nan))
        yield_score = _linear_score(
            annualized_yield,
            targets["annualized_yield_poor"],
            targets["annualized_yield_excellent"],
        )

        ratio_score = _linear_score(
            iv_rv,
            targets["iv_rv_poor"],
            targets["iv_rv_excellent"],
        )
        history_confidence = min(iv_history_days / max(targets["min_iv_history_days"], 1), 1.0)
        iv_percentile_effective = 50.0 + (float(iv_percentile) - 50.0) * history_confidence
        vol_score = 0.55 * ratio_score + 0.45 * iv_percentile_effective

        entry_score = _bell_score(
            down_atr,
            entry["ideal_down_move_atr"],
            entry["entry_bell_width"],
        )
        recovery_score = _linear_score(
            close_off_low,
            0.0,
            entry["excellent_close_off_low_atr"],
        )
        entry_score = 0.72 * entry_score + 0.28 * recovery_score

        price_to_sma_score = _linear_score(
            price_to_sma50,
            targets["price_to_sma50_poor"],
            targets["price_to_sma50_excellent"],
        )
        return20_score = _linear_score(
            float(row.get("return_20d", np.nan)),
            targets["return_20d_poor"],
            targets["return_20d_excellent"],
        )
        slope_score = _linear_score(
            float(row.get("slope20_annualized", np.nan)),
            targets["slope20_poor"],
            targets["slope20_excellent"],
        )
        trend_score = 0.45 * price_to_sma_score + 0.30 * return20_score + 0.25 * slope_score

        spread_score = _linear_score(
            -spread_pct,
            -filters["max_spread_pct"],
            -targets["excellent_spread_pct"],
        )
        oi_score = _linear_score(
            math.log1p(max(open_interest, 0)),
            math.log1p(filters["min_open_interest"]),
            math.log1p(targets["excellent_open_interest"]),
        )
        volume_score = _linear_score(
            math.log1p(max(volume, 0)),
            math.log1p(filters["min_volume"]),
            math.log1p(targets["excellent_volume"]),
        )
        liquidity_score = 0.45 * spread_score + 0.35 * oi_score + 0.20 * volume_score

        distance_em = float(row.get("strike_distance_expected_move", np.nan))
        breakeven_discount = float(row.get("breakeven_discount", np.nan))
        distance_score = _linear_score(
            distance_em,
            targets["distance_em_poor"],
            targets["distance_em_excellent"],
        )
        breakeven_score = _linear_score(
            breakeven_discount,
            targets["breakeven_discount_poor"],
            targets["breakeven_discount_excellent"],
        )
        delta_preference_score = _bell_score(
            abs_delta,
            profile["preferred_abs_delta"],
            profile["delta_preference_width"],
        )
        buffer_score = 0.45 * distance_score + 0.35 * breakeven_score + 0.20 * delta_preference_score

        component_scores = {
            "yield_score": yield_score,
            "vol_score": vol_score,
            "entry_score": entry_score,
            "trend_score": trend_score,
            "liquidity_score": liquidity_score,
            "buffer_score": buffer_score,
        }
        total_score = sum(component_scores[name] * float(weights[name]) for name in component_scores)
        total_score = _clamp(total_score)

        if annualized_yield >= targets["annualized_yield_excellent"]:
            positives.append("Strong annualized premium yield")
        if iv_rv >= targets["iv_rv_excellent"]:
            positives.append("IV is rich versus realized volatility")
        if iv_percentile_effective >= 70:
            positives.append("IV is elevated versus its stored history")
        if entry_ready:
            positives.append("Red-day entry and stabilization conditions are met")
        if spread_pct <= targets["excellent_spread_pct"]:
            positives.append("Liquid option market")
        if distance_em >= targets["distance_em_excellent"]:
            positives.append("Strike has a meaningful implied-move buffer")

        if failures:
            status = "REJECT"
        elif entry_ready and total_score >= decision["sell_score"]:
            status = "SELL"
        elif total_score >= decision["watch_score"]:
            status = "WATCH"
        else:
            status = "SKIP"

        if status == "WATCH" and not warnings:
            warnings.append("Composite score is below the SELL threshold")
        elif status == "SKIP" and not warnings:
            warnings.append("Composite score is below the WATCH threshold")

        row.update(component_scores)
        row.update(
            {
                "iv_percentile": float(iv_percentile),
                "iv_percentile_effective": float(iv_percentile_effective),
                "iv_history_days": int(iv_history_days),
                "entry_ready": bool(entry_ready),
                "hard_failure_count": len(failures),
                "decision_score": round(total_score, 2),
                "decision": status,
                "failure_reasons": "; ".join(failures),
                "warnings": "; ".join(warnings),
                "positive_signals": "; ".join(positives),
            }
        )
        rows.append(row)

    return pd.DataFrame(rows)
