from __future__ import annotations

import math


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


def black_scholes_put(
    spot: float,
    strike: float,
    time_years: float,
    rate: float,
    volatility: float,
    dividend_yield: float = 0.0,
) -> dict[str, float]:
    """Return European put price and Greeks for deterministic demo generation."""
    if min(spot, strike, time_years, volatility) <= 0:
        raise ValueError("spot, strike, time_years and volatility must be positive")

    sqrt_t = math.sqrt(time_years)
    d1 = (
        math.log(spot / strike)
        + (rate - dividend_yield + 0.5 * volatility * volatility) * time_years
    ) / (volatility * sqrt_t)
    d2 = d1 - volatility * sqrt_t

    discount_r = math.exp(-rate * time_years)
    discount_q = math.exp(-dividend_yield * time_years)
    price = (
        strike * discount_r * norm_cdf(-d2)
        - spot * discount_q * norm_cdf(-d1)
    )
    delta = -discount_q * norm_cdf(-d1)
    gamma = discount_q * norm_pdf(d1) / (spot * volatility * sqrt_t)
    vega = spot * discount_q * norm_pdf(d1) * sqrt_t / 100.0

    # Theta is returned per calendar day.
    theta_annual = (
        -spot * discount_q * norm_pdf(d1) * volatility / (2.0 * sqrt_t)
        + rate * strike * discount_r * norm_cdf(-d2)
        - dividend_yield * spot * discount_q * norm_cdf(-d1)
    )
    theta = theta_annual / 365.0

    return {
        "price": max(price, 0.0),
        "delta": delta,
        "gamma": gamma,
        "theta": theta,
        "vega": vega,
    }
