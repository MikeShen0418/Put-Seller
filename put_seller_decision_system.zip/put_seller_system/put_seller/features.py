from __future__ import annotations

import math
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd


def compute_underlying_features(history: pd.DataFrame, quote: dict[str, Any]) -> dict[str, float]:
    """Compute price, trend, realized-volatility and entry-timing features."""
    if history.empty or len(history) < 60:
        raise ValueError("At least 60 daily bars are required")

    frame = history.copy().sort_values("date").reset_index(drop=True)
    for column in ["open", "high", "low", "close", "volume"]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame = frame.dropna(subset=["high", "low", "close"])
    if len(frame) < 60:
        raise ValueError("Too few valid daily bars after numeric cleaning")

    previous_close = frame["close"].shift(1)
    true_range = pd.concat(
        [
            frame["high"] - frame["low"],
            (frame["high"] - previous_close).abs(),
            (frame["low"] - previous_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    atr20 = float(true_range.tail(20).mean())

    log_returns = np.log(frame["close"] / frame["close"].shift(1)).dropna()
    rv20 = float(log_returns.tail(20).std(ddof=1) * math.sqrt(252.0))
    rv60 = float(log_returns.tail(60).std(ddof=1) * math.sqrt(252.0))

    spot = float(quote["spot"])
    prev_close = float(quote.get("prev_close") or frame.iloc[-2]["close"])
    day_low = float(quote.get("low") or spot)
    day_high = float(quote.get("high") or spot)
    atr20 = max(atr20, spot * 0.001)

    sma20 = float(frame["close"].tail(20).mean())
    sma50 = float(frame["close"].tail(50).mean())
    sma200 = float(frame["close"].tail(min(200, len(frame))).mean())
    close_5d_ago = float(frame["close"].iloc[-6]) if len(frame) >= 6 else prev_close
    close_20d_ago = float(frame["close"].iloc[-21]) if len(frame) >= 21 else prev_close

    # Negative daily_move_atr means a down day; down_move_atr is positive on a decline.
    daily_move_atr = (spot - prev_close) / atr20
    down_move_atr = (prev_close - spot) / atr20
    close_off_low_atr = (spot - day_low) / atr20
    intraday_range_atr = (day_high - day_low) / atr20
    drop_5d_atr = max(0.0, (close_5d_ago - spot) / atr20)

    x = np.arange(min(20, len(frame)), dtype=float)
    y = np.log(frame["close"].tail(len(x)).to_numpy(dtype=float))
    slope20_annualized = float(np.polyfit(x, y, 1)[0] * 252.0) if len(x) >= 5 else 0.0

    return {
        "spot": spot,
        "prev_close": prev_close,
        "daily_return": spot / prev_close - 1.0 if prev_close else 0.0,
        "atr20": atr20,
        "atr20_pct": atr20 / spot if spot else np.nan,
        "daily_move_atr": daily_move_atr,
        "down_move_atr": down_move_atr,
        "close_off_low_atr": close_off_low_atr,
        "intraday_range_atr": intraday_range_atr,
        "drop_5d_atr": drop_5d_atr,
        "rv20": rv20,
        "rv60": rv60,
        "sma20": sma20,
        "sma50": sma50,
        "sma200": sma200,
        "price_to_sma20": spot / sma20 if sma20 else np.nan,
        "price_to_sma50": spot / sma50 if sma50 else np.nan,
        "price_to_sma200": spot / sma200 if sma200 else np.nan,
        "return_5d": spot / close_5d_ago - 1.0 if close_5d_ago else 0.0,
        "return_20d": spot / close_20d_ago - 1.0 if close_20d_ago else 0.0,
        "slope20_annualized": slope20_annualized,
    }


def enrich_option_chain(
    chain: pd.DataFrame,
    quote: dict[str, Any],
    underlying: dict[str, float],
    as_of: date,
    earnings_date: date | None,
    execution_fraction_from_bid: float = 0.35,
    earnings_buffer_days: int = 2,
) -> pd.DataFrame:
    """Add cash yield, buffer, expected-move, liquidity and earnings features."""
    if chain.empty:
        return chain.copy()

    frame = chain.copy()
    numeric_columns = [
        "strike",
        "bid",
        "ask",
        "last",
        "volume",
        "open_interest",
        "delta",
        "gamma",
        "theta",
        "vega",
        "iv",
    ]
    for column in numeric_columns:
        if column in frame.columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")

    frame["expiration"] = pd.to_datetime(frame["expiration"]).dt.date
    frame["dte"] = frame["expiration"].map(lambda value: max((value - as_of).days, 0))
    frame["abs_delta"] = frame["delta"].abs()
    frame["midpoint"] = (frame["bid"] + frame["ask"]) / 2.0
    frame["spread"] = frame["ask"] - frame["bid"]
    frame["spread_pct"] = np.where(
        frame["midpoint"] > 0,
        frame["spread"] / frame["midpoint"],
        np.nan,
    )
    fraction = min(max(float(execution_fraction_from_bid), 0.0), 1.0)
    frame["estimated_fill"] = frame["bid"] + fraction * frame["spread"].clip(lower=0)
    frame["estimated_fill"] = frame[["estimated_fill", "ask"]].min(axis=1)
    frame["estimated_fill"] = frame["estimated_fill"].clip(lower=0)

    spot = float(quote["spot"])
    rv20 = max(float(underlying["rv20"]), 1e-6)
    frame["cash_required"] = frame["strike"] * 100.0
    frame["premium_dollars"] = frame["estimated_fill"] * 100.0
    frame["max_cycle_yield"] = np.where(
        frame["strike"] > 0,
        frame["estimated_fill"] / frame["strike"],
        np.nan,
    )
    frame["annualized_max_yield"] = np.where(
        frame["dte"] > 0,
        frame["max_cycle_yield"] * 365.0 / frame["dte"],
        np.nan,
    )
    frame["breakeven"] = frame["strike"] - frame["estimated_fill"]
    frame["strike_discount"] = (spot - frame["strike"]) / spot
    frame["breakeven_discount"] = (spot - frame["breakeven"]) / spot
    frame["expected_move"] = spot * frame["iv"] * np.sqrt(frame["dte"] / 365.0)
    frame["strike_distance_expected_move"] = np.where(
        frame["expected_move"] > 0,
        (spot - frame["strike"]) / frame["expected_move"],
        np.nan,
    )
    frame["iv_rv_ratio"] = frame["iv"] / rv20
    frame["is_otm"] = frame["strike"] < spot

    if earnings_date is None:
        frame["earnings_date"] = pd.NaT
        frame["days_to_earnings"] = np.nan
        frame["earnings_known"] = False
        frame["earnings_crosses"] = False
    else:
        frame["earnings_date"] = earnings_date
        frame["days_to_earnings"] = (earnings_date - as_of).days
        frame["earnings_known"] = True
        safe_cutoff = frame["expiration"].map(lambda value: value + timedelta(days=earnings_buffer_days))
        frame["earnings_crosses"] = safe_cutoff.map(lambda value: earnings_date <= value)

    for key, value in underlying.items():
        if key not in frame.columns:
            frame[key] = value
    frame["spot"] = spot
    return frame
