from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    """Raised when the configuration is missing required settings."""


def load_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"Config file does not exist: {config_path}")

    with config_path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}

    profile_name = raw.get("active_profile", "balanced")
    profiles = raw.get("profiles", {})
    if profile_name not in profiles:
        raise ConfigError(
            f"active_profile={profile_name!r} was not found under profiles. "
            f"Available profiles: {sorted(profiles)}"
        )

    config = deepcopy(raw)
    config["profile_name"] = profile_name
    config["profile"] = deepcopy(profiles[profile_name])
    _validate(config)
    return config


def _validate(config: dict[str, Any]) -> None:
    required_top = ["watchlist_path", "capital", "decision", "profile"]
    missing = [key for key in required_top if key not in config]
    if missing:
        raise ConfigError(f"Missing top-level config keys: {missing}")

    profile = config["profile"]
    required_profile = [
        "min_dte",
        "max_dte",
        "min_abs_delta",
        "max_abs_delta",
        "preferred_abs_delta",
    ]
    missing_profile = [key for key in required_profile if key not in profile]
    if missing_profile:
        raise ConfigError(f"Missing profile keys: {missing_profile}")

    if profile["min_dte"] > profile["max_dte"]:
        raise ConfigError("profile.min_dte cannot exceed profile.max_dte")
    if profile["min_abs_delta"] > profile["max_abs_delta"]:
        raise ConfigError("profile.min_abs_delta cannot exceed profile.max_abs_delta")

    weights = config["decision"].get("weights", {})
    if weights:
        total = sum(float(value) for value in weights.values())
        if abs(total - 1.0) > 1e-6:
            raise ConfigError(f"decision.weights must sum to 1.0; got {total:.6f}")


def resolve_path(config_file: str | Path, configured_path: str | Path) -> Path:
    """Resolve a path relative to the directory containing the YAML config."""
    configured = Path(configured_path)
    if configured.is_absolute():
        return configured
    return (Path(config_file).resolve().parent / configured).resolve()
