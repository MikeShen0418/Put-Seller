from __future__ import annotations

import math
from typing import Any

import pandas as pd


def _objective_per_contract(row: pd.Series, mode: str) -> float:
    premium = float(row["premium_dollars"])
    dte = max(float(row["dte"]), 1.0)
    score = float(row["decision_score"]) / 100.0
    annualized_premium = premium * 365.0 / dte
    if mode == "premium_dollars":
        return premium
    if mode == "annualized_premium":
        return annualized_premium
    if mode == "quality_adjusted_premium":
        return annualized_premium * max(score, 0.0)
    raise ValueError(f"Unknown optimization objective: {mode}")


def optimize_portfolio(
    best_by_ticker: pd.DataFrame,
    config: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, float]]:
    """Group knapsack: choose 0..N contracts per ticker under cash constraints."""
    capital_cfg = config["capital"]
    total_cash = float(capital_cfg["total_cash"])
    increment = float(capital_cfg.get("cash_increment", 100.0))
    max_ticker_pct = float(capital_cfg.get("max_ticker_pct", 0.25))
    default_max_contracts = int(capital_cfg.get("max_contracts_per_ticker", 2))
    objective_mode = str(capital_cfg.get("objective", "quality_adjusted_premium"))

    eligible = best_by_ticker.loc[best_by_ticker["decision"] == "SELL"].copy()
    if eligible.empty:
        return pd.DataFrame(), {
            "total_cash": total_cash,
            "cash_allocated": 0.0,
            "cash_remaining": total_cash,
            "premium_dollars": 0.0,
            "portfolio_cycle_yield": 0.0,
            "weighted_annualized_yield": 0.0,
            "objective_value": 0.0,
        }

    total_units = int(math.floor(total_cash / increment))
    groups: list[tuple[str, pd.Series, int]] = []
    for _, row in eligible.iterrows():
        cost = float(row["cash_required"])
        if cost <= 0:
            continue
        ticker_cap = int(row.get("max_contracts", default_max_contracts) or default_max_contracts)
        concentration_cap = int(math.floor(total_cash * max_ticker_pct / cost))
        affordability_cap = int(math.floor(total_cash / cost))
        max_count = max(0, min(ticker_cap, concentration_cap, affordability_cap))
        if max_count > 0:
            groups.append((str(row["ticker"]), row, max_count))

    # state[cash_units] = (objective_value, selections)
    state: dict[int, tuple[float, dict[str, int]]] = {0: (0.0, {})}
    for ticker, row, max_count in groups:
        cost_units = int(math.ceil(float(row["cash_required"]) / increment))
        per_contract_value = _objective_per_contract(row, objective_mode)
        next_state: dict[int, tuple[float, dict[str, int]]] = {}
        for used_units, (value, selections) in state.items():
            for count in range(max_count + 1):
                new_units = used_units + count * cost_units
                if new_units > total_units:
                    break
                new_value = value + count * per_contract_value
                existing = next_state.get(new_units)
                if existing is None or new_value > existing[0]:
                    new_selections = selections.copy()
                    if count:
                        new_selections[ticker] = count
                    next_state[new_units] = (new_value, new_selections)
        state = next_state

    best_units, (best_value, selections) = max(
        state.items(), key=lambda item: (item[1][0], item[0])
    )

    rows: list[dict[str, Any]] = []
    for ticker, count in selections.items():
        row = eligible.loc[eligible["ticker"] == ticker].iloc[0].to_dict()
        row["contracts"] = int(count)
        row["allocated_cash"] = float(row["cash_required"]) * count
        row["allocated_premium"] = float(row["premium_dollars"]) * count
        row["objective_contribution"] = _objective_per_contract(pd.Series(row), objective_mode) * count
        rows.append(row)
    allocation = pd.DataFrame(rows)
    if not allocation.empty:
        allocation = allocation.sort_values(
            ["objective_contribution", "decision_score"], ascending=False
        ).reset_index(drop=True)

    cash_allocated = float(allocation["allocated_cash"].sum()) if not allocation.empty else 0.0
    premium = float(allocation["allocated_premium"].sum()) if not allocation.empty else 0.0
    weighted_annualized = (
        float(
            (allocation["annualized_max_yield"] * allocation["allocated_cash"]).sum()
            / cash_allocated
        )
        if cash_allocated > 0
        else 0.0
    )
    summary = {
        "total_cash": total_cash,
        "cash_allocated": cash_allocated,
        "cash_remaining": max(total_cash - cash_allocated, 0.0),
        "premium_dollars": premium,
        "portfolio_cycle_yield": premium / cash_allocated if cash_allocated > 0 else 0.0,
        "weighted_annualized_yield": weighted_annualized,
        "objective_value": float(best_value),
        "cash_units_used": float(best_units),
    }
    return allocation, summary
