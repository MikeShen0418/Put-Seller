from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from dotenv import load_dotenv

from .config import load_config
from .pipeline import run_pipeline
from .providers.demo import DemoProvider
from .providers.tradier import TradierProvider


def build_parser() -> argparse.ArgumentParser:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(
        description="Screen, score and allocate cash-secured put candidates."
    )
    parser.add_argument(
        "--config",
        default=str(project_root / "config" / "config.yaml"),
        help="Path to YAML configuration file.",
    )
    parser.add_argument("--mode", choices=["demo", "live"], default="demo")
    parser.add_argument(
        "--profile",
        choices=["defensive", "balanced", "yield"],
        help="Override active_profile from the YAML file.",
    )
    parser.add_argument("--cash", type=float, help="Override total cash available.")
    parser.add_argument(
        "--watchlist",
        help="Override the watchlist CSV path from the YAML file.",
    )
    parser.add_argument(
        "--as-of",
        help="Demo as-of date in YYYY-MM-DD format. Defaults to today.",
    )
    parser.add_argument("--output-root", help="Optional output directory override.")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    project_root = Path(__file__).resolve().parents[1]
    load_dotenv(project_root / ".env")
    load_dotenv()

    config = load_config(args.config)
    if args.profile:
        config["profile_name"] = args.profile
        config["profile"] = config["profiles"][args.profile].copy()
    if args.cash is not None:
        if args.cash <= 0:
            raise SystemExit("--cash must be positive")
        config["capital"]["total_cash"] = args.cash
    if args.watchlist:
        config["watchlist_path"] = str(Path(args.watchlist).resolve())

    if args.mode == "demo":
        as_of = date.fromisoformat(args.as_of) if args.as_of else None
        provider = DemoProvider(as_of=as_of)
    else:
        provider = TradierProvider()

    result = run_pipeline(
        provider=provider,
        config=config,
        config_path=args.config,
        mode=args.mode,
        output_root_override=args.output_root,
    )

    display_columns = [
        "ticker",
        "decision",
        "decision_score",
        "expiration",
        "strike",
        "abs_delta",
        "estimated_fill",
        "annualized_max_yield",
        "failure_reasons",
        "warnings",
    ]
    available = [column for column in display_columns if column in result.best_by_ticker.columns]
    print("\nBest contract by ticker\n")
    print(result.best_by_ticker[available].to_string(index=False))
    print("\nPortfolio summary\n")
    for key, value in result.portfolio_summary.items():
        print(f"{key}: {value}")
    print(f"\nReport: {result.report_path}")
    print(f"Output directory: {result.output_dir}")


if __name__ == "__main__":
    main()
