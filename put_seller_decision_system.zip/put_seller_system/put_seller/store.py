from __future__ import annotations

from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd


class IVSnapshotStore:
    """Small CSV store used to build each ticker's own IV percentile over time."""

    COLUMNS = ["date", "ticker", "iv_proxy", "source"]

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> pd.DataFrame:
        if not self.path.exists():
            return pd.DataFrame(columns=self.COLUMNS)
        frame = pd.read_csv(self.path)
        if frame.empty:
            return pd.DataFrame(columns=self.COLUMNS)
        frame["date"] = pd.to_datetime(frame["date"], errors="coerce").dt.date
        frame["ticker"] = frame["ticker"].astype(str).str.upper()
        frame["iv_proxy"] = pd.to_numeric(frame["iv_proxy"], errors="coerce")
        return frame.dropna(subset=["date", "ticker", "iv_proxy"])[self.COLUMNS]

    def history(self, ticker: str, lookback: int = 252) -> pd.Series:
        frame = self.load()
        subset = frame.loc[frame["ticker"] == ticker.upper()].sort_values("date")
        return subset["iv_proxy"].tail(lookback).reset_index(drop=True)

    def percentile(self, ticker: str, current_iv: float, lookback: int = 252) -> tuple[float, int]:
        history = self.history(ticker, lookback=lookback)
        if history.empty or not np.isfinite(current_iv):
            return 50.0, 0
        percentile = 100.0 * float((history <= current_iv).mean())
        return percentile, int(len(history))

    def append(self, records: list[dict]) -> None:
        if not records:
            return
        current = self.load()
        new = pd.DataFrame(records)
        for column in self.COLUMNS:
            if column not in new.columns:
                new[column] = np.nan
        new = new[self.COLUMNS]
        new["date"] = pd.to_datetime(new["date"], errors="coerce").dt.date
        new["ticker"] = new["ticker"].astype(str).str.upper()
        new["iv_proxy"] = pd.to_numeric(new["iv_proxy"], errors="coerce")
        combined = new.copy() if current.empty else pd.concat([current, new], ignore_index=True)
        combined = combined.dropna(subset=["date", "ticker", "iv_proxy"])
        combined = combined.sort_values(["ticker", "date"]).drop_duplicates(
            subset=["date", "ticker"], keep="last"
        )
        combined.to_csv(self.path, index=False)

    def seed_if_missing(self, frame: pd.DataFrame) -> None:
        """Seed demo history without overwriting an existing ticker/date observation."""
        if frame.empty:
            return
        records = frame.copy()
        records["date"] = pd.to_datetime(records["date"], errors="coerce").dt.date
        self.append(records.to_dict(orient="records"))
