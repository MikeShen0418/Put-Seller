from __future__ import annotations

import shutil
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import resolve_path
from .features import compute_underlying_features, enrich_option_chain
from .optimizer import optimize_portfolio
from .providers.base import MarketDataProvider
from .providers.demo import DemoProvider
from .report import render_html_report, write_run_summary
from .scoring import score_candidates
from .store import IVSnapshotStore


@dataclass
class PipelineResult:
    underlying_snapshot: pd.DataFrame
    all_candidates: pd.DataFrame
    best_by_ticker: pd.DataFrame
    allocation: pd.DataFrame
    portfolio_summary: dict[str, float]
    output_dir: Path
    report_path: Path


def _parse_bool(value: Any, default: bool = False) -> bool:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _parse_optional_date(value: Any) -> date | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip()
    if not text:
        return None
    parsed = pd.to_datetime(text, errors="coerce")
    return None if pd.isna(parsed) else parsed.date()


def _parse_optional_float(value: Any) -> float | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        parsed = float(text)
    except ValueError:
        return None
    return parsed if np.isfinite(parsed) else None


def _select_best(scored: pd.DataFrame) -> pd.Series:
    rank = {"SELL": 4, "WATCH": 3, "SKIP": 2, "REJECT": 1, "ERROR": 0}
    temp = scored.copy()
    temp["_rank"] = temp["decision"].map(rank).fillna(0)
    if "hard_failure_count" not in temp.columns:
        temp["hard_failure_count"] = 0
    temp = temp.sort_values(
        ["_rank", "hard_failure_count", "decision_score", "annualized_max_yield", "open_interest"],
        ascending=[False, True, False, False, False],
    )
    return temp.iloc[0].drop(labels=["_rank"])


def _iv_proxy(scored_or_enriched: pd.DataFrame, target_dte: int) -> float:
    if scored_or_enriched.empty:
        return float("nan")
    frame = scored_or_enriched.copy()
    subset = frame.loc[frame["abs_delta"].between(0.15, 0.35, inclusive="both")]
    if subset.empty:
        subset = frame
    subset = subset.assign(_dte_gap=(subset["dte"] - target_dte).abs())
    closest_gap = subset["_dte_gap"].min()
    closest = subset.loc[subset["_dte_gap"] == closest_gap]
    return float(closest["iv"].median())


def run_pipeline(
    provider: MarketDataProvider,
    config: dict[str, Any],
    config_path: str | Path,
    mode: str,
    output_root_override: str | Path | None = None,
) -> PipelineResult:
    config_path = Path(config_path).resolve()
    watchlist_path = resolve_path(config_path, config["watchlist_path"])
    snapshot_setting = (
        config.get("demo_snapshot_store_path", config["snapshot_store_path"])
        if mode.lower() == "demo"
        else config["snapshot_store_path"]
    )
    snapshot_path = resolve_path(config_path, snapshot_setting)
    output_root = (
        Path(output_root_override).resolve()
        if output_root_override is not None
        else resolve_path(config_path, config["output_root"])
    )
    output_root.mkdir(parents=True, exist_ok=True)

    watchlist = pd.read_csv(watchlist_path)
    required = {"ticker", "enabled"}
    missing = required.difference(watchlist.columns)
    if missing:
        raise ValueError(f"Watchlist is missing columns: {sorted(missing)}")
    watchlist["ticker"] = watchlist["ticker"].astype(str).str.upper().str.strip()
    watchlist = watchlist.loc[watchlist["enabled"].map(lambda value: _parse_bool(value, True))]
    if watchlist.empty:
        raise ValueError("The enabled watchlist is empty")

    store = IVSnapshotStore(snapshot_path)
    if isinstance(provider, DemoProvider):
        for ticker in watchlist["ticker"]:
            store.seed_if_missing(provider.synthetic_iv_history(ticker))

    underlying_rows: list[dict[str, Any]] = []
    candidate_frames: list[pd.DataFrame] = []
    best_rows: list[dict[str, Any]] = []
    snapshot_records: list[dict[str, Any]] = []

    for _, watch_row in watchlist.iterrows():
        ticker = str(watch_row["ticker"]).upper()
        try:
            quote = provider.get_quote(ticker)
            quote_as_of = quote.get("as_of")
            if isinstance(quote_as_of, datetime):
                as_of = quote_as_of.date()
            else:
                as_of = date.today()
            history = provider.get_history(ticker)
            underlying = compute_underlying_features(history, quote)

            manual_earnings = _parse_optional_date(watch_row.get("manual_earnings_date"))
            earnings_date = manual_earnings or provider.get_next_earnings(ticker)
            manual_news_clear = _parse_bool(watch_row.get("manual_news_clear"), False)
            max_breakeven_price = _parse_optional_float(watch_row.get("max_breakeven_price"))
            min_annualized_yield = _parse_optional_float(watch_row.get("min_annualized_yield"))
            max_contracts = int(watch_row.get("max_contracts") or config["capital"]["max_contracts_per_ticker"])

            profile = config["profile"]
            expirations = [
                expiry
                for expiry in provider.get_expirations(ticker)
                if profile["min_dte"] <= (expiry - as_of).days <= profile["max_dte"]
            ]
            if not expirations:
                raise ValueError(
                    f"No expirations found in {profile['min_dte']}-{profile['max_dte']} DTE window"
                )

            chains: list[pd.DataFrame] = []
            for expiration in expirations:
                chain = provider.get_option_chain(ticker, expiration)
                if not chain.empty:
                    chains.append(chain)
            if not chains:
                raise ValueError("Option chains were empty for all eligible expirations")

            chain = pd.concat(chains, ignore_index=True)
            enriched = enrich_option_chain(
                chain=chain,
                quote=quote,
                underlying=underlying,
                as_of=as_of,
                earnings_date=earnings_date,
                execution_fraction_from_bid=config["decision"]["execution_fraction_from_bid"],
                earnings_buffer_days=config["decision"]["earnings_buffer_days"],
            )
            enriched["max_breakeven_price"] = max_breakeven_price
            enriched["ticker_min_annualized_yield"] = min_annualized_yield
            iv_proxy = _iv_proxy(enriched, int(profile["target_dte"]))
            iv_percentile, iv_history_days = store.percentile(ticker, iv_proxy)

            scored = score_candidates(
                candidates=enriched,
                config=config,
                manual_news_clear=manual_news_clear,
                iv_percentile=iv_percentile,
                iv_history_days=iv_history_days,
            )
            scored["sector"] = watch_row.get("sector", "")
            scored["thesis"] = watch_row.get("thesis", "")
            scored["max_contracts"] = max_contracts
            scored["manual_news_clear"] = manual_news_clear
            scored["data_mode"] = quote.get("data_mode", mode)
            candidate_frames.append(scored)

            best = _select_best(scored).to_dict()
            best_rows.append(best)

            underlying_rows.append(
                {
                    "ticker": ticker,
                    **underlying,
                    "iv_proxy": iv_proxy,
                    "iv_percentile": iv_percentile,
                    "iv_history_days": iv_history_days,
                    "earnings_date": earnings_date,
                    "manual_news_clear": manual_news_clear,
                    "max_breakeven_price": max_breakeven_price,
                    "min_annualized_yield": min_annualized_yield,
                    "sector": watch_row.get("sector", ""),
                    "thesis": watch_row.get("thesis", ""),
                    "data_mode": quote.get("data_mode", mode),
                    "error": "",
                }
            )
            snapshot_records.append(
                {
                    "date": as_of,
                    "ticker": ticker,
                    "iv_proxy": iv_proxy,
                    "source": quote.get("data_mode", mode),
                }
            )
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            underlying_rows.append(
                {
                    "ticker": ticker,
                    "data_mode": mode,
                    "error": message,
                    "sector": watch_row.get("sector", ""),
                    "thesis": watch_row.get("thesis", ""),
                }
            )
            best_rows.append(
                {
                    "ticker": ticker,
                    "decision": "ERROR",
                    "decision_score": 0.0,
                    "failure_reasons": message,
                    "warnings": "",
                    "positive_signals": "",
                    "max_contracts": int(watch_row.get("max_contracts") or 1),
                    "sector": watch_row.get("sector", ""),
                    "thesis": watch_row.get("thesis", ""),
                }
            )

    store.append(snapshot_records)

    underlying_snapshot = pd.DataFrame(underlying_rows)
    all_candidates = pd.concat(candidate_frames, ignore_index=True) if candidate_frames else pd.DataFrame()
    best_by_ticker = pd.DataFrame(best_rows)
    if not best_by_ticker.empty:
        decision_rank = {"SELL": 0, "WATCH": 1, "SKIP": 2, "REJECT": 3, "ERROR": 4}
        best_by_ticker["_sort"] = best_by_ticker["decision"].map(decision_rank).fillna(9)
        best_by_ticker = best_by_ticker.sort_values(
            ["_sort", "decision_score"], ascending=[True, False]
        ).drop(columns="_sort").reset_index(drop=True)

    allocation, portfolio_summary = optimize_portfolio(best_by_ticker, config)

    run_time = datetime.now(timezone.utc)
    run_id = run_time.strftime("run_%Y%m%d_%H%M%SZ")
    output_dir = output_root / run_id
    output_dir.mkdir(parents=True, exist_ok=False)

    underlying_snapshot.to_csv(output_dir / "underlying_snapshot.csv", index=False)
    all_candidates.to_csv(output_dir / "all_candidates.csv", index=False)
    best_by_ticker.to_csv(output_dir / "best_by_ticker.csv", index=False)
    allocation.to_csv(output_dir / "portfolio_allocation.csv", index=False)

    report_path = output_dir / "decision_report.html"
    render_html_report(
        output_path=report_path,
        mode=mode,
        run_timestamp=run_time.isoformat(),
        profile_name=config["profile_name"],
        best_by_ticker=best_by_ticker,
        underlying_snapshot=underlying_snapshot,
        allocation=allocation,
        portfolio_summary=portfolio_summary,
        config=config,
    )
    write_run_summary(
        output_dir / "run_summary.json",
        {
            "run_timestamp": run_time.isoformat(),
            "mode": mode,
            "profile": config["profile_name"],
            "portfolio_summary": portfolio_summary,
            "decision_counts": best_by_ticker.get("decision", pd.Series(dtype=str)).value_counts().to_dict(),
            "watchlist_path": str(watchlist_path),
            "snapshot_store_path": str(snapshot_path),
        },
    )

    latest_dir = output_root / "latest"
    if latest_dir.exists():
        shutil.rmtree(latest_dir)
    shutil.copytree(output_dir, latest_dir)

    return PipelineResult(
        underlying_snapshot=underlying_snapshot,
        all_candidates=all_candidates,
        best_by_ticker=best_by_ticker,
        allocation=allocation,
        portfolio_summary=portfolio_summary,
        output_dir=output_dir,
        report_path=report_path,
    )
