"""Explainable cash-secured put screening and allocation system."""

__version__ = "0.1.0"
