from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

import pandas as pd


def _fmt_money(value: Any) -> str:
    try:
        return f"${float(value):,.0f}"
    except (TypeError, ValueError):
        return ""


def _fmt_price(value: Any) -> str:
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return ""


def _fmt_pct(value: Any, decimals: int = 1) -> str:
    try:
        return f"{float(value) * 100:.{decimals}f}%"
    except (TypeError, ValueError):
        return ""


def _fmt_num(value: Any, decimals: int = 2) -> str:
    try:
        return f"{float(value):,.{decimals}f}"
    except (TypeError, ValueError):
        return ""


def _prepare_best(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "decision",
        "decision_score",
        "expiration",
        "dte",
        "strike",
        "abs_delta",
        "estimated_fill",
        "premium_dollars",
        "cash_required",
        "max_cycle_yield",
        "annualized_max_yield",
        "breakeven_discount",
        "iv",
        "iv_rv_ratio",
        "iv_percentile_effective",
        "down_move_atr",
        "warnings",
        "failure_reasons",
    ]
    available = [column for column in columns if column in frame.columns]
    result = frame[available].copy()
    rename = {
        "decision_score": "Score",
        "estimated_fill": "Est. fill",
        "premium_dollars": "Max premium",
        "cash_required": "Cash required",
        "max_cycle_yield": "Cycle yield",
        "annualized_max_yield": "Annualized yield",
        "breakeven_discount": "Breakeven cushion",
        "iv_rv_ratio": "IV/RV",
        "iv_percentile_effective": "IV percentile*",
        "down_move_atr": "Down move (ATR)",
        "abs_delta": "Abs delta",
        "failure_reasons": "Hard failures",
        "warnings": "Watch items",
    }
    result = result.rename(columns=rename)
    for column in ["strike", "Est. fill"]:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    for column in ["Max premium", "Cash required"]:
        if column in result:
            result[column] = result[column].map(_fmt_money)
    for column in ["Cycle yield", "Annualized yield", "Breakeven cushion", "iv"]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    for column in ["Abs delta", "IV/RV", "Down move (ATR)"]:
        if column in result:
            result[column] = result[column].map(_fmt_num)
    if "IV percentile*" in result:
        result["IV percentile*"] = result["IV percentile*"].map(lambda x: _fmt_num(x, 0))
    if "Score" in result:
        result["Score"] = result["Score"].map(lambda x: _fmt_num(x, 1))
    return result


def _prepare_allocation(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    columns = [
        "ticker",
        "contracts",
        "expiration",
        "strike",
        "abs_delta",
        "allocated_cash",
        "allocated_premium",
        "max_cycle_yield",
        "annualized_max_yield",
        "decision_score",
    ]
    result = frame[[column for column in columns if column in frame.columns]].copy()
    result = result.rename(
        columns={
            "allocated_cash": "Allocated cash",
            "allocated_premium": "Max premium",
            "max_cycle_yield": "Cycle yield",
            "annualized_max_yield": "Annualized yield",
            "decision_score": "Score",
            "abs_delta": "Abs delta",
        }
    )
    for column in ["strike"]:
        if column in result:
            result[column] = result[column].map(_fmt_price)
    for column in ["Allocated cash", "Max premium"]:
        if column in result:
            result[column] = result[column].map(_fmt_money)
    for column in ["Cycle yield", "Annualized yield"]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    for column in ["Abs delta", "Score"]:
        if column in result:
            result[column] = result[column].map(_fmt_num)
    return result


def _prepare_underlyings(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "ticker",
        "spot",
        "daily_return",
        "down_move_atr",
        "close_off_low_atr",
        "rv20",
        "iv_proxy",
        "iv_percentile",
        "price_to_sma50",
        "return_20d",
        "earnings_date",
        "data_mode",
        "error",
    ]
    result = frame[[column for column in columns if column in frame.columns]].copy()
    result = result.rename(
        columns={
            "daily_return": "Day return",
            "down_move_atr": "Down move (ATR)",
            "close_off_low_atr": "Close off low (ATR)",
            "price_to_sma50": "Price/SMA50",
            "return_20d": "20d return",
            "iv_percentile": "IV percentile",
            "iv_proxy": "IV proxy",
            "data_mode": "Data mode",
        }
    )
    if "spot" in result:
        result["spot"] = result["spot"].map(_fmt_price)
    for column in ["Day return", "rv20", "IV proxy", "20d return"]:
        if column in result:
            result[column] = result[column].map(_fmt_pct)
    for column in ["Down move (ATR)", "Close off low (ATR)", "Price/SMA50"]:
        if column in result:
            result[column] = result[column].map(_fmt_num)
    if "IV percentile" in result:
        result["IV percentile"] = result["IV percentile"].map(lambda x: _fmt_num(x, 0))
    return result


def render_html_report(
    output_path: str | Path,
    mode: str,
    run_timestamp: str,
    profile_name: str,
    best_by_ticker: pd.DataFrame,
    underlying_snapshot: pd.DataFrame,
    allocation: pd.DataFrame,
    portfolio_summary: dict[str, float],
    config: dict[str, Any],
) -> None:
    output_path = Path(output_path)
    decision_counts = best_by_ticker.get("decision", pd.Series(dtype=str)).value_counts().to_dict()
    cards = [
        ("Profile", profile_name),
        ("SELL candidates", str(decision_counts.get("SELL", 0))),
        ("WATCH candidates", str(decision_counts.get("WATCH", 0))),
        ("Cash allocated", _fmt_money(portfolio_summary.get("cash_allocated", 0))),
        ("Max premium", _fmt_money(portfolio_summary.get("premium_dollars", 0))),
        ("Portfolio cycle yield", _fmt_pct(portfolio_summary.get("portfolio_cycle_yield", 0))),
        ("Weighted annualized yield", _fmt_pct(portfolio_summary.get("weighted_annualized_yield", 0))),
    ]
    cards_html = "".join(
        f'<div class="card"><div class="label">{html.escape(label)}</div><div class="value">{html.escape(value)}</div></div>'
        for label, value in cards
    )

    best_html = _prepare_best(best_by_ticker).to_html(index=False, border=0, classes="data-table")
    underlying_html = _prepare_underlyings(underlying_snapshot).to_html(index=False, border=0, classes="data-table")
    allocation_html = (
        _prepare_allocation(allocation).to_html(index=False, border=0, classes="data-table")
        if not allocation.empty
        else '<div class="empty">No candidates passed the SELL threshold and portfolio constraints.</div>'
    )

    profile = config["profile"]
    filters = config["decision"]["filters"]
    entry = config["decision"]["entry"]
    method = {
        "DTE": f"{profile['min_dte']}-{profile['max_dte']}",
        "Absolute delta": f"{profile['min_abs_delta']:.2f}-{profile['max_abs_delta']:.2f}",
        "Preferred delta": f"{profile['preferred_abs_delta']:.2f}",
        "Minimum IV/RV": f"{filters['min_iv_rv_ratio']:.2f}",
        "Maximum spread": f"{filters['max_spread_pct']:.1%}",
        "Preferred red day": f"{entry['min_down_move_atr']:.2f}-{entry['max_down_move_atr']:.2f} ATR",
        "Earnings rule": "Reject contracts crossing earnings plus buffer",
        "Allocation objective": str(config["capital"]["objective"]),
    }
    method_rows = "".join(
        f"<tr><th>{html.escape(key)}</th><td>{html.escape(value)}</td></tr>"
        for key, value in method.items()
    )

    demo_banner = ""
    if mode.lower() == "demo":
        demo_banner = (
            '<div class="banner"><strong>DEMO MODE:</strong> All prices, options, IVs and earnings dates '
            "in this report are synthetic. The tickers are placeholders, not recommendations.</div>"
        )

    report = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Put Seller Decision Report</title>
<style>
:root {{ --ink:#14213d; --muted:#667085; --line:#e5e7eb; --panel:#ffffff; --bg:#f5f7fb; --accent:#1f4e79; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:Inter,Segoe UI,Arial,sans-serif; color:var(--ink); background:var(--bg); }}
.container {{ max-width:1500px; margin:0 auto; padding:28px; }}
h1 {{ margin:0 0 6px; font-size:30px; }}
h2 {{ margin:32px 0 12px; font-size:21px; }}
.subtle {{ color:var(--muted); margin-bottom:20px; }}
.banner {{ padding:12px 14px; border:1px solid #f0c36d; background:#fff8e6; border-radius:8px; margin:14px 0; }}
.cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin:18px 0 8px; }}
.card {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:14px; box-shadow:0 1px 2px rgba(16,24,40,.04); }}
.card .label {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.04em; }}
.card .value {{ font-size:22px; font-weight:700; margin-top:7px; }}
.panel {{ background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:16px; overflow:auto; }}
.data-table {{ border-collapse:collapse; width:100%; font-size:12px; white-space:nowrap; }}
.data-table th {{ position:sticky; top:0; text-align:left; padding:9px 8px; border-bottom:2px solid #cfd6df; background:#eef3f8; }}
.data-table td {{ padding:8px; border-bottom:1px solid var(--line); vertical-align:top; }}
.data-table tr:hover td {{ background:#fafcff; }}
.method-table {{ border-collapse:collapse; width:100%; max-width:760px; }}
.method-table th,.method-table td {{ border-bottom:1px solid var(--line); padding:9px; text-align:left; }}
.method-table th {{ width:230px; color:var(--muted); }}
.empty {{ color:var(--muted); padding:20px 4px; }}
.note {{ color:var(--muted); font-size:12px; line-height:1.55; margin-top:10px; }}
.footer {{ margin:36px 0 10px; color:var(--muted); font-size:12px; line-height:1.5; }}
</style>
</head>
<body><div class="container">
<h1>Cash-Secured Put Decision Report</h1>
<div class="subtle">Run {html.escape(run_timestamp)} | mode={html.escape(mode)} | profile={html.escape(profile_name)}</div>
{demo_banner}
<div class="cards">{cards_html}</div>

<h2>Best contract by ticker</h2>
<div class="panel">{best_html}</div>
<div class="note">*IV percentile is confidence-adjusted toward 50 until the local snapshot store has enough observations.</div>

<h2>Optimized allocation</h2>
<div class="panel">{allocation_html}</div>

<h2>Underlying conditions</h2>
<div class="panel">{underlying_html}</div>

<h2>Active rules</h2>
<div class="panel"><table class="method-table">{method_rows}</table></div>

<div class="footer">
This system is decision support, not an order-entry engine. Maximum premium and maximum yield assume the option expires worthless.
The score is a configurable heuristic, not a forecast of profit or assignment probability. A manual check for company-specific news remains mandatory.
</div>
</div></body></html>"""
    output_path.write_text(report, encoding="utf-8")


def write_run_summary(path: str | Path, payload: dict[str, Any]) -> None:
    Path(path).write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
