from __future__ import annotations

import io
import os
from datetime import date, datetime, timedelta, timezone
from typing import Any

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .base import MarketDataProvider


class TradierAPIError(RuntimeError):
    """Raised when a live market-data request fails or is malformed."""


class TradierProvider(MarketDataProvider):
    """Live provider using Tradier for market data and Alpha Vantage for earnings."""

    def __init__(
        self,
        token: str | None = None,
        alpha_vantage_key: str | None = None,
        base_url: str | None = None,
        timeout_seconds: int = 20,
    ) -> None:
        self.token = token or os.getenv("TRADIER_TOKEN")
        if not self.token:
            raise TradierAPIError(
                "TRADIER_TOKEN is missing. Copy .env.example to .env and add a token, "
                "or run with --mode demo."
            )
        self.alpha_vantage_key = alpha_vantage_key or os.getenv("ALPHAVANTAGE_API_KEY")
        self.base_url = (base_url or os.getenv("TRADIER_BASE_URL") or "https://api.tradier.com/v1").rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.6,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "POST"}),
        )
        self.session.mount("https://", HTTPAdapter(max_retries=retry))
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json",
                "User-Agent": "put-seller-decision-system/0.1",
            }
        )
        self._earnings_cache: dict[str, date | None] = {}
        self._earnings_calendar_loaded = False

    def _get(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        response = self.session.get(url, params=params, timeout=self.timeout_seconds)
        if response.status_code >= 400:
            raise TradierAPIError(
                f"Tradier request failed ({response.status_code}) for {path}: {response.text[:500]}"
            )
        try:
            payload = response.json()
        except ValueError as exc:
            raise TradierAPIError(f"Tradier returned non-JSON content for {path}") from exc
        if isinstance(payload, dict) and payload.get("fault"):
            raise TradierAPIError(f"Tradier API fault for {path}: {payload['fault']}")
        return payload

    @staticmethod
    def _as_list(value: Any) -> list[Any]:
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]

    def get_quote(self, ticker: str) -> dict:
        payload = self._get("markets/quotes", {"symbols": ticker.upper(), "greeks": "false"})
        quote = payload.get("quotes", {}).get("quote")
        if isinstance(quote, list):
            quote = quote[0] if quote else None
        if not quote:
            raise TradierAPIError(f"No quote returned for {ticker}")

        spot = quote.get("last") or quote.get("bid") or quote.get("ask")
        if spot is None:
            raise TradierAPIError(f"Quote for {ticker} had no usable price")
        timestamp = quote.get("trade_date")
        if isinstance(timestamp, (int, float)):
            # Tradier has returned both seconds and milliseconds historically.
            if timestamp > 10_000_000_000:
                timestamp /= 1000.0
            as_of = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        else:
            as_of = datetime.now(tz=timezone.utc)

        return {
            "ticker": ticker.upper(),
            "spot": float(spot),
            "prev_close": float(quote.get("prevclose") or spot),
            "open": float(quote.get("open") or spot),
            "high": float(quote.get("high") or spot),
            "low": float(quote.get("low") or spot),
            "volume": int(quote.get("volume") or 0),
            "as_of": as_of,
            "data_mode": "TRADIER_LIVE_OR_DELAYED",
        }

    def get_history(self, ticker: str, calendar_days: int = 420) -> pd.DataFrame:
        end = date.today()
        start = end - timedelta(days=calendar_days)
        payload = self._get(
            "markets/history",
            {
                "symbol": ticker.upper(),
                "interval": "daily",
                "start": start.isoformat(),
                "end": end.isoformat(),
            },
        )
        days = self._as_list(payload.get("history", {}).get("day"))
        if not days:
            raise TradierAPIError(f"No daily history returned for {ticker}")
        frame = pd.DataFrame(days)
        required = ["date", "open", "high", "low", "close", "volume"]
        missing = [column for column in required if column not in frame.columns]
        if missing:
            raise TradierAPIError(f"History for {ticker} is missing columns: {missing}")
        frame["date"] = pd.to_datetime(frame["date"]).dt.date
        for column in ["open", "high", "low", "close", "volume"]:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
        return frame[required].dropna(subset=["close"]).sort_values("date").reset_index(drop=True)

    def get_expirations(self, ticker: str) -> list[date]:
        payload = self._get(
            "markets/options/expirations",
            {
                "symbol": ticker.upper(),
                "includeAllRoots": "false",
                "strikes": "false",
                "contractSize": "false",
                "expirationType": "false",
            },
        )
        raw_dates = self._as_list(payload.get("expirations", {}).get("date"))
        result: list[date] = []
        for raw in raw_dates:
            try:
                result.append(pd.Timestamp(raw).date())
            except Exception:
                continue
        return sorted(set(result))

    def get_option_chain(self, ticker: str, expiration: date) -> pd.DataFrame:
        payload = self._get(
            "markets/options/chains",
            {
                "symbol": ticker.upper(),
                "expiration": expiration.isoformat(),
                "greeks": "true",
            },
        )
        options = self._as_list(payload.get("options", {}).get("option"))
        rows: list[dict[str, Any]] = []
        for option in options:
            if option.get("option_type") != "put":
                continue
            greeks = option.get("greeks") or {}
            iv = greeks.get("smv_vol") or greeks.get("mid_iv") or greeks.get("bid_iv") or greeks.get("ask_iv")
            rows.append(
                {
                    "symbol": option.get("symbol"),
                    "ticker": ticker.upper(),
                    "expiration": pd.Timestamp(option.get("expiration_date") or expiration).date(),
                    "strike": pd.to_numeric(option.get("strike"), errors="coerce"),
                    "option_type": "put",
                    "bid": pd.to_numeric(option.get("bid"), errors="coerce"),
                    "ask": pd.to_numeric(option.get("ask"), errors="coerce"),
                    "last": pd.to_numeric(option.get("last"), errors="coerce"),
                    "volume": pd.to_numeric(option.get("volume"), errors="coerce"),
                    "open_interest": pd.to_numeric(option.get("open_interest"), errors="coerce"),
                    "delta": pd.to_numeric(greeks.get("delta"), errors="coerce"),
                    "gamma": pd.to_numeric(greeks.get("gamma"), errors="coerce"),
                    "theta": pd.to_numeric(greeks.get("theta"), errors="coerce"),
                    "vega": pd.to_numeric(greeks.get("vega"), errors="coerce"),
                    "iv": pd.to_numeric(iv, errors="coerce"),
                    "quote_time": greeks.get("updated_at") or datetime.now(tz=timezone.utc).isoformat(),
                }
            )
        frame = pd.DataFrame(rows)
        if frame.empty:
            return frame
        numeric = ["strike", "bid", "ask", "last", "volume", "open_interest", "delta", "gamma", "theta", "vega", "iv"]
        for column in numeric:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
        return frame.dropna(subset=["strike", "bid", "ask", "delta", "iv"]).reset_index(drop=True)

    def _load_earnings_calendar(self) -> None:
        if self._earnings_calendar_loaded or not self.alpha_vantage_key:
            return
        self._earnings_calendar_loaded = True
        params = {
            "function": "EARNINGS_CALENDAR",
            "horizon": "3month",
            "apikey": self.alpha_vantage_key,
        }
        try:
            response = requests.get(
                "https://www.alphavantage.co/query",
                params=params,
                timeout=self.timeout_seconds,
                headers={"User-Agent": "put-seller-decision-system/0.1"},
            )
            if response.status_code >= 400:
                return
            frame = pd.read_csv(io.StringIO(response.text))
            if frame.empty or not {"symbol", "reportDate"}.issubset(frame.columns):
                return
            frame["symbol"] = frame["symbol"].astype(str).str.upper()
            frame["reportDate"] = pd.to_datetime(frame["reportDate"], errors="coerce").dt.date
            today = date.today()
            frame = frame.loc[frame["reportDate"].notna() & (frame["reportDate"] >= today)]
            for symbol, group in frame.groupby("symbol"):
                self._earnings_cache[str(symbol)] = min(group["reportDate"])
        except Exception:
            # Earnings are a fail-closed input in the scoring layer. Returning no
            # date causes the candidate to be rejected under the default config.
            return

    def get_next_earnings(self, ticker: str) -> date | None:
        ticker = ticker.upper()
        if not self.alpha_vantage_key:
            return None
        self._load_earnings_calendar()
        return self._earnings_cache.get(ticker)

