# Cash-Secured Put Decision System

A configurable Python pipeline for screening a watchlist, scoring cash-secured put candidates, and allocating a fixed cash budget across the candidates that pass every rule.

The repository runs immediately in **demo mode** with deterministic synthetic data. The familiar tickers in the demo watchlist are placeholders only; the generated prices, options, volatility, and earnings dates are not live and are not recommendations.

## What the system does

1. Reads your approved stock list from a CSV watchlist.
2. Pulls the underlying quote, daily history, option expirations, put chains, Greeks, IV, and the next earnings date.
3. Calculates:
   - 20-day ATR and realized volatility
   - current decline in ATR units
   - recovery from the session low
   - 5-day and 20-day trend measures
   - maximum cycle yield and simple annualized maximum yield
   - strike and breakeven cushions
   - strike distance in implied-move units
   - IV-to-realized-volatility ratio
   - a rolling IV percentile stored locally over time
   - option liquidity and spread quality
4. Applies hard gates before any score is considered.
5. Produces an explainable 0–100 score for each surviving contract.
6. Labels the best contract for each ticker as `SELL`, `WATCH`, `SKIP`, `REJECT`, or `ERROR`.
7. Uses a group-knapsack optimizer to allocate capital without exceeding total cash, per-ticker limits, or concentration limits.
8. Writes CSV files, JSON metadata, and an HTML decision report.

## Decision philosophy

The model is designed around the discussion that led to this project:

- Sell puts only on a user-approved company list.
- Prefer elevated IV relative to both realized volatility and the ticker's own stored IV history.
- Treat high IV as a premium-richness signal, not proof that bulls and bears are equally informed or equally active.
- Prefer a meaningful red day, but reject panic moves and persistent breakdowns.
- Require evidence of intraday stabilization rather than selling merely because the stock is down.
- Exclude contracts that cross earnings, including a configurable buffer after expiration.
- Use delta and implied-move distance instead of a fixed “5% below spot” rule.
- Do not force trades. Cash remains unallocated when too few candidates qualify.

The maximum-yield calculations assume the option expires worthless:

```text
Maximum cycle yield = estimated premium / strike
Simple annualized maximum yield = cycle yield * 365 / DTE
Cash required per contract = strike * 100
Maximum premium per contract = estimated premium * 100
```

The default estimated fill is:

```text
bid + 35% * (ask - bid)
```

Change `execution_fraction_from_bid` to `0.0` for strict bid pricing or `0.5` for midpoint pricing.

## Hard gates

By default, a candidate is rejected when any of the following is true:

- DTE or absolute delta is outside the active profile.
- The strike is not out of the money.
- Bid, volume, or open interest is too low.
- The bid-ask spread is too wide.
- IV is not sufficiently high relative to 20-day realized volatility.
- The next earnings date is unknown.
- Earnings occur before expiration or inside the post-expiration buffer.
- `manual_news_clear` is false.
- The daily decline is in the configured panic zone.
- The five-day decline is too severe.
- Price is too far below the 50-day moving average.

A hard failure overrides a high yield or high score.

## Strategy profiles

Change one line in `config/config.yaml`:

```yaml
active_profile: balanced
```

Available profiles:

| Profile | DTE | Absolute put delta | Intended use |
|---|---:|---:|---|
| `defensive` | 35–50 | 0.12–0.20 | More strike distance and lower initial directional exposure |
| `balanced` | 28–42 | 0.15–0.25 | Default compromise between yield and buffer |
| `yield` | 21–35 | 0.24–0.35 | Higher gross premium yield and more assignment exposure |

These are configurable search regions, not claims that a particular delta is optimal.

## Quick start: demo mode

### Windows

Double-click:

```text
setup_windows.bat
```

Then double-click:

```text
run_demo.bat
```

### Command line

```bash
python -m venv .venv
```

Activate the environment, then:

```bash
pip install -r requirements.txt
python -m put_seller.cli --mode demo --config config/config.yaml
```

Useful overrides:

```bash
python -m put_seller.cli --mode demo --profile defensive
python -m put_seller.cli --mode demo --profile yield --cash 250000
python -m put_seller.cli --mode demo --as-of 2026-10-20
```

## Live data setup

The included live provider uses:

- **Tradier** for quotes, daily history, option expirations, option chains, Greeks, and IV.
- **Alpha Vantage** for the upcoming earnings calendar.

Tradier's option-chain endpoint supports `greeks=true` and includes Greek/IV fields. Tradier states that real-time U.S. stock and options data is available to brokerage account holders, while its sandbox is delayed; its derived Greeks are updated hourly. Official documentation:

- https://docs.tradier.com/reference/brokerage-api-markets-get-options-chains
- https://docs.tradier.com/reference/brokerage-api-markets-get-options-expirations
- https://docs.tradier.com/reference/brokerage-api-markets-get-history
- https://docs.tradier.com/docs/market-data

Alpha Vantage's `EARNINGS_CALENDAR` endpoint returns upcoming earnings in CSV format and can be filtered by ticker:

- https://www.alphavantage.co/documentation/#earnings-calendar

Copy `.env.example` to `.env` and add your credentials:

```text
TRADIER_TOKEN=...
TRADIER_BASE_URL=https://api.tradier.com/v1
ALPHAVANTAGE_API_KEY=...
```

Then replace `data/watchlist_dummy.csv` with your own watchlist or point `watchlist_path` to a new file. A conservative starting template is included at `data/watchlist_live_template.csv`.

Run:

```bash
python -m put_seller.cli --mode live --config config/config.yaml --watchlist data/watchlist_live_template.csv
```

The default rules reject a ticker when its next earnings date is unknown. You can either provide an Alpha Vantage key or populate `manual_earnings_date` in the watchlist.

## Watchlist columns

| Column | Meaning |
|---|---|
| `ticker` | U.S. equity ticker |
| `enabled` | Include/exclude without deleting the row |
| `max_contracts` | Per-ticker contract cap before portfolio concentration limits |
| `sector` | Informational label |
| `manual_news_clear` | Must be true under the default rules; set true only after reviewing material company news |
| `manual_earnings_date` | Optional `YYYY-MM-DD` override |
| `max_breakeven_price` | Optional valuation gate; reject when strike minus estimated premium is above this price |
| `min_annualized_yield` | Optional ticker-specific minimum, entered as a decimal such as `0.20` for 20% |
| `thesis` | Your reason for keeping the company on the approved list |

The live template defaults `manual_news_clear` to false so the system cannot accidentally approve a trade before a news review.

## IV percentile behavior

Tradier provides current IV but not the one-year historical IV series needed for a true historical percentile. The system therefore keeps separate stores: `data/iv_snapshots_live.csv` for live runs and `data/iv_snapshots_demo.csv` for synthetic demo runs. Each records one IV proxy per ticker per date.

- With fewer than 60 stored observations, the percentile is pulled toward a neutral 50.
- Confidence increases as daily observations accumulate.
- Demo mode seeds synthetic history only to exercise the percentile logic.
- A later version can replace this store with paid historical options data without changing the scoring interface.

## Scoring model

After hard gates, each contract receives six component scores:

| Component | Default weight | Purpose |
|---|---:|---|
| Yield | 25% | Gross premium per dollar of cash and DTE |
| Volatility richness | 20% | IV/RV plus stored IV percentile |
| Entry quality | 20% | Red-day magnitude and recovery from the low |
| Trend quality | 15% | Price versus SMA50, 20-day return, and slope |
| Liquidity | 10% | Spread, volume, and open interest |
| Buffer | 10% | Delta preference, breakeven cushion, and implied-move distance |

Every threshold and weight is in `config/config.yaml`.

The score is a heuristic for consistent decision-making. It is not an expected return, probability of profit, or assignment forecast.

## Portfolio optimization

The optimizer first selects the highest-ranked contract for each ticker. It then chooses 0 to `max_contracts` contracts per ticker subject to:

- total cash available
- cash increment used by the dynamic program
- per-ticker contract cap
- maximum percentage of total cash in one ticker

The default objective is `quality_adjusted_premium`:

```text
annualized premium dollars * decision score / 100
```

Other available objectives:

```yaml
objective: premium_dollars
objective: annualized_premium
```

The optimization does not force full investment.

## Output files

Each run creates a timestamped folder under `output/` and refreshes `output/latest/`:

| File | Contents |
|---|---|
| `decision_report.html` | Human-readable dashboard |
| `best_by_ticker.csv` | Best contract and decision for each ticker |
| `all_candidates.csv` | Every evaluated contract and all component scores |
| `underlying_snapshot.csv` | Price, trend, realized-volatility, IV, and earnings features |
| `portfolio_allocation.csv` | Optimized contract counts and cash allocation |
| `run_summary.json` | Run metadata and portfolio summary |

## Notebook

Open:

```text
notebooks/Put_Seller_Decision_System.ipynb
```

It runs the demo pipeline, displays the decision tables, and charts score versus annualized maximum yield.

## Suggested operating routine

1. Maintain a deliberately small approved-company list.
2. Run the screen after the opening volatility has settled, rather than immediately at 9:30 a.m. ET.
3. Review company news and set `manual_news_clear=true` only after that review.
4. Confirm the earnings date through a second source when it is close to expiration.
5. Inspect the live option chain at the broker before placing a limit order.
6. Record the actual fill and later outcome separately from this screening dataset.

## Testing

```bash
pytest -q
```

The included tests cover yield calculations, earnings-event rejection, optimizer constraints, and deterministic demo data.

## Important limitations

- No system can distinguish a temporary pullback from a lasting business deterioration using prices and option data alone.
- High IV can reflect genuine downside information, not merely attractive disagreement.
- Delta is dynamic and is only a model estimate at the current instant.
- A stock crossing the strike does not guarantee immediate early assignment, but an in-the-money option near expiration creates substantial assignment exposure.
- This project does not place orders and intentionally has no broker-trading endpoint.
- Maximum premium is not expected profit.
