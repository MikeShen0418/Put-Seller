@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
echo Live mode uses data\watchlist_live_template.csv, whose manual_news_clear fields default to false.
echo Edit that file and .env before relying on the output.
python -m put_seller.cli --mode live --config config\config.yaml --watchlist data\watchlist_live_template.csv
pause
