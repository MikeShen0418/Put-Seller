from put_seller.providers.demo import DemoProvider


def test_demo_provider_is_deterministic():
    provider_a = DemoProvider()
    provider_b = DemoProvider()
    quote_a = provider_a.get_quote("NVDA")
    quote_b = provider_b.get_quote("NVDA")
    assert quote_a["spot"] == quote_b["spot"]
    expiration = provider_a.get_expirations("NVDA")[4]
    chain = provider_a.get_option_chain("NVDA", expiration)
    assert not chain.empty
    assert set(["bid", "ask", "delta", "iv", "open_interest"]).issubset(chain.columns)
    assert (chain["ask"] >= chain["bid"]).all()
