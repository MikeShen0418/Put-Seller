import pandas as pd

from put_seller.optimizer import optimize_portfolio


def test_optimizer_respects_cash_and_concentration():
    best = pd.DataFrame(
        [
            {
                "ticker": "AAA",
                "decision": "SELL",
                "premium_dollars": 300.0,
                "cash_required": 10000.0,
                "dte": 30,
                "decision_score": 80.0,
                "annualized_max_yield": 0.365,
                "max_contracts": 5,
            },
            {
                "ticker": "BBB",
                "decision": "SELL",
                "premium_dollars": 250.0,
                "cash_required": 8000.0,
                "dte": 30,
                "decision_score": 75.0,
                "annualized_max_yield": 0.380,
                "max_contracts": 5,
            },
        ]
    )
    config = {
        "capital": {
            "total_cash": 30000.0,
            "cash_increment": 100.0,
            "max_ticker_pct": 0.50,
            "max_contracts_per_ticker": 5,
            "objective": "quality_adjusted_premium",
        }
    }
    allocation, summary = optimize_portfolio(best, config)
    assert summary["cash_allocated"] <= 30000.0
    for _, row in allocation.iterrows():
        assert row["allocated_cash"] <= 15000.0
