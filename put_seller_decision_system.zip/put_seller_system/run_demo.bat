@echo off
setlocal
cd /d %~dp0
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python -m put_seller.cli --mode demo --config config\config.yaml
pause
